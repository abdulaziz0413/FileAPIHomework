(function() {
    try {
        (function() {
            function df(a, c, b, d) {
                var e = this;
                return D(window, "c.i", function() {
                    function f(x) {
                        (x = ef(k, l, "", x)(k, l)) && (T(x.then) ? x.then(g) : g(x));
                        return x
                    }

                    function g(x) {
                        x && (T(x) ? m.push(x) : pa(x) && y(function(F) {
                            var U = F[0];
                            F = F[1];
                            T(F) && ("u" === U ? m.push(F) : h(F, U))
                        }, Ma(x)))
                    }

                    function h(x, F, U) {
                        e[F] = $l(k, l, U || p, F, x)
                    }
                    var k = window;
                    (!k || isNaN(a) && !a) && de();
                    var l = am(a, ff, c, b, d),
                        m = [],
                        p = [mh, ef, nh];
                    p.unshift(bm);
                    var r = B(P, bb),
                        q = M(l);
                    l.id || Ua(Ic("Invalid Metrika id: " + l.id, !0));
                    var t = hd.C("counters", {});
                    if (t[q]) return wb(k,
                        q, "Duplicate counter " + q + " initialization"), t[q];
                    t[q] = e;
                    hd.D("counters", t);
                    hd.Ia("counter", e);
                    y(function(x) {
                        x(k, l)
                    }, ee);
                    y(f, id);
                    f(cm);
                    h(dm(k, l, m), "destruct", [mh, nh]);
                    Sb(k, C([k, r, f, 1, "a.i"], oh));
                    y(f, V)
                })()
            }

            function em(a, c) {
                var b = "" + c,
                    d = {
                        id: 1,
                        ca: "0"
                    },
                    e = fm(b);
                e ? d.id = e : -1 === ib(b, ":") ? (b = Ga(b), d.id = b) : (b = b.split(":"), e = b[1], d.id = Ga(b[0]), d.ca = fe(e) ? "1" : "0");
                return [za(a, d), d]
            }

            function gm(a, c) {
                var b = n(c, "data");
                if (ka(b)) {
                    var d = b.split("*");
                    b = d[0];
                    d = d[1];
                    "sc.frame" === b && c.source ? c.source.postMessage("sc.sa",
                        "*") : "sc.sar" === b && a(d || "b")
                }
            }

            function hm(a, c) {
                if ("*" === c) return !0;
                var b = R(a);
                return c === b.host + b.pathname
            }

            function im(a, c) {
                var b = n(c, "target");
                b && a(b)
            }

            function jm(a, c, b) {
                var d = n(b, "submitter");
                d || (b = n(b, "target")) && (d = ge(a, b));
                d && c(d)
            }

            function km(a, c, b, d) {
                var e = he(a, d);
                e && y(function(f) {
                    var g, h = null;
                    try {
                        var k = n(f, "css_selector"),
                            l = bc(k, a.document);
                        h = ph(l)
                    } catch (q) {}
                    k = null;
                    try {
                        var m = n(f, "xpath"),
                            p = lm(m);
                        var r = p ? n(a, "document.evaluate") ? a.document.evaluate(p, a.document, null, a.XPathResult.FIRST_ORDERED_NODE_TYPE,
                            null).singleNodeValue : null : null;
                        k = ph(r)
                    } catch (q) {}
                    f = (g = {}, g.s = [k, h], g.b = e, g);
                    c(f)
                }, b)
            }

            function ph(a) {
                return (a = Kb(a)) ? jd(ie(a)) : null
            }

            function lm(a) {
                if (!a) return "";
                a = a.match(mm);
                if (!a || 0 === a.length) return "";
                var c = nm();
                return "//HTML/BODY/" + J(function(b, d) {
                    var e = d[0],
                        f = Ga(d.slice(1));
                    return "/" + c[e] + (f ? "[" + (f + 1) + "]" : "") + b
                }, "", a)
            }

            function om(a) {
                y(function(c) {
                    var b;
                    if (c.data.auctionId) {
                        var d = c.event,
                            e = c.data;
                        c = e.auctionId;
                        Ha[c] || (Ha[c] = (b = {}, b.auctionId = c, b));
                        b = "auctionInit" === d;
                        if (!Ha[c].startStamp || b) Ha[c].startStamp =
                            b ? e.auctionStart || e.timestamp : e.auctionStart;
                        if (K(d, pm)) {
                            if (b = e.bidderCode) {
                                Ha[c][d] || (Ha[c][d] = {});
                                var f = {};
                                Ha[c][d][b] = f;
                                y(function(g) {
                                    var h = e[g];
                                    la(h) || (f[g] = h)
                                }, qm);
                                Ha[c].endStamp && (Ha[c].aa = !0)
                            }
                        } else "auctionEnd" === d && (Ha[c].aa = !0, Ha[c].endStamp = e.auctionEnd || e.timestamp, Ha[c].requestedBidders = fa(function(g, h, k) {
                            return gf(g, k) === h
                        }, B(Q("bidderCode"), e.bidderRequests)))
                    }
                }, a)
            }

            function rm(a, c) {
                y(function(b) {
                    b.aa && sm(a, c, b.auctionId)
                }, qh(Ha))
            }

            function sm(a, c, b) {
                Ha[b].aa = !1;
                Ha[b].Ka && ha(a, Ha[b].Ka);
                Ha[b].Ka = O(a, function() {
                    var d, e;
                    delete Ha[b].Ka;
                    delete Ha[b].aa;
                    c((d = {}, d.__ym = (e = {}, e.pbjs = Ha[b], e), d));
                    delete Ha[b]
                }, 2E3)
            }

            function tm(a) {
                var c = n(a, "featurePolicy");
                return c ? "browsingTopics" in a && c.allowsFeature("browsing-topics") : !1
            }

            function um(a, c, b, d) {
                var e = n(d, "data");
                if (ka(e)) {
                    var f = e.split("*");
                    e = f[0];
                    var g = f[1];
                    f = f[2];
                    "sc.topics-response" === e ? (g && ("1" === g && f ? (a = xb(a, f), ca(a) && c.D("cta", a)) : c.D("cta.e", g)), b()) : "sc.frame" === e && d.source && d.source.postMessage("sc.topics", "*")
                }
            }

            function vm(a,
                c) {
                var b;
                if ("https://oauth.yandex.ru" === n(c, "origin") && n(c, "source.window") && "_ym_uid_request" === n(c.data, "_ym")) {
                    var d = c.source,
                        e = (b = {}, b._ym_uid = a, b);
                    d.postMessage(e, "https://oauth.yandex.ru")
                }
            }

            function rh(a, c) {
                void 0 === c && (c = !0);
                var b = bc("canvas", a.document);
                if (b && (b = Jc(b))) {
                    var d = je(a) || Kc(a),
                        e = d[0];
                    d = d[1];
                    if (.3 <= sh(a, b, {
                            h: d,
                            w: e
                        }) / (d * e)) {
                        G(a).D("hc", 1);
                        return
                    }
                }
                c && O(a, C([a, !1], rh), 3E3)
            }

            function th(a) {
                return {
                    N: function(c, b) {
                        wm(a).then(function(d) {
                            c.J || (c.J = {});
                            c.J.uah = d;
                            b()
                        }, b)
                    }
                }
            }

            function xm(a) {
                var c =
                    J(function(b, d) {
                        var e = d[1],
                            f = zm(a[d[0]]);
                        f && b.push("" + e + "\n" + f);
                        return b
                    }, [], Ma(Am));
                return I("\n", c)
            }

            function Bm(a) {
                return "che\n" + a
            }

            function zm(a) {
                return ka(a) ? a : ca(a) ? I(",", B(function(c) {
                    return '"' + c.brand + '";v="' + c.version + '"'
                }, a)) : la(a) ? "" : a ? "?1" : "?0"
            }

            function Cm(a, c) {
                var b = Dm(a),
                    d = [Em(a) || Fm(a)];
                uh(a) && d.push(b);
                var e = ia(a);
                b = Pa(a);
                var f = b.C("synced", {});
                d = fa(function(g) {
                    if (c[g]) {
                        var h = (f[g] || 1) + 1440 < e(pb);
                        h && delete f[g];
                        return h
                    }
                }, d);
                b.D("synced", f);
                return B(function(g) {
                        return {
                            Li: c[g],
                            Yh: g
                        }
                    },
                    d)
            }

            function Fm(a) {
                a = Gm(a);
                return Hm[a] || a
            }

            function Dm(a) {
                a = vh(a);
                return Im[a] || "ru"
            }

            function Jm(a, c, b, d) {
                if (!b.K || fe(c.ca)) d();
                else {
                    var e = ke(a),
                        f = u(e, Km),
                        g = Lc(a, ""),
                        h = function() {
                            var r = I(",", B(Lm(hf), le(e)));
                            r = "" + r + Mm(r, g);
                            me(b, "gdpr", r);
                            d()
                        };
                    if (c.dj) f("31"), h();
                    else if (3 === c.id) h();
                    else {
                        var k = G(a),
                            l = k.C("f1");
                        if (l) l(h);
                        else if (l = le(e), Ya(pc(hf), l)) h();
                        else if (g.C("yandex_login")) f("13"), g.D("gdpr", Mc, 525600), h();
                        else {
                            l = ne(a);
                            var m = R(a);
                            var p = /(^|\w+\.)yango(\.yandex)?\.com$/.test(m.hostname) ? {
                                url: "https://yastatic.net/s3/taxi-front/yango-gdpr-popup/",
                                version: 2,
                                qf: Nm,
                                yf: "_inversed_buttons"
                            } : void 0;
                            l || p ? (l = g.C("gdpr"), K(l, qc) ? (f(l === jf ? "12" : "3"), h()) : kf(a) || Om(a) ? (f("17"), h()) : Pm(a).then(P, E).then(function(r) {
                                r ? (f("28"), h()) : (wh(h), k.D("f1", wh), (0, lf[0])(a).then(Q("params.eu")).then(function(q) {
                                    if (q || cb(m.href, "yagdprcheck=1") || g.C("yaGdprCheck")) {
                                        g.D("gdpr_popup", jf);
                                        Qm(a, c);
                                        if (jb(a)) return Rm(a, f, c);
                                        var t = xh(a, e);
                                        if (t) return q = Sm(a, f, t, c, p), q.then(C([a, c], Tm)), q
                                    }
                                    q || f("8");
                                    return L.resolve({
                                        value: Mc,
                                        Md: !0
                                    })
                                }).then(function(q) {
                                    g.Fb("gdpr_popup");
                                    if (q) {
                                        var t = q.value;
                                        q = q.Md;
                                        K(t, qc) && g.D("gdpr", t, q ? void 0 : 525600)
                                    }
                                    t = cc(yh, ja);
                                    kd(a, t, 20)(Qa(D(a, "gdr"), E));
                                    k.D("f1", ja)
                                })["catch"](D(a, "gdp.a")))
                            })) : (f("14"), h())
                        }
                    }
                }
            }

            function Tm(a, c) {
                if (ne(a)) {
                    var b = ke(a),
                        d = za(a, c);
                    d = d && d.params;
                    b = B(u(Um, n), le(b));
                    d && b.length && d("gdpr", ua(b))
                }
            }

            function Rm(a, c, b) {
                var d = oe(a, b);
                return new L(function(e) {
                    var f;
                    if (d) {
                        var g = d.$,
                            h = v(u("4", c), u(null, e)),
                            k = O(a, h, 2E3, "gdp.f.t");
                        d.Sf((f = {}, f.type = "isYandex", f)).then(function(l) {
                            l.isYandex ? (c("5"), g.F(zh, function(m) {
                                    e({
                                        value: Ah(m[1].type)
                                    })
                                })) :
                                (c("6"), e(null))
                        })["catch"](h).then(C([a, k], ha))
                    } else e({
                        value: jf,
                        Md: !0
                    })
                })
            }

            function Qm(a, c) {
                var b = oe(a, c);
                b && b.$.F(["isYandex"], function() {
                    var d;
                    return d = {
                        type: "isYandex"
                    }, d.isYandex = ne(a), d
                });
                return b
            }

            function Vm(a, c, b) {
                a = b || vh(a);
                return K(a, c) ? a : "en"
            }

            function Ah(a) {
                if (K(a, ["GDPR-ok-view-default", "GDPR-ok-view-detailed"])) return Mc;
                a = a.replace("GDPR-ok-view-detailed-", "");
                return K(a, qc) ? a : Mc
            }

            function Bh(a, c, b) {
                var d = n(a, "AppMetricaInitializer"),
                    e = n(d, "init");
                if (e) try {
                    H(e, d)(yb(a, c))
                } catch (f) {} else Ch =
                    O(a, C([a, c, 2 * b], Bh), b, "ai.d");
                return function() {
                    return ha(a, Ch)
                }
            }

            function Dh(a, c, b, d) {
                var e, f, g, h = b.Sh,
                    k = b.Nh;
                b = b.isTrusted;
                a = mf(a, k);
                k = k.readOnly;
                d = (e = {}, e.fi = nf((f = {}, f.a = h ? 1 : 0, f.b = a, f.c = d || 0, f.d = k ? 1 : null, f)).Ha(), e);
                la(b) || (d.ite = zb(b));
                c.params((g = {}, g.__ym = d, g))
            }

            function Eh(a) {
                var c = n(a, "target");
                if (c) {
                    var b = n(c, "value");
                    if ((b = db(b)) && !(100 <= Ta(b))) {
                        var d = Tb(b),
                            e = 0 < ib(b, "@"),
                            f = "tel" === n(c, "type") || !e && Ta(d);
                        if (e || f) {
                            if (f) {
                                if (Wm(b)) return;
                                var g = b[0],
                                    h = d[0];
                                if (g !== h && "+" !== g) return;
                                var k = b[1];
                                if ("+" === g && k !== h) return;
                                b = b[Ta(b) - 1];
                                g = d[Ta(d) - 1];
                                if (b !== g) return;
                                b = d
                            }
                            d = e ? 5 : 11;
                            g = e ? 100 : 16;
                            if (!(Ta(b) < d || Ta(b) > g)) return a = n(a, "isTrusted"), {
                                Nh: c,
                                Sh: e,
                                zj: f,
                                Oh: b,
                                isTrusted: a
                            }
                        }
                    }
                }
            }

            function Xm(a) {
                var c = n(a, "speechSynthesis.getVoices");
                if (c) return a = H(c, a.speechSynthesis), rc(function(b) {
                    return B(u(b, n), Ym)
                }, a())
            }

            function Zm(a, c, b) {
                return I("x", B(v(P, Da("concat", "" + a), u(b, n)), c))
            }

            function $m(a, c) {
                var b = c.Eg;
                if (!an(a, b)) return "";
                var d = [];
                a: {
                    var e = bn(a, b);
                    try {
                        var f = C(e, v)()();
                        break a
                    } catch (F) {
                        if ("ccf" ===
                            F.message) {
                            f = null;
                            break a
                        }
                        Ua(F)
                    }
                    f = void 0
                }
                if (Va(f)) var g = "";
                else try {
                    g = f.toDataURL()
                } catch (F) {
                    g = ""
                }(f = g) && d.push(f);
                var h = b.getContextAttributes();
                try {
                    var k = na(b.getSupportedExtensions, "getSupportedExtensions") ? b.getSupportedExtensions() || [] : []
                } catch (F) {
                    k = []
                }
                k = I(";", k);
                f = of (b.getParameter(b.ALIASED_LINE_WIDTH_RANGE), b);
                e = of (b.getParameter(b.ALIASED_POINT_SIZE_RANGE), b);
                g = b.getParameter(b.ALPHA_BITS);
                h = h && h.antialias ? "yes" : "no";
                var l = b.getParameter(b.BLUE_BITS),
                    m = b.getParameter(b.DEPTH_BITS),
                    p = b.getParameter(b.GREEN_BITS),
                    r = b.getExtension("EXT_texture_filter_anisotropic") || b.getExtension("WEBKIT_EXT_texture_filter_anisotropic") || b.getExtension("MOZ_EXT_texture_filter_anisotropic");
                if (r) {
                    var q = b.getParameter(r.MAX_TEXTURE_MAX_ANISOTROPY_EXT);
                    0 === q && (q = 2)
                }
                q = {
                    pj: k,
                    "webgl aliased line width range": f,
                    "webgl aliased point size range": e,
                    "webgl alpha bits": g,
                    "webgl antialiasing": h,
                    "webgl blue bits": l,
                    "webgl depth bits": m,
                    "webgl green bits": p,
                    "webgl max anisotropy": r ? q : null,
                    "webgl max combined texture image units": b.getParameter(b.MAX_COMBINED_TEXTURE_IMAGE_UNITS),
                    "webgl max cube map texture size": b.getParameter(b.MAX_CUBE_MAP_TEXTURE_SIZE),
                    "webgl max fragment uniform vectors": b.getParameter(b.MAX_FRAGMENT_UNIFORM_VECTORS),
                    "webgl max render buffer size": b.getParameter(b.MAX_RENDERBUFFER_SIZE),
                    "webgl max texture image units": b.getParameter(b.MAX_TEXTURE_IMAGE_UNITS),
                    "webgl max texture size": b.getParameter(b.MAX_TEXTURE_SIZE),
                    "webgl max varying vectors": b.getParameter(b.MAX_VARYING_VECTORS),
                    "webgl max vertex attribs": b.getParameter(b.MAX_VERTEX_ATTRIBS),
                    "webgl max vertex texture image units": b.getParameter(b.MAX_VERTEX_TEXTURE_IMAGE_UNITS),
                    "webgl max vertex uniform vectors": b.getParameter(b.MAX_VERTEX_UNIFORM_VECTORS),
                    "webgl max viewport dims": of (b.getParameter(b.MAX_VIEWPORT_DIMS), b),
                    "webgl red bits": b.getParameter(b.RED_BITS),
                    "webgl renderer": b.getParameter(b.RENDERER),
                    "webgl shading language version": b.getParameter(b.SHADING_LANGUAGE_VERSION),
                    "webgl stencil bits": b.getParameter(b.STENCIL_BITS),
                    "webgl vendor": b.getParameter(b.VENDOR),
                    "webgl version": b.getParameter(b.VERSION)
                };
                pf(d, q, ": ");
                a: {
                    try {
                        var t = b.getExtension("WEBGL_debug_renderer_info");
                        if (t) {
                            var x = {
                                "webgl unmasked vendor": b.getParameter(t.UNMASKED_VENDOR_WEBGL),
                                "webgl unmasked renderer": b.getParameter(t.UNMASKED_RENDERER_WEBGL)
                            };
                            break a
                        }
                    } catch (F) {}
                    x = {}
                }
                pf(d, x);
                if (!b.getShaderPrecisionFormat) return I("~", d);
                pf(d, cn(b));
                return I("~", d)
            }

            function pf(a, c, b) {
                void 0 === b && (b = ":");
                y(function(d) {
                    return a.push("" + d[0] + b + d[1])
                }, Ma(c))
            }

            function dn(a, c, b, d) {
                c = d.C("cc");
                d = C(["cc", ""], d.D);
                if (c) {
                    var e = c.split("&");
                    c = e[0];
                    if ((e = (e = e[1]) && Ga(e)) && 1440 < ia(a)(pb) - e) return d();
                    b.D("cc", c)
                } else Aa(0)(c) ||
                    d()
            }

            function en(a, c, b, d) {
                return qa(c, function(e) {
                    if (!qf(e) && !ld(a))
                        if (e = d.C("zzlc"), W(e) || Va(e) || "na" === e) {
                            var f = eb(a);
                            if (f && (e = dc(a))) {
                                var g = f("iframe");
                                z(g.style, {
                                    display: "none",
                                    width: "1px",
                                    height: "1px",
                                    visibility: "hidden"
                                });
                                f = rf(a, 68);
                                var h = sf(a, 79);
                                g.src = "https://mc.yandex." + (f || h ? "md" : "ru") + Fh("L21ldHJpa2EvenpsYy5odG1s");
                                e.appendChild(g);
                                var k = 0,
                                    l = da(a).F(a, ["message"], D(a, "zz.m", function(m) {
                                        (m = n(m, "data")) && m.substr && "__ym__zz" === m.substr(0, 8) && (sc(g), m = m.substr(8), d.D("zzlc", m), b.D("zzlc",
                                            m), l(), ha(a, k))
                                    }));
                                k = O(a, v(l, u(g, sc)), 3E3)
                            }
                        } else b.D("zzlc", e)
                })
            }

            function fn(a, c, b) {
                var d, e;
                c = qb(u(a, n), gn);
                c = W(c) ? null : n(a, c);
                if (n(a, "navigator.onLine") && c && c && n(c, "prototype.constructor.name")) {
                    var f = new c((d = {}, d.iceServers = [], d));
                    a = n(f, "createDataChannel");
                    T(a) && (H(a, f, "y.metrika")(), a = n(f, "createOffer"), T(a) && !a.length && (a = H(a, f)(), d = n(a, "then"), T(d) && H(d, a, function(g) {
                        var h = n(f, "setLocalDescription");
                        T(h) && H(h, f, g, E, E)()
                    })(), z(f, (e = {}, e.onicecandidate = function() {
                        var g, h = n(f, "close");
                        if (T(h)) {
                            h =
                                H(h, f);
                            try {
                                var k = (g = n(f, "localDescription.sdp")) && g.match(/c=IN\s[\w\d]+\s([\w\d:.]+)/)
                            } catch (l) {
                                f.onicecandidate = E;
                                "closed" !== f.iceConnectionState && h();
                                return
                            }
                            k && 0 < k.length && (g = ec(k[1]), b.D("pp", g));
                            f.onicecandidate = E;
                            h()
                        }
                    }, e))))
                }
            }

            function hn(a, c, b) {
                var d, e = md(a, c);
                if (e) {
                    e.$.F(["gpu-get"], function() {
                        var h;
                        return h = {}, h.type = "gpu-get", h.pu = b.C("pu"), h
                    });
                    var f = n(a, "opener");
                    if (f) {
                        var g = O(a, C([a, c, b], Gh), 200, "pu.m");
                        e.ne(f, (d = {}, d.type = "gpu-get", d), function(h, k) {
                            var l = n(k, "pu");
                            l && (ha(a, g), b.D("pu",
                                l))
                        })
                    } else Gh(a, c, b)
                }
            }

            function Gh(a, c, b) {
                var d = n(a, "location.host");
                a = nd(a, c);
                b.D("pu", "" + ec(d) + a)
            }

            function Hh(a, c, b) {
                c = Lc(a, void 0, c);
                c = Ih(a, c.C("phc_settings") || "");
                var d = n(c, "clientId"),
                    e = n(c, "orderId"),
                    f = n(c, "service_id"),
                    g = n(c, "phones") || [];
                return d && e && g && f ? jn(a, b.nc, {
                    dg: kn
                })(g).then(function(h) {
                    return ln(b, {
                        Cb: d,
                        Pb: e,
                        Vf: f
                    }, h.ja, g, h.Aa)
                })["catch"](E) : L.resolve()
            }

            function kn(a, c, b) {
                a = mn(b.Sb);
                if ("href" === b.je) {
                    var d = b.sb;
                    c = d.href;
                    b = c.replace(a, b.bb);
                    if (c !== b) return d.href = b, !0
                } else if ((a = null ===
                        (d = b.sb.textContent) || void 0 === d ? void 0 : d.replace(a, b.bb)) && a !== b.sb.textContent) return b.sb.textContent = a, !0;
                return !1
            }

            function ln(a, c, b, d, e) {
                var f;
                c.Cb && c.Pb && (c.Cb === a.Cb && c.Pb === a.Pb || z(a, c, {
                    ja: {},
                    gb: !0
                }), 0 < e && ra(a.Aa, [e]), y(function(g) {
                    var h, k, l = g[0];
                    g = g[1];
                    var m = +(a.ja[l] && a.ja[l][g] ? a.ja[l][g] : 0);
                    z(a.ja, (h = {}, h[l] = (k = {}, k[g] = m, k), h))
                }, d), y(function(g) {
                    var h, k, l = g[0];
                    g = g[1];
                    var m = 1 + (a.ja[l] ? a.ja[l][g] : 0);
                    z(a.ja, (h = {}, h[l] = (k = {}, k[g] = m, k), h))
                }, b), a.mf && (a.gb || b.length) && ((c = za(a.l, a.nc)) && c.params("__ym",
                    "phc", (f = {}, f.clientId = a.Cb, f.orderId = a.Pb, f.service_id = a.Vf, f.phones = a.ja, f.performance = a.Aa, f)), a.gb = !1))
            }

            function nn(a) {
                a = eb(a);
                if (!a) return "";
                a = a("video");
                try {
                    var c = Da("canPlayType", a),
                        b = rc(function(d) {
                            return B(v(P, Da("concat", d + "; codecs=")), on)
                        }, Jh);
                    return B(c, Jh.concat(b))
                } catch (d) {
                    return "canPlayType"
                }
            }

            function pn(a) {
                var c = n(a, "matchMedia");
                if (c && Ia("matchMedia", c)) {
                    var b = Da("matchMedia", a);
                    return J(function(d, e) {
                        d[e] = b("(" + e + ")");
                        return d
                    }, {}, qn)
                }
            }

            function cn(a) {
                return J(function(c, b) {
                    var d =
                        b[0],
                        e = b[1];
                    c[d + " precision"] = n(e, "precision") || "n";
                    c[d + " precision rangeMin"] = n(e, "rangeMin") || "n";
                    c[d + " precision rangeMax"] = n(e, "rangeMax") || "n";
                    return c
                }, {}, [
                    ["webgl vertex shader high float", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.HIGH_FLOAT)],
                    ["webgl vertex shader medium", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.MEDIUM_FLOAT)],
                    ["webgl vertex shader low float", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.LOW_FLOAT)],
                    ["webgl fragment shader high float", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER,
                        a.HIGH_FLOAT)],
                    ["webgl fragment shader medium float", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.MEDIUM_FLOAT)],
                    ["webgl fragment shader low float", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.LOW_FLOAT)],
                    ["webgl vertex shader high int", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.HIGH_INT)],
                    ["webgl vertex shader medium int", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.MEDIUM_INT)],
                    ["webgl vertex shader low int", a.getShaderPrecisionFormat(a.VERTEX_SHADER, a.LOW_INT)],
                    ["webgl fragment shader high int",
                        a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.HIGH_INT)
                    ],
                    ["webgl fragment shader medium int", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.MEDIUM_INT)],
                    ["webgl fragment shader low int precision", a.getShaderPrecisionFormat(a.FRAGMENT_SHADER, a.LOW_INT)]
                ])
            }

            function bn(a, c) {
                return [function() {
                    var b = c.createBuffer();
                    b && c.getParameter && Ia("getParameter", c.getParameter) || tf();
                    c.bindBuffer(c.ARRAY_BUFFER, b);
                    var d = new a.Float32Array(rn);
                    c.bufferData(c.ARRAY_BUFFER, d, c.STATIC_DRAW);
                    b.Uh = 3;
                    b.ei = 3;
                    d = c.createProgram();
                    var e = c.createShader(c.VERTEX_SHADER);
                    d && e || tf();
                    return {
                        fe: d,
                        cj: e,
                        bj: b
                    }
                }, function(b) {
                    var d = b.fe,
                        e = b.cj;
                    c.shaderSource(e, "attribute vec2 attrVertex;varying vec2 varyinTexCoordinate;uniform vec2 uniformOffset;void main(){varyinTexCoordinate=attrVertex+uniformOffset;gl_Position=vec4(attrVertex,0,1);}");
                    c.compileShader(e);
                    c.attachShader(d, e);
                    (d = c.createShader(c.FRAGMENT_SHADER)) || tf();
                    return z(b, {
                        jh: d
                    })
                }, function(b) {
                    var d = b.fe,
                        e = b.jh;
                    c.shaderSource(e, "precision mediump float;varying vec2 varyinTexCoordinate;void main() {gl_FragColor=vec4(varyinTexCoordinate,0,1);}");
                    c.compileShader(e);
                    c.attachShader(d, e);
                    c.linkProgram(d);
                    c.useProgram(d);
                    return b
                }, function(b) {
                    var d = b.fe;
                    b = b.bj;
                    d.aj = c.getAttribLocation(d, "attrVertex");
                    d.ii = c.getUniformLocation(d, "uniformOffset");
                    c.enableVertexAttribArray(d.Kj);
                    c.vertexAttribPointer(d.aj, b.Uh, c.FLOAT, !1, 0, 0);
                    c.uniform2f(d.ii, 1, 1);
                    c.drawArrays(c.TRIANGLE_STRIP, 0, b.ei);
                    return c.canvas
                }]
            }

            function an(a, c) {
                if (!T(a.Float32Array)) return !1;
                var b = n(c, "canvas");
                if (!b || !Ia("toDataUrl", b.toDataURL)) return !1;
                try {
                    c.createBuffer()
                } catch (d) {
                    return !1
                }
                return !0
            }

            function of (a, c) {
                c.clearColor(0, 0, 0, 1);
                c.enable(c.DEPTH_TEST);
                c.depthFunc(c.LEQUAL);
                c.clear(c.COLOR_BUFFER_BIT | c.DEPTH_BUFFER_BIT);
                return "[" + n(a, "0") + ", " + n(a, "1") + "]"
            }

            function sn(a, c) {
                if (n(c, "settings.ins")) {
                    var b = G(a);
                    if (!b.C("scip")) {
                        var d = Pa(a),
                            e = ia(a)(pb),
                            f = uf(d.C("sci"));
                        if (!(f && 1440 >= e - f)) {
                            f = va(a, "ci");
                            var g = ["sync.cook.int"],
                                h = function(l) {
                                    l = b.C("scip", "") + l;
                                    b.D("scip", l)
                                },
                                k = u("a", h);
                            b.D("scip", "0");
                            return f({
                                ba: {
                                    ha: g,
                                    Pa: 3E3,
                                    zb: !0
                                }
                            }, ["https://an.yandex.ru/sync_cookie"]).then(function(l) {
                                l =
                                    n(l.Sc, "CookieMatchUrls");
                                if (ca(l) && Ta(l)) {
                                    h("1");
                                    var m = va(a, "c");
                                    l = B(function(p, r) {
                                        return m({
                                            ba: {
                                                ha: g,
                                                Pa: 3E3
                                            }
                                        }, ["https://" + p])["catch"](v(u("b", h), u("" + r, h)))
                                    }, fa(ka, l));
                                    return L.all(l)
                                }
                                k()
                            }, k).then(function() {
                                var l = b.C("scip");
                                !l || cb(l, "a") || cb(l, "b") || (d.D("sci", e), h("2"))
                            }, E)
                        }
                    }
                }
            }

            function Kh(a) {
                return {
                    N: function(c, b) {
                        if (!c.K) return b();
                        var d = G(a).C("fid");
                        !Lh && d && (me(c, "fid", d), Lh = !0);
                        return b()
                    }
                }
            }

            function tn(a, c) {
                var b = a.document;
                if (K(b.readyState, ["interactive", "complete"])) Sb(a, c);
                else {
                    var d =
                        da(a),
                        e = d.F,
                        f = d.Zb,
                        g = function() {
                            f(b, ["DOMContentLoaded"], g);
                            f(a, ["load"], g);
                            c()
                        };
                    e(b, ["DOMContentLoaded"], g);
                    e(a, ["load"], g)
                }
            }

            function vf(a) {
                return {
                    N: function(c, b) {
                        var d = c.K;
                        if (d) {
                            var e = G(a).C("adBlockEnabled");
                            e && d.D("adb", e)
                        }
                        b()
                    }
                }
            }

            function un(a) {
                var c = D(a, "i.clch", vn);
                da(a).F(a.document, ["click"], u(a, c), {
                    passive: !1
                });
                return function(b) {
                    var d = Ea.Ra,
                        e = a.Ya[Ea.kc],
                        f = !!e._informer;
                    e._informer = z({
                        domain: "informer.yandex.ru"
                    }, b);
                    f || tc(a, {
                        src: d + "//informer.yandex.ru/metrika/informer.js"
                    })
                }
            }

            function wn(a,
                c) {
                var b = Pa(a);
                if ("" === b.C("cc")) {
                    var d = u("cc", b.D);
                    d(0);
                    var e = ia(a),
                        f = G(a);
                    f = v(Q(xn({
                        Sc: 1
                    }) + ".c"), od(function(g) {
                        d(g + "&" + e(pb))
                    }), u("cc", f.D));
                    va(a, "6", c)({
                        ba: {
                            zb: !0,
                            He: !1
                        }
                    }, ["https://mc.yandex.md/cc"]).then(f)["catch"](v(od(function() {
                        var g = e(pb);
                        b.D("cc", "&" + g)
                    }), D(a, "cc")))
                }
            }

            function pe(a, c) {
                if (!c) return !1;
                var b = R(a);
                return (new RegExp(c)).test("" + b.pathname + b.hash + b.search)
            }

            function yn(a, c) {
                return qa(c, function(b) {
                    var d = n(b, "settings.dr");
                    return {
                        Sg: zn(a, d),
                        isEnabled: n(b, "settings.auto_goals")
                    }
                })
            }

            function An(a, c, b, d, e) {
                b = wf(a.document.body, b);
                d = wf(a.document.body, d);
                K(e.target, [b, d]) && xf(a, c)
            }

            function Mh(a, c, b, d) {
                (b = Bn(a, d, b)) && xf(a, c, b)
            }

            function Nh(a, c) {
                var b = Oh(a, c);
                return Cn(a, b)
            }

            function Oh(a, c) {
                var b = wf(a.document.body, c);
                return b ? Dn(a, b) : ""
            }

            function xf(a, c, b) {
                if (c = za(a, c)) a = Nc(["dr", b || "" + Wa(a, 10, 99)]), c.params(Nc(["__ym", a]))
            }

            function wf(a, c) {
                var b = null;
                try {
                    b = c ? bc(c, a) : b
                } catch (d) {}
                return b
            }

            function Ph(a) {
                a = Ba(Fh(a));
                return B(function(c) {
                    c = c.charCodeAt(0).toString(2);
                    return Qh("0", 8,
                        c)
                }, a)
            }

            function Dn(a, c) {
                if (!c) return "";
                var b = [],
                    d = n(a, "document");
                yf(a, c, function(e) {
                    if (e.nodeType === d.TEXT_NODE) var f = e.textContent;
                    else e instanceof a.HTMLImageElement ? f = e.alt : e instanceof a.HTMLInputElement && (f = e.value);
                    (f = f && db(f)) && b.push(f)
                });
                return 0 === b.length ? "" : I(" ", b)
            }

            function En(a, c, b) {
                a = Ja(b);
                b = a[1];
                "track" === a[0] && c({
                    version: "0",
                    sc: b
                })
            }

            function Fn(a, c, b) {
                if (b) {
                    var d = b.version;
                    (b = n(Gn, d + "." + b.sc)) && (c && K(b, Hn) || a("ym-" + b + "-" + d))
                }
            }

            function In(a, c, b) {
                if ("rt" === b) return "https://" + Rh(a,
                    c) + ".mc.yandex.ru/watch/3/1";
                if ("mf" === b) {
                    b = R(a);
                    b = qe(b.protocol + "//" + b.hostname + b.pathname);
                    c = nd(a, c);
                    var d = "";
                    do d += Wa(a); while (d.length < c.length);
                    d = d.slice(0, c.length);
                    a = "";
                    for (var e = 0; e < c.length; e += 1) a += (c.charCodeAt(e) + d.charCodeAt(e) - 96) % 10;
                    a = [d, a];
                    return "https://adstat.yandex.ru/track?service=metrika&id=" + a[1] + "&mask=" + a[0] + "&ref=" + b
                }
            }

            function Jn(a, c, b) {
                var d, e = zf(c).Rb;
                return va(a, "pi", c)({
                    K: Ka((d = {}, d[e] = 1, d))
                }, [b])
            }

            function Kn(a, c, b) {
                return new L(function(d, e) {
                    if (Af(a, Oc, "isp")) {
                        var f = E,
                            g = function(h) {
                                ("1" === h ? d : e)();
                                f();
                                Bf(Oc, "isp")
                            };
                        f = da(a).F(a, ["message"], C([b, g], D(a, "isp.stat.m", Ln)));
                        O(a, g, 1500)
                    } else e()
                })
            }

            function Ln(a, c, b) {
                var d = n(b, "data");
                if (ka(d)) {
                    var e = d.split("*");
                    d = e[0];
                    var f = e[1];
                    e = e[2];
                    "sc.frame" === d && b.source ? b.source.postMessage("sc.images*" + a, "*") : "sc.image" === d && f === a && c(e)
                }
            }

            function Mn(a, c) {
                var b = Pa(a),
                    d = "wv2rf:" + M(c),
                    e = c.ic,
                    f = Cf(a),
                    g = b.C(d),
                    h = c.Ui;
                return W(f) || Va(g) ? Fa(function(k, l) {
                    qa(c, function(m) {
                        var p = !!n(m, "settings.webvisor.forms");
                        p = !n(m, "settings.x3") &&
                            p;
                        f = Cf(a) || n(m, "settings.eu");
                        b.D(d, zb(p));
                        l({
                            ic: e,
                            Ld: !!f,
                            Bf: p,
                            fg: h
                        })
                    })
                }) : Df({
                    ic: e,
                    Ld: f,
                    Bf: !!Ga(g),
                    fg: h
                })
            }

            function Nn() {
                var a = J(function(c, b) {
                    c[b[0]] = {
                        gd: 0,
                        Cg: 1 / b[1]
                    };
                    return c
                }, {}, [
                    ["blur", .0034],
                    ["change", .0155],
                    ["click", .01095],
                    ["deviceRotation", 2E-4],
                    ["focus", .0061],
                    ["mousemove", .5132],
                    ["scroll", .4795],
                    ["selection", .0109],
                    ["touchcancel", 2E-4],
                    ["touchend", .0265],
                    ["touchforcechange", .0233],
                    ["touchmove", .1442],
                    ["touchstart", .027],
                    ["zoom", .0014]
                ]);
                return {
                    yg: function(c) {
                        if (c.length) return {
                            type: "activity",
                            data: J(function(b, d) {
                                var e = a[d];
                                return Math.round(b + e.gd * e.Cg)
                            }, 0, ea(a))
                        }
                    },
                    ji: function(c) {
                        c && (c = a[c.data.type || c.event]) && (c.gd += 1)
                    }
                }
            }

            function On(a) {
                return {
                    lh: function() {
                        var c = a.document.querySelector("base[href]");
                        return c ? c.getAttribute("href") : null
                    },
                    nh: function() {
                        if (a.document.doctype) {
                            var c = z({
                                    name: "html",
                                    publicId: "",
                                    systemId: ""
                                }, a.document.doctype),
                                b = c.publicId,
                                d = c.systemId;
                            return "<!DOCTYPE " + I("", [c.name, b ? ' PUBLIC "' + b + '"' : "", !b && d ? " SYSTEM" : "", d ? ' "' + d + '"' : ""]) + ">"
                        }
                        return null
                    }
                }
            }

            function Pn(a,
                c, b) {
                var d = pd(a),
                    e = da(a),
                    f = jb(a),
                    g = c.zd(),
                    h = !n(a, "postMessage") || f && !n(a, "parent.postMessage"),
                    k = u(d, P);
                if (h) {
                    if (!g) return O(a, H(d.T, d, "i", {
                        va: !1
                    }), 10), {
                        yd: k,
                        Of: E,
                        stop: E
                    };
                    Ua(Ra())
                }
                d.F(["sr"], function(q) {
                    var t, x = Sh(a, q.source);
                    x && Ef(a, q.source, (t = {}, t.type = "\u043d", t.frameId = c.sa().Z(x), t))
                });
                d.F(["sd"], function(q) {
                    var t = q.data;
                    q = q.source;
                    (a === q || Sh(a, q)) && d.T("sdr", {
                        data: t.data,
                        frameId: t.frameId
                    })
                });
                if (f && !g) {
                    var l = !1,
                        m = 0,
                        p = function() {
                            var q;
                            Ef(a, a.parent, (q = {}, q.type = "sr", q));
                            m = O(a, p, 100, "if.i")
                        };
                    p();
                    var r = function(q) {
                        d.ga(["\u043d"], r);
                        ha(a, m);
                        var t = Pc(a, q.origin).host;
                        l || q.source !== a.parent || !q.data.frameId || "about:blank" !== R(a).host && !K(t, b) || (l = !0, d.T("i", {
                            frameId: q.data.frameId,
                            va: !0
                        }))
                    };
                    d.F(["\u043d"], r);
                    O(a, function() {
                        d.ga(["\u043d"], r);
                        ha(a, m);
                        l || (l = !0, d.T("i", {
                            va: !1
                        }))
                    }, 2E3, "if.r")
                }
                e = e.F(a, ["message"], function(q) {
                    var t = xb(a, q.data);
                    t && t.type && K(t.type, Qn) && d.T(t.type, {
                        data: t,
                        source: q.source,
                        origin: q.origin
                    })
                });
                return {
                    yd: k,
                    Of: function(q) {
                        var t;
                        return Ef(a, a.parent, (t = {}, t.frameId =
                            c.zd(), t.data = q, t.type = "sd", t))
                    },
                    stop: e
                }
            }

            function Sh(a, c) {
                try {
                    return qb(v(Q("contentWindow"), Aa(c)), Ba(a.document.querySelectorAll("iframe")))
                } catch (b) {
                    return null
                }
            }

            function Ef(a, c, b) {
                c || Ua(Ra());
                a = yb(a, b);
                c.postMessage(a, "*")
            }

            function Th() {
                return fc() + fc() + "-" + fc() + "-" + fc() + "-" + fc() + "-" + fc() + fc() + fc()
            }

            function fc() {
                return Math.floor(65536 * (1 + Math.random())).toString(16).substring(1)
            }

            function Rn(a, c) {
                if (ka(c)) return c;
                var b = a.textContent;
                if (ka(b)) return b;
                b = a.data;
                if (ka(b)) return b;
                b = a.nodeValue;
                return ka(b) ? b : ""
            }

            function Sn(a, c, b, d, e) {
                void 0 === d && (d = {});
                void 0 === e && (e = Na(c));
                var f = z(J(function(h, k) {
                    h[k.name] = k.value;
                    return h
                }, {}, Ba(c.attributes)), d);
                z(f, Tn(c, e, f));
                var g = (d = J(function(h, k) {
                    var l = k[0],
                        m = re(a, c, l, k[1], b, e),
                        p = m.value;
                    la(p) ? delete f[l] : f[l] = p;
                    return h || m.pb
                }, !1, Ma(f))) && Jc(c);
                g && (f.width = g.width, f.height = g.height);
                return {
                    pb: d,
                    zg: f
                }
            }

            function Tn(a, c, b) {
                var d = {};
                Ff(a) ? d.value = a.value || b.value : "IMG" !== c || b.src || (d.src = "");
                return d
            }

            function re(a, c, b, d, e, f) {
                void 0 === f && (f = Na(c));
                var g = {
                    pb: !1,
                    value: d
                };
                if (Ff(c)) "value" === b ? !la(d) && "" !== d && (b = e.Ld, f = e.Bf, e = qd(a, c), f ? (b = Qc(a, c, b), a = b.qb, c = b.hb, b = b.Va, g.pb = !c && (e || a)) : (g.pb = e, b = !(c && gc("ym-record-keys", c))), b || e) && (d = "" + d, g.value = 0 < d.length ? Uh("\u2022", d.length) : "") : "checked" === b && K((c.getAttribute("type") || "").toLowerCase(), Un) ? g.value = c.checked ? "checked" : null : Vn.test(b) && Gf(a, c) && (g.value = null);
                else if ("IMG" === f && "src" === b)(e = qd(a, c)) ? (g.pb = e, g.value = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=") :
                    g.value = (c.getAttribute("srcset") ? c.currentSrc : "") || c.src;
                else if ("A" === f && "href" === b) g.value = d ? "#" : "";
                else if (K(b, ["srcset", "integrity", "crossorigin", "password"]) || 2 < b.length && 0 === ib(b, "on") || "IFRAME" === f && "src" === b || "SCRIPT" === f && K(b, ["src", "type"])) g.value = null;
                return g
            }

            function Hf(a, c, b, d) {
                void 0 === d && (d = "wv2");
                return {
                    H: function(e, f) {
                        return D(a, d + "." + b + "." + f, e, void 0, c)
                    }
                }
            }

            function Wn(a, c, b, d, e) {
                function f() {
                    l && l.stop()
                }
                if (!c.yb) return L.resolve(E);
                var g = va(a, "4", c),
                    h = {
                        K: Ka()
                    },
                    k = new Xn(a, b, function(m,
                        p, r) {
                        if (!g) return L.resolve();
                        var q = "wv-data=" + jd(m, !0),
                            t = D(a, "m.n.m.s");
                        p = {};
                        p["wv-part"] = "" + r;
                        r = m.length;
                        for (var x = 0, F = 255, U = 255, N, ma, wa; r;) {
                            N = 21 < r ? 21 : r;
                            r -= N;
                            do ma = "string" === typeof m ? m.charCodeAt(x) : m[x], x += 1, 255 < ma && (wa = ma >> 8, ma &= 255, ma ^= wa), F += ma, U += F; while (--N);
                            F = (F & 255) + (F >> 8);
                            U = (U & 255) + (U >> 8)
                        }
                        m = (F & 255) + (F >> 8) << 8 | (U & 255) + (U >> 8);
                        return g(z({}, h, {
                            ba: {
                                da: q
                            },
                            J: (p["wv-check"] = "" + (65535 === m ? 0 : m), p["wv-type"] = b.type, p)
                        }), c)["catch"](t)
                    }),
                    l = Yn(a, k, d, e);
                return qa(c, function(m) {
                    m && G(a).D("isEU", n(m,
                        "settings.eu"));
                    G(a).C("oo") || l && Vh(a, m) && l.start();
                    return f
                })
            }

            function Yn(a, c, b, d) {
                var e = a.document,
                    f = [],
                    g = da(a),
                    h = ":submit" + Math.random(),
                    k = [],
                    l = H(c.flush, c),
                    m = sa(function(q, t) {
                        D(a, "hfv." + q, function() {
                            try {
                                var x = t.type
                            } catch (F) {
                                return
                            }
                            x = K(x, d);
                            c.push(t, {
                                type: q
                            });
                            x && l()
                        })()
                    }),
                    p = D(a, "sfv", function() {
                        var q = b(a),
                            t = Zn(a);
                        y(function(x) {
                            f.push(g.F(x.target, [x.event], m(x.type)))
                        }, q);
                        y(function(x) {
                            f.push(g.F(x.target, [x.event], D(a, "hff." + x.type + "." + x.event, function(F) {
                                y(Fa({
                                    l: a,
                                    qa: F,
                                    flush: l
                                }), x.O)
                            })))
                        }, t);
                        k = Wh(a, "form", e);
                        e.attachEvent && (q = Wh(a, "form *", e), y(function(x) {
                            f.push(g.F(x, ["submit"], m("form")))
                        }, k), y(function(x) {
                            If(x) && f.push(g.F(x, ["change"], m("formInput")))
                        }, q));
                        y(function(x) {
                            var F = x.submit;
                            if (T(F) || "object" === typeof F && $n.test("" + F)) x[h] = F, x.submit = D(a, "fv", function() {
                                var U = {
                                    target: x,
                                    type: "submit"
                                };
                                m("document")(U);
                                return x[h]()
                            })
                        }, k)
                    }),
                    r = D(a, "ufv", function() {
                        y(ja, f);
                        y(function(q) {
                            q && (q.submit = q[h])
                        }, k);
                        c.flush()
                    });
                return {
                    start: p,
                    stop: r
                }
            }

            function ao(a, c) {
                var b = fa(function(e) {
                        return 0 <
                            e.O.length
                    }, c),
                    d = Xh({
                        target: a.document,
                        type: "document"
                    });
                return B(v(P, d, bo(a)), b)
            }

            function Yh(a, c) {
                var b = a.l,
                    d = [],
                    e = c.form;
                if (!c[Xa] && e) {
                    var f = e.elements;
                    e = e.length;
                    for (var g = 0; g < e; g += 1) {
                        var h = f[g];
                        se(h) && !h[Xa] && ra(d, uc(b, h))
                    }
                } else ra(d, uc(b, c));
                return d
            }

            function Jf(a) {
                if (rd) {
                    rd = !1;
                    var c = Ab(a.l),
                        b = [];
                    kb(a.l, b, 15) ? a = [] : (S(b, c), a = b);
                    return a
                }
            }

            function Zh(a) {
                if (!rd) {
                    rd = !0;
                    a = Ab(a.l);
                    var c = [];
                    Ub(c, 14);
                    S(c, a);
                    return c
                }
            }

            function co(a, c, b) {
                var d = c[Xa];
                if (d) {
                    a: {
                        var e = Ab(a),
                            f = c[Xa];
                        if (0 < f) {
                            var g = [];
                            c = Kf(a,
                                c);
                            var h = vc[f],
                                k = c[0] + "x" + c[1],
                                l = c[2] + "x" + c[3];
                            if (k !== h.xf) {
                                h.xf = k;
                                if (kb(a, g, 9)) {
                                    a = [];
                                    break a
                                }
                                S(g, e);
                                S(g, f);
                                S(g, c[0]);
                                S(g, c[1])
                            }
                            if (l !== h.size) {
                                h.size = l;
                                if (kb(a, g, 10)) {
                                    a = [];
                                    break a
                                }
                                S(g, e);
                                S(g, f);
                                S(g, c[2]);
                                S(g, c[3])
                            }
                            if (g.length) {
                                a = g;
                                break a
                            }
                        }
                        a = []
                    }
                    ra(b, a)
                }
                return d
            }

            function Qc(a, c, b) {
                void 0 === b && (b = !1);
                if (!c) return {
                    Va: !1,
                    hb: !1,
                    qb: !1
                };
                var d = c.getAttribute("type") || c.type;
                if ("button" === d) return {
                    Va: !1,
                    hb: !1,
                    qb: !1
                };
                var e = fa($h, [c.className, c.id, c.name]),
                    f = c && gc("ym-record-keys", c);
                d = d && K(d, ai) || Ya(fb(eo),
                    e);
                var g;
                (g = d) || (g = c.placeholder, g = Ya(fb(fo), e) || $h(g) && go.test(g || ""));
                e = g;
                return {
                    Va: !f && (Lf(a, c) || e && b || e && !d && !b),
                    hb: f,
                    qb: e
                }
            }

            function Lf(a, c) {
                return Gf(a, c) || sd(a, c) ? !0 : qd(a, c)
            }

            function $h(a) {
                return !!(a && 2 < a.length)
            }

            function Ff(a) {
                try {
                    var c = Na(a);
                    if (K(c, Mf)) {
                        if ("INPUT" === c) {
                            var b = a.type;
                            return !b || K(b.toLocaleLowerCase(), ho)
                        }
                        return !0
                    }
                } catch (d) {}
                return !1
            }

            function bi(a, c) {
                return c && gc("(ym-disable-submit|-metrika-noform)", c)
            }

            function io(a, c) {
                return I("", B(function(b) {
                    return a.isNaN(b) ? jo.test(b) ?
                        (b = b.toUpperCase() === b ? ko : lo, String.fromCharCode(Wa(a, b[0], b[1]))) : b : "" + Wa(a, 0, 9)
                }, c.split("")))
            }

            function qd(a, c) {
                if (la(c)) return !1;
                if (Nf(c)) {
                    var b = c.parentNode;
                    return (la(b) ? 0 : 11 === b.nodeType) ? !1 : qd(a, c.parentNode)
                }
                b = ci(a);
                if (!b) return !1;
                var d = b.call(c, ".ym-hide-content,.ym-hide-content *");
                return d && b.call(c, ".ym-show-content,.ym-hide-content .ym-show-content *") ? !1 : d
            }

            function Vh(a, c) {
                var b = wc(a),
                    d = b.C("visorc");
                K(d, ["w", "b"]) || (d = "");
                di(a) && ei(a, te, "visorc") && !mo.test(lb(a) || "") || (d = "b");
                var e =
                    n(c, "settings.webvisor.recp");
                if (!a.isFinite(e) || 0 > e || 1 < e) d = "w";
                d || (d = G(a).C("hitId") % 1E4 / 1E4 < e ? "w" : "b");
                b.D("visorc", d, 30);
                return "w" === d
            }

            function no(a, c) {
                return {
                    N: function(b, d) {
                        b.K.Wb("we", Lb(c.yb));
                        fi(a, c, b, "rn");
                        d()
                    }
                }
            }

            function gi(a, c, b) {
                if (hi.isEnabled(a)) return new hi(a, c);
                if (ii.isEnabled(a)) return new ii(a, b)
            }

            function ji(a, c) {
                var b = c[1][3],
                    d = 0,
                    e = new a.Uint8Array(c[0]);
                return cc([b], function(f, g) {
                    if (!f) return e;
                    f[0](a, f[2], e, d);
                    d += f[1];
                    g.push(f[3]);
                    return e
                })
            }

            function ki(a, c, b) {
                a = c(b);
                c = [E, 0,
                    0
                ];
                var d = [0, c, c, void 0];
                return cc(a, function(e, f) {
                    var g = e[0],
                        h = e[1],
                        k = e[2];
                    if (0 === g) return k(d, h), d;
                    if (void 0 === h || null === h) return d;
                    var l = g >> 3;
                    if (g & 1) xc(d, X(l)), h = k(h), l & 2 && xc(d, X(h[1])), xc(d, h);
                    else if (g & 4)
                        for (g = h.length - 1; 0 <= g;) {
                            var m = k(h[g]);
                            m.push([0, 0, Of]);
                            m.push([0, X(l), xc]);
                            m.unshift([0, 0, Pf]);
                            ra(f, m);
                            --g
                        } else if (g & 2) {
                            k = e[2];
                            var p = e[3],
                                r = e[4],
                                q = e[5],
                                t = ea(h);
                            for (g = t.length - 1; 0 <= g;) m = t[g], m = [
                                [0, 0, Pf],
                                [r, h[m], q],
                                [k, m, p],
                                [0, 0, Of],
                                [0, X(l), xc]
                            ], ra(f, m), --g
                        } else m = k(h), m.push([0, 0, Of]), m.push([0,
                            X(l), xc
                        ]), m.unshift([0, 0, Pf]), ra(f, m);
                    return d
                })
            }

            function Pf(a) {
                var c = a[1],
                    b = a[0],
                    d = a[2];
                a[3] ? (a[0] = a[3][0], a[1] = a[3][1], a[2] = a[3][2], a[3] = a[3][3]) : (a[0] = 0, a[1] = [E, 0, 0], a[2] = a[1]);
                xc(a, X(b));
                b && (a[2][3] = c[3], a[2] = d, a[0] += b)
            }

            function Of(a) {
                a[3] = [a[0], a[1], a[2], a[3]];
                a[1] = [E, 0, 0];
                a[2] = a[1];
                a[0] = 0
            }

            function xc(a, c) {
                a[0] += c[1];
                a[2][3] = c;
                a[2] = c
            }

            function li(a) {
                return [
                    [1857, a.partsTotal, X],
                    [1793, a.activity, X],
                    [1744, a.textChangeMutation, oo],
                    [1680, a.removedNodesMutation, po],
                    [1616, a.addedNodesMutation, qo],
                    [1552,
                        a.attributesChangeMutation, ro
                    ],
                    [1488, a.publishersHeader, so],
                    [1424, a.articleInfo, to],
                    [1360, a.focusEvent, uo],
                    [1296, a.fatalErrorEvent, vo],
                    [1232, a.deviceRotationEvent, wo],
                    [1168, a.keystrokesEvent, xo],
                    [1104, a.resizeEvent, yo],
                    [1040, a.zoomEvent, zo],
                    [976, a.touchEvent, Ao],
                    [912, a.changeEvent, Bo],
                    [848, a.selectionEvent, Co],
                    [784, a.scrollEvent, Do],
                    [720, a.mouseEvent, Eo],
                    [656, a.Hj, Fo],
                    [592, a.page, Go],
                    [513, a.end, yc],
                    [449, a.partNum, X],
                    [401, a.chunk, Ho],
                    [257, a.frameId, ta],
                    [193, a.event, X],
                    [129, a.type, X],
                    [65, a.stamp, X]
                ]
            }

            function Io(a) {
                return [
                    [84, a.zi, li]
                ]
            }

            function Jo(a) {
                return [
                    [129, a.position, ta],
                    [81, a.name, ba]
                ]
            }

            function Ko(a) {
                return [
                    [81, a.name, ba]
                ]
            }

            function Lo(a) {
                return [
                    [81, a.name, ba]
                ]
            }

            function to(a) {
                return [
                    [593, a.updateDate, ba],
                    [532, a.rubric, Jo],
                    [449, a.chars, ta],
                    [401, a.publicationDate, ba],
                    [340, a.topics, Ko],
                    [276, a.authors, Lo],
                    [209, a.pageTitle, ba],
                    [145, a.pageUrlCanonical, ba],
                    [65, a.id, X]
                ]
            }

            function Mo(a) {
                return [
                    [513, a.chars, ta],
                    [489, a.maxScrolled, td],
                    [385, a.involvedTime, ta],
                    [321, a.height, ta],
                    [257, a.width, ta],
                    [193,
                        a.y, ta
                    ],
                    [129, a.x, ta],
                    [65, a.id, X]
                ]
            }

            function so(a) {
                return [
                    [129, a.involvedTime, ta],
                    [84, a.articleMeta, Mo]
                ]
            }

            function uo(a) {
                return [
                    [65, a.target, ta]
                ]
            }

            function vo(a) {
                return [
                    [209, a.stack, ba],
                    [145, a.Xg, ba],
                    [81, a.code, ba]
                ]
            }

            function wo(a) {
                return [
                    [193, a.orientation, ta],
                    [129, a.height, X],
                    [65, a.width, X]
                ]
            }

            function xo(a) {
                return [
                    [84, a.keystrokes, No]
                ]
            }

            function No(a) {
                return [
                    [273, a.modifier, ba],
                    [193, a.isMeta, yc],
                    [145, a.key, ba],
                    [65, a.id, X]
                ]
            }

            function yo(a) {
                return [
                    [257, a.pageHeight, X],
                    [193, a.pageWidth, X],
                    [129, a.height, X],
                    [65, a.width, X]
                ]
            }

            function zo(a) {
                return [
                    [193, a.y, ta],
                    [129, a.x, ta],
                    [105, a.level, td]
                ]
            }

            function Ao(a) {
                return [
                    [129, a.target, ta],
                    [84, a.touches, Oo]
                ]
            }

            function Oo(a) {
                return [
                    [297, a.force, td],
                    [233, a.y, td],
                    [169, a.x, td],
                    [81, a.id, ba]
                ]
            }

            function Bo(a) {
                return [
                    [257, a.target, ta],
                    [193, a.hidden, yc],
                    [129, a.checked, yc],
                    [81, a.value, ba]
                ]
            }

            function Co(a) {
                return [
                    [257, a.endNode, X],
                    [193, a.startNode, X],
                    [129, a.end, ta],
                    [65, a.start, ta]
                ]
            }

            function Do(a) {
                return [
                    [257, a.target, ta],
                    [193, a.page, yc],
                    [129, a.y, ta],
                    [65, a.x, ta]
                ]
            }

            function Eo(a) {
                return [
                    [193,
                        a.target, ta
                    ],
                    [129, a.y, X],
                    [65, a.x, X]
                ]
            }

            function Fo(a) {
                return [
                    [148, a.changes, Po],
                    [65, a.target, ta]
                ]
            }

            function Po(a) {
                return [
                    [193, a.index, X],
                    [145, a.op, ba],
                    [81, a.style, ba]
                ]
            }

            function oo(a) {
                return [
                    [209, a.value, ba],
                    [129, a.index, X],
                    [65, a.target, X]
                ]
            }

            function po(a) {
                return [
                    [129, a.index, X],
                    [69, a.nodes, ta]
                ]
            }

            function qo(a) {
                return [
                    [129, a.index, X],
                    [84, a.nodes, mi]
                ]
            }

            function ro(a) {
                return [
                    [210, a.attributes, 81, ba, 145, ba],
                    [129, a.index, X],
                    [65, a.target, X]
                ]
            }

            function Go(a) {
                return [
                    [852, a.content, mi],
                    [785, a.tabId, ba],
                    [705, a.recordStamp,
                        Qo
                    ],
                    [656, a.location, Ro],
                    [592, a.viewport, ni],
                    [528, a.screen, ni],
                    [449, a.hasBase, yc],
                    [401, a.base, ba],
                    [337, a.referrer, ba],
                    [273, a.ua, ba],
                    [209, a.address, ba],
                    [145, a.title, ba],
                    [81, a.doctype, ba]
                ]
            }

            function Ro(a) {
                return [
                    [209, a.path, ba],
                    [145, a.protocol, ba],
                    [81, a.host, ba]
                ]
            }

            function ni(a) {
                return [
                    [129, a.height, ta],
                    [65, a.width, ta]
                ]
            }

            function mi(a) {
                return [
                    [513, a.hidden, yc],
                    [449, a.prev, X],
                    [385, a.next, X],
                    [337, a.content, ba],
                    [257, a.parent, X],
                    [210, a.attributes, 81, ba, 145, ba],
                    [145, a.name, ba],
                    [65, a.id, X]
                ]
            }

            function ba(a) {
                var c =
                    So({}, a, [], 0);
                return c ? [To, c, a] : [oi, 0, 0]
            }

            function Ho(a) {
                return [Uo, a.length, a]
            }

            function yc(a) {
                return [oi, 1, a ? 1 : 0]
            }

            function Qo(a) {
                a = pi(a);
                var c = a[0],
                    b = a[1],
                    d = (b >>> 28 | c << 4) >>> 0;
                c >>>= 24;
                return [qi, 0 === c ? 0 === d ? 16384 > b ? 128 > b ? 1 : 2 : 2097152 > b ? 3 : 4 : 16384 > d ? 128 > d ? 5 : 6 : 2097152 > d ? 7 : 8 : 128 > c ? 9 : 10, a]
            }

            function td(a) {
                return [Vo, 4, a]
            }

            function ta(a) {
                return 0 > a ? [qi, 10, pi(a)] : X(a)
            }

            function X(a) {
                return [Wo, 128 > a ? 1 : 16384 > a ? 2 : 2097152 > a ? 3 : 268435456 > a ? 4 : 5, a]
            }

            function Wo(a, c, b, d) {
                for (a = c; 127 < a;) b[d++] = a & 127 | 128, a >>>= 7;
                b[d] = a
            }

            function oi(a,
                c, b, d) {
                b[d] = c
            }

            function Uo(a, c, b, d) {
                for (a = 0; a < c.length; ++a) b[d + a] = c[a]
            }

            function ri(a) {
                return function(c, b, d, e) {
                    for (var f, g = 0, h = 0; h < b.length; ++h)
                        if (c = b.charCodeAt(h), 128 > c) a ? g += 1 : d[e++] = c;
                        else {
                            if (2048 > c) {
                                if (a) {
                                    g += 2;
                                    continue
                                }
                                d[e++] = c >> 6 | 192
                            } else {
                                if (55296 === (c & 64512) && 56320 === ((f = b.charCodeAt(h + 1)) & 64512)) {
                                    if (a) {
                                        g += 4;
                                        continue
                                    }
                                    c = 65536 + ((c & 1023) << 10) + (f & 1023);
                                    ++h;
                                    d[e++] = c >> 18 | 240;
                                    d[e++] = c >> 12 & 63 | 128
                                } else {
                                    if (a) {
                                        g += 3;
                                        continue
                                    }
                                    d[e++] = c >> 12 | 224
                                }
                                d[e++] = c >> 6 & 63 | 128
                            }
                            d[e++] = c & 63 | 128
                        }
                    return a ? g : e
                }
            }

            function Vo(a,
                c, b, d) {
                return Xo(a)(a, c, b, d)
            }

            function Yo(a, c, b, d) {
                var e = 0 > c ? 1 : 0;
                e && (c = -c);
                if (0 === c) ud(0 < 1 / c ? 0 : 2147483648, b, d);
                else if (a.isNaN(c)) ud(2143289344, b, d);
                else if (3.4028234663852886E38 < c) ud((e << 31 | 2139095040) >>> 0, b, d);
                else if (1.1754943508222875E-38 > c) ud((e << 31 | a.Math.round(c / 1.401298464324817E-45)) >>> 0, b, d);
                else {
                    var f = a.Math.floor(a.Math.log(c) / Math.LN2);
                    ud((e << 31 | f + 127 << 23 | Math.round(c * a.Math.pow(2, -f) * 8388608) & 8388607) >>> 0, b, d)
                }
            }

            function ud(a, c, b) {
                c[b] = a & 255;
                c[b + 1] = a >>> 8 & 255;
                c[b + 2] = a >>> 16 & 255;
                c[b + 3] = a >>>
                    24
            }

            function qi(a, c, b, d) {
                a = c[0];
                for (c = c[1]; a;) b[d++] = c & 127 | 128, c = (c >>> 7 | a << 25) >>> 0, a >>>= 7;
                for (; 127 < c;) b[d++] = c & 127 | 128, c >>>= 7;
                b[d++] = c
            }

            function pi(a) {
                if (!a) return [0, 0];
                var c = 0 > a;
                c && (a = -a);
                var b = a >>> 0;
                a = (a - b) / 4294967296 >>> 0;
                c && (a = ~a >>> 0, b = ~b >>> 0, 4294967295 < ++b && (b = 0, 4294967295 < ++a && (a = 0)));
                return [a, b]
            }

            function fi(a, c, b, d) {
                var e, f = b.J;
                f.wmode = "0";
                f["wv-hit"] = f["wv-hit"] || "" + zc(a);
                f["page-url"] = f["page-url"] || R(a).href;
                d && (f[d] = f[d] || "" + Wa(a));
                a = {
                    na: {
                        Ba: "webvisor/" + c.id
                    },
                    ba: z(b.ba || {}, {
                        Za: (e = {}, e["Content-Type"] =
                            "text/plain", e),
                        $c: "POST"
                    }),
                    J: f
                };
                z(b, a)
            }

            function Zo(a, c) {
                return qa(c, function(b) {
                    var d = G(a);
                    M(c);
                    if (!d.C("dSync", !1)) return d.D("dSync", !0), si(a, b, {
                        cb: c,
                        Rb: "s",
                        Qd: "ds",
                        Ji: function(e, f, g) {
                            var h = e.Sc;
                            e = e.host;
                            if (n(h, "settings")) return Ua(Ra("ds.e"));
                            f = f(Y) - g;
                            g = e[1];
                            var k, l;
                            h = Ka((k = {}, k.di = h, k.dit = f, k.dip = g, k));
                            k = (l = {}, l["page-url"] = R(a).href, l);
                            return va(a, "S", ti)({
                                K: h,
                                J: k
                            }, ti)["catch"](D(a, "ds.rs"))
                        }
                    })
                })
            }

            function si(a, c, b) {
                var d, e = b.cb,
                    f = ia(a),
                    g = $o(a, c.userData, e),
                    h = ap(a),
                    k = v(ui, C([bp, cp], vd))(a),
                    l = n(c, "settings.sbp");
                l && (b.data = z({}, l, (d = {}, d.c = e.id, d)));
                return h.length ? dp(a, f, g, c, k, b).then(function() {
                    return ep(a, h, g, f, k, b)
                }, E) : L.resolve()
            }

            function ap(a) {
                var c = wd(a);
                a = v(Qf, pc(["iPhone", "iPad"]))(a);
                return c ? fp : a ? gp : []
            }

            function ep(a, c, b, d, e, f) {
                e = f.Ji;
                var g = void 0 === e ? E : e,
                    h = f.Qd,
                    k = d(Y);
                return hp(a, c, f)(Qa(function(l) {
                    y(function(m) {
                        m && ue(a, h + ".s", m)
                    }, l);
                    l = d(pb);
                    b.D(h, l)
                }, function(l) {
                    b.D(h, d(pb));
                    g(l, d, k)
                }))
            }

            function dp(a, c, b, d, e, f) {
                var g = f.Qd,
                    h = f.cb;
                return new L(function(k, l) {
                    var m = b.C(g, 0);
                    m = parseInt("" + m, 10);
                    return c(pb) - m <= e.$f ? l() : ip(a) ? k(void 0) : qf(d) ? l() : k(jp(a, h))
                })
            }

            function hp(a, c, b) {
                var d = b.Rb,
                    e = b.data,
                    f = va(a, d, b.cb);
                a = z({}, vi);
                e && z(a.J, e);
                return kp(B(function(g) {
                    return lp(f(z({
                        ba: {
                            He: !1,
                            ke: !0
                        }
                    }, vi), B(function(h) {
                        var k = h[1],
                            l = h[2];
                        h = I("", B(function(m) {
                            return String.fromCharCode(m.charCodeAt(0) + 10)
                        }, h[0].split("")));
                        return "http" + (l ? "s" : "") + "://" + h + ":" + k + "/" + mp[d]
                    }, g)).then(function(h) {
                        return z({}, h, {
                            host: g[h.hg]
                        })
                    }))
                }, c))
            }

            function $o(a, c, b) {
                var d = c || {},
                    e = va(a, "u", b),
                    f = Pa(a);
                return {
                    C: function(g, h) {
                        return W(d[g]) ? f.C(g, h) : d[g]
                    },
                    D: function(g, h) {
                        var k, l = "" + h;
                        d[g] = l;
                        f.D(g, l);
                        return e({
                            J: (k = {}, k.key = g, k.value = l, k)
                        }, [Ea.Ra + "//" + hc + "/user_storage_set"], {})["catch"](D(a, "u.d.s.s"))
                    }
                }
            }

            function np(a) {
                return {
                    N: function(c, b) {
                        G(a).C("oo") || b()
                    }
                }
            }

            function op(a, c) {
                try {
                    var b = c[0];
                    var d = b[1]
                } catch (e) {
                    return function() {
                        return L.resolve()
                    }
                }
                return function(e) {
                    var f, g = (f = {}, f["browser-info"] = pp, f["page-url"] = a.location && "" + a.location.href, f);
                    return d && (e = yb(a, e)) ? d(qp, {
                        $a: g,
                        ha: [],
                        da: "site-info=" +
                            qe(e)
                    })["catch"](E) : L.resolve()
                }
            }

            function rp(a, c) {
                if (n(a, "disableYaCounter" + c.id) || n(a, "Ya.disableMetrica")) {
                    var b = M(c);
                    delete G(a).C("counters", {})[b];
                    Ua(Ra("oo.e"))
                }
            }

            function sp(a) {
                if (xd(a)) return null;
                var c = tp(a),
                    b = c.Af;
                W(b) && (c.Af = null, up(a).then(function(d) {
                    c.Af = d
                }));
                return b ? 1 : null
            }

            function vp(a, c, b) {
                b = b.J;
                if ((void 0 === b ? {} : b).nohit) return null;
                a = yd(a);
                if (!a) return null;
                var d = b = null;
                n(a, "getEntriesByType") && (d = n(a.getEntriesByType("navigation"), "0")) && (b = wp);
                if (!b) {
                    var e = n(a, "timing");
                    e && (b =
                        xp, d = e)
                }
                if (!b) return null;
                a = yp(a, d, b);
                c = M(c);
                c = zp(c);
                return (c = Ap(c, a)) && I(",", c)
            }

            function Ap(a, c) {
                var b = a.length ? B(function(d, e) {
                    var f = c[e];
                    return f === d ? null : f
                }, a) : c;
                a.length = 0;
                y(v(P, Da("push", a)), c);
                return fa(Aa(null), b).length === a.length ? null : b
            }

            function yp(a, c, b) {
                return B(function(d) {
                    var e = d[0],
                        f = d[1];
                    if (T(e)) return e(a, c) || null;
                    if (1 === d.length) return c[e] ? Math.round(c[e]) : null;
                    var g;
                    !(g = c[e] && c[f]) && (g = 0 === c[e] && 0 === c[f]) && (g = d[1], g = !(wi[d[0]] || wi[g]));
                    if (!g) return null;
                    d = Math.round(c[e]) - Math.round(c[f]);
                    return 0 > d || 36E5 < d ? null : d
                }, b)
            }

            function ve(a, c) {
                try {
                    var b = c.localStorage.getItem(a);
                    return b && jd(ie(b))
                } catch (d) {}
                return null
            }

            function ie(a) {
                for (var c = [], b = 0; b < a.length; b++) {
                    var d = a.charCodeAt(b);
                    128 > d ? c.push(d) : (127 < d && 2048 > d ? c.push(d >> 6 | 192) : (c.push(d >> 12 | 224), c.push(d >> 6 & 63 | 128)), c.push(d & 63 | 128))
                }
                return c
            }

            function jd(a, c) {
                void 0 === c && (c = !1);
                for (var b = a.length, d = b - b % 3, e = [], f = 0; f < d; f += 3) {
                    var g = (a[f] << 16) + (a[f + 1] << 8) + a[f + 2];
                    e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >>
                        18 & 63
                    ], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 12 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g >> 6 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [g & 63])
                }
                switch (b - d) {
                    case 1:
                        b = a[d] << 4;
                        e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b >> 6 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b & 63], "=", "=");
                        break;
                    case 2:
                        b = (a[d] << 10) + (a[d + 1] << 2), e.push("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b >>
                            12 & 63
                        ], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b >> 6 & 63], "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=" [b & 63], "=")
                }
                e = I("", e);
                return c ? xi(e, !0) : e
            }

            function Fh(a, c) {
                void 0 === c && (c = !1);
                var b = a,
                    d = "",
                    e = 0;
                if (!b) return "";
                for (c && (b = xi(b)); b.length % 4;) b += "=";
                do {
                    var f = Ac("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", b.charAt(e++)),
                        g = Ac("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", b.charAt(e++)),
                        h = Ac("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",
                            b.charAt(e++)),
                        k = Ac("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=", b.charAt(e++));
                    if (0 > f || 0 > g || 0 > h || 0 > k) return "";
                    var l = f << 18 | g << 12 | h << 6 | k;
                    f = l >> 16 & 255;
                    g = l >> 8 & 255;
                    l &= 255;
                    d = 64 === h ? d + String.fromCharCode(f) : 64 === k ? d + String.fromCharCode(f, g) : d + String.fromCharCode(f, g, l)
                } while (e < b.length);
                return d
            }

            function xi(a, c) {
                void 0 === c && (c = !1);
                return a ? a.replace(c ? /[+/=]/g : /[-*_]/g, function(b) {
                    return Bp[b] || b
                }) : ""
            }

            function Cp(a) {
                try {
                    var c = Ta(a) ? a : [];
                    return I(",", [a.name, a.description, v(Ba, ua, Mb(Dp),
                        we(","))(c)])
                } catch (b) {
                    return ""
                }
            }

            function Dp(a) {
                return I(",", [a.description, a.suffixes, a.type])
            }

            function Ep(a, c) {
                for (var b = "", d = 0; d < c; d += 1) b += a;
                return b
            }

            function Fp(a, c, b, d, e, f, g, h) {
                var k = b.C(f);
                la(k) && (b.D(f, g), e(a, c, b, d), k = b.C(f, g));
                W(h) || h.Wb(f, "" + k);
                return k
            }

            function Gp(a, c) {
                if (zd(a)) {
                    var b = lb(a).match(Hp);
                    if (b && b.length) return b[1] === c
                }
                return !1
            }

            function xe(a, c, b) {
                return function(d) {
                    var e, f, g = za(c, b);
                    g && Ip(a, d, c) && (g = H(g.params, g), (d = Rf({
                        event: a,
                        La: "products",
                        xa: ic,
                        Bh: "goods"
                    }, d)) && g && g((e = {},
                        e.__ym = (f = {}, f.ecommerce = [d], f), e)))
                }
            }

            function Ip(a, c, b) {
                var d = !1,
                    e = "";
                if (!pa(c)) return wb(b, "", "Ecommerce data should be an object"), d;
                var f = c.goods;
                switch (a) {
                    case "detail":
                    case "add":
                    case "remove":
                        ca(f) && f.length ? (d = Jp(function(g) {
                            return pa(g) && (ka(g.id) || ye(b, g.id) || ka(g.name))
                        }, f)) || (e = "All items in 'goods' should be objects and contain 'id' or 'name' field") : e = "Ecommerce data should contain 'goods' non-empty array";
                        break;
                    case "purchase":
                        ye(b, c.id) || ka(c.id) ? d = !0 : e = "Purchase object should contain string or number 'id' field"
                }
                wb(b,
                    "", e);
                return d
            }

            function Kp(a, c, b) {
                if (b.J && b.J.nohit) return null;
                c = M(c);
                b = Lp(a);
                if (b[c]) return null;
                var d = G(a).C("fht", Infinity);
                a: {
                    var e = n(a, "performance.getEntriesByType");
                    if (T(e)) {
                        if (a = fa(v(P, Q("name"), Aa("first-contentful-paint")), e.call(a.performance, "paint")), a.length) {
                            a = a[0].startTime;
                            break a
                        }
                    } else {
                        var f = n(a, "chrome.loadTimes");
                        e = yi(a);
                        if (T(f) && (f = f.call(a.chrome), f = n(f, "firstPaintTime"), e && f)) {
                            a = 1E3 * f - e;
                            break a
                        }
                        if (a = n(a, "performance.timing.msFirstPaint")) {
                            a -= e;
                            break a
                        }
                    }
                    a = void 0
                }
                return a && d >
                    a ? (b[c] = a, Math.round(a)) : null
            }

            function Ad(a, c) {
                return {
                    N: function(b, d) {
                        Sf(b) ? d() : qa(c, function(e) {
                            var f;
                            if (e = n(e, "settings.hittoken")) e = (f = {}, f.hittoken = e, f), b.J = z(b.J || {}, e);
                            d()
                        })
                    }
                }
            }

            function Mp(a, c) {
                function b() {
                    r.hidden ? z(k.style, Bd(["top", "right", "left", "background"], "initial")) : z(k.style, Bd(["top", "right", "left"], "0"), {
                        background: "rgba(0, 0, 0, .3)"
                    });
                    x.parentNode || (q.appendChild(p), q.appendChild(x));
                    r.hidden = !r.hidden;
                    q.hidden = !q.hidden;
                    t.hidden = !t.hidden
                }

                function d(N) {
                    var ma = g();
                    z(ma.style, Bc("2px",
                        "18px"), Rc, {
                        left: "15px",
                        top: "7px",
                        background: "#2f3747",
                        borderRadius: "2px"
                    });
                    ma.style.transform = "rotate(" + N + "deg)";
                    return ma
                }

                function e(N, ma, wa, Bb, Cd) {
                    var ze = g();
                    z(ze.style, Bc(ma + "px", wa + "px"), Rc, {
                        left: N + "px",
                        bottom: 0,
                        background: Bb,
                        borderTopLeftRadius: Cd
                    });
                    return ze
                }
                var f = eb(a);
                if (!f) return E;
                var g = u("div", f),
                    h = u("iframe", f),
                    k = g();
                k.classList.add("__ym_wv_ign");
                z(k.style, zi, {
                    bottom: "0",
                    width: "100%",
                    maxWidth: "initial",
                    zIndex: "999999999"
                });
                var l = k.attachShadow ? k.attachShadow({
                        mode: "open"
                    }) : k,
                    m = g();
                z(m.style,
                    Bc("24px"), Rc, Tf, {
                        top: "12px",
                        right: "10px",
                        background: "#3367dc",
                        overflow: "hidden"
                    });
                var p = g();
                z(p.style, {
                    border: "2px solid transparent",
                    animation: "__ym_wv_ign-spinner-animation 1s 0.21s infinite linear"
                }, Tf, Rc, Bc("48px"), Bd(["top", "left"], "calc(50% - 24px)"), Bd(["borderTopColor", "borderLeftColor"], "#fc0"));
                f = f("style");
                f.textContent = "@keyframes __ym_wv_ign-spinner-animation {to {transform: rotate(360deg);}}";
                p.appendChild(f);
                var r = g();
                r.id = "__ym_wv_ign__opener";
                z(r.style, Bc("46px", "48px"), zi, {
                    right: "0",
                    bottom: "60px",
                    cursor: "pointer",
                    background: "#fff",
                    borderRadius: "16px 0 0 16px",
                    boxShadow: "0px 0px 1px rgba(67, 68, 69, 0.3), 0px 1px 2px rgba(67, 68, 69, 0.3)"
                });
                var q = g();
                z(q.style, Rc, Bd(["top", "right", "bottom"], "0"), {
                    width: "600px",
                    background: "#fff"
                });
                var t = g();
                t.id = "__ym_wv_ign__closer";
                z(t.style, Bc("32px"), Rc, Tf, {
                    top: "12px",
                    right: "612px",
                    cursor: "pointer",
                    background: "#fff"
                });
                f = h();
                f.src = "https://metrika.yandex.ru/widget/iframe-check";
                var x = h();
                z(x.style, Bc("100%"), {
                    border: "none"
                });
                x.src = "https://metrika.yandex.ru/widget/dashboard?id=" +
                    c;
                q.hidden = !0;
                t.hidden = !0;
                t.appendChild(d(45));
                t.appendChild(d(-45));
                q.appendChild(f);
                m.appendChild(e(0, 8, 9, "linear-gradient(0deg, #ff324f, #ff324f), linear-gradient(158.67deg, #ff455c 12.6%, #ff1139 96.76%)"));
                m.appendChild(e(8, 9, 16, "#04acff", "3px"));
                m.appendChild(e(17, 7, 24, "#ffdd13"));
                r.appendChild(m);
                l.appendChild(q);
                l.appendChild(t);
                var F = ["click", "touchstart"];
                h = da(a);
                m = a.document.body;
                l = [h.F(r, F, b), h.F(t, F, b), h.F(f, ["load"], C([ja, [H(q.removeChild, q, f), H(l.appendChild, l, r)]], y)), h.F(x, ["load"],
                    H(q.removeChild, q, p)), H(m.removeChild, m, k)];
                var U = C([ja, l], y);
                l.push(h.F(a, ["securitypolicyviolation"], function(N) {
                    (N = n(N, "blockedURI")) && 0 <= ib(N, "https://metrika.yandex.ru") && U()
                }));
                m.appendChild(k);
                return U
            }

            function Bd(a, c) {
                return J(function(b, d) {
                    b[d] = c;
                    return b
                }, {}, a)
            }

            function Bc(a, c) {
                var b;
                return b = {}, b.width = a, b.height = c || a, b
            }

            function Np(a, c) {
                var b = n(c, "origin"),
                    d;
                if (d = b) d = Op.test(b) || Pp.test(b);
                d && (b = xb(a, c.data), "appendremote" === n(b, "action") && Qp(a, c, b))
            }

            function Ai(a, c, b, d) {
                var e, f, g, h;
                void 0 ===
                    b && (b = "");
                void 0 === d && (d = "");
                var k = G(a),
                    l = {};
                l.getCachedTags = Ae;
                l.form = (e = {}, e.closest = u(a, Bi), e.select = Rp, e.getData = u(a, Ci), e);
                l.button = (f = {}, f.closest = u(a, ge), f.select = Uf, f.getData = u(a, he), f);
                l.phone = (g = {}, g.hidePhones = C([a, null, [d]], Di), g);
                l.status = (h = {}, h.checkStatus = C([a, Ga(b)], Sp), h);
                k.D("_u", l);
                c && tc(a, {
                    src: c
                })
            }

            function Ei(a) {
                var c = a.lang;
                c = void 0 === c ? "" : c;
                var b = a.appVersion;
                b = void 0 === b ? "" : b;
                var d = a.fileId;
                d = void 0 === d ? "" : d;
                a = a.beta;
                a = void 0 === a ? !1 : a;
                b = I(".", ua(B(v(P, Ga), b.split("."))));
                if (!K(d,
                        Tp) || !K(c, ["ru", "en", "tr"])) return "";
                c = (a ? "https://s3.mds.yandex.net/internal-metrika-betas" : "https://yastatic.net/s3/metrika") + (b ? "/" + b : "") + "/form-selector/" + (d + "_" + c + ".js");
                return Fi(c) ? c : ""
            }

            function Up(a, c) {
                var b = eb(a);
                if (b) {
                    var d = b("div"),
                        e = dc(a);
                    if (e) {
                        d.innerHTML = '<iframe name="RemoteIframe" allowtransparency="true" style="position: absolute; left: -999px; top: -999px; width: 1px; height: 1px;"></iframe>';
                        var f = d.firstChild;
                        f.onload = function() {
                            var h = b("meta");
                            h.setAttribute("http-equiv", "Content-Security-Policy");
                            h.setAttribute("content", "script-src *");
                            f.contentWindow.document.head.appendChild(h);
                            tc(f.contentWindow, {
                                src: c
                            })
                        };
                        a._ym__remoteIframeEl = f;
                        e.appendChild(d);
                        d.removeChild(f);
                        var g = null;
                        d.attachShadow ? g = d.attachShadow({
                            mode: "open"
                        }) : d.createShadowRoot ? g = d.createShadowRoot() : d.webkitCreateShadowRoot && (g = d.webkitCreateShadowRoot());
                        g ? g.appendChild(f) : (e.appendChild(f), a._ym__remoteIframeContainer = f)
                    }
                }
            }

            function Sp(a) {
                var c, b = Gi(a);
                a = G(a).C("getCounters", Dd)();
                a = B(Q("id"), a);
                return c = {
                    id: b
                }, c.counterFound = !!b && K(b, a), c
            }

            function Di(a, c, b) {
                var d;
                c = Hi(a, c, {
                    dg: Vp,
                    ai: (d = {}, d.href = !0, d)
                });
                b = ua(B(function(f) {
                    return "*" === f ? f : Tb(f)
                }, b));
                var e = B(v(P, Da("concat", [""]), Ii("reverse"), ja), b);
                b = Ed(a);
                d = Ji(a, b, 1E3);
                c = u(e, c);
                d.F(c);
                Wp(a, b);
                Ki(a, b);
                c()
            }

            function Vp(a, c, b) {
                var d = eb(a),
                    e = b.sb,
                    f = b.Sb,
                    g = e.parentNode,
                    h = e.textContent;
                if (!("text" === b.je && h && d && g)) return !1;
                b = d("small");
                Li(b);
                var k = Mi(h).length;
                y(Da("appendChild", b), J(function(l, m) {
                    var p = l.nodes,
                        r = l.kg,
                        q = d("small");
                    q.innerHTML = m;
                    var t = Xp.test(m);
                    Li(q);
                    t && (q.style.opacity =
                        "" + (k - r - 1) / k);
                    p.push(q);
                    return {
                        nodes: p,
                        kg: r + (t ? 1 : 0)
                    }
                }, {
                    nodes: [],
                    kg: 0
                }, h).nodes);
                Yp(a, c, b, f);
                g.insertBefore(b, e);
                e.textContent = "";
                return !0
            }

            function Yp(a, c, b, d) {
                function e() {
                    y(u(["style", "opacity", ""], Nc), Ba(b.childNodes));
                    if (c) {
                        var k = za(a, c);
                        k && k.extLink("tel:" + d, {})
                    }
                    g();
                    h()
                }
                var f = da(a),
                    g = E,
                    h = E;
                g = f.F(b, ["mouseenter"], function(k) {
                    if (k.target === b) {
                        var l = O(a, e, 200, "ph.h.e");
                        h();
                        h = f.F(b, ["mouseleave"], function(m) {
                            m.target === b && ha(a, l)
                        })
                    }
                })
            }

            function Ki(a, c) {
                Cb(a)(Qa(E, function() {
                    var b, d = a.document.body,
                        e = (b = {}, b.attributes = !0, b.childList = !0, b.subtree = !0, b);
                    Ia("MutationObserver", a.MutationObserver) && (new MutationObserver(c.T)).observe(d, e)
                }))
            }

            function Wp(a, c) {
                return da(a).F(a, ["load"], c.T)
            }

            function Hi(a, c, b) {
                function d(k) {
                    return f(a, c, k) ? h[k.Sb] && h[k.Sb].Yc : null
                }
                var e, f = b.dg;
                b = b.ai;
                var g = void 0 === b ? (e = {}, e.href = !0, e.text = !0, e) : b,
                    h;
                return function(k) {
                    return new L(function(l, m) {
                        k && k.length || m();
                        h = Ni()(k);
                        Cb(a)(Qa(u({
                            ja: [],
                            Aa: 0
                        }, l), function() {
                            var p = ia(a),
                                r = p(Y),
                                q = g.href ? Zp(a, h) : [],
                                t = g.text ? Oi(a, h, a.document.body) : [];
                            l({
                                ja: fa(ca, ua(B(d, q.concat(t)))),
                                Aa: p(Y) - r
                            })
                        }))
                    })
                }
            }

            function Zp(a, c) {
                var b = a.document.body;
                if (!b) return [];
                var d = Pi(c);
                return J(function(e, f) {
                    var g = n(f, "href");
                    try {
                        var h = decodeURI(g || "")
                    } catch (p) {
                        h = ""
                    }
                    if ("tel:" === h.slice(0, 4)) {
                        var k = (d.exec(h) || [])[0],
                            l = k ? Tb(k) : "",
                            m = c[l];
                        W(m) || !l && "*" !== m.Yc[0] || (e.push({
                            je: "href",
                            sb: f,
                            Sb: l,
                            bb: Qi(k, c[l].bb),
                            Mi: g
                        }), g = Tb(h.slice(4)), l = Ni()([l ? m.Yc : [g, ""]]), ra(e, Oi(a, l, f)))
                    }
                    return e
                }, [], Ba(b.querySelectorAll("a")))
            }

            function Oi(a, c, b) {
                if (!b) return [];
                var d = [],
                    e = Pi(c),
                    f = ["script", "style"];
                yf(a, b, function(g) {
                    var h = n(g, "parentNode.nodeName") || "";
                    g === b || K(h.toLowerCase(), f) || (h = ua(e.exec(g.textContent || "") || []), y(function(k) {
                        var l = Tb(k);
                        W(c[l]) || d.push({
                            je: "text",
                            sb: g,
                            Sb: l,
                            bb: Qi(k, c[l].bb),
                            Mi: g.textContent || ""
                        })
                    }, h))
                }, function(g) {
                    return e.test(g.textContent || "") ? 1 : 0
                }, a.NodeFilter.SHOW_TEXT);
                return d
            }

            function Ni() {
                return Vf(function(a, c) {
                    var b = B(Tb, c),
                        d = b[0];
                    b = b[1];
                    a[d] = {
                        bb: b,
                        Yc: c
                    };
                    var e = Ri(d);
                    e !== d && (a[e] = {
                        bb: Ri(b),
                        Yc: c
                    });
                    return a
                }, {})
            }

            function Qi(a, c) {
                for (var b = [], d = a.split(""), e = c.split(""), f = 0, g = 0; g < a.length && !(f >= e.length); g += 1) {
                    var h = d[g];
                    "0" <= h && "9" >= h ? (b.push(e[f]), f += 1) : b.push(d[g])
                }
                return I("", b) + c.slice(f + 1)
            }

            function Ri(a) {
                var c = {
                    7: "8",
                    8: "7"
                };
                return 11 === a.length && c[a[0]] ? "" + c[a[0]] + a.slice(1) : a
            }

            function Pi(a) {
                return new RegExp("(?:" + I("|", B(Si, ea(a))) + ")")
            }

            function Ti(a, c, b, d) {
                if (c) {
                    var e = [];
                    c && (a.document.documentElement.contains(c) ? yf(a, c, Da("push", e), d) : ra(e, Ui(a, c, d)));
                    y(b, e)
                }
            }

            function yf(a, c, b, d, e) {
                function f(g) {
                    return T(d) ? d(g) ? a.NodeFilter.FILTER_ACCEPT :
                        a.NodeFilter.FILTER_REJECT : a.NodeFilter.FILTER_ACCEPT
                }
                void 0 === e && (e = -1);
                if (T(b) && f(c) === a.NodeFilter.FILTER_ACCEPT && (b(c), !Nf(c)))
                    for (c = a.document.createTreeWalker(c, e, d ? {
                            acceptNode: f
                        } : null, !1); c.nextNode() && !1 !== b(c.currentNode););
            }

            function Ui(a, c, b) {
                var d = [],
                    e = v(P, Da("push", d));
                T(b) ? (b = b(c), (la(b) || b === a.NodeFilter.FILTER_ACCEPT) && e(c)) : e(c);
                if (c.childNodes && 0 < c.childNodes.length) {
                    c = c.childNodes;
                    b = 0;
                    for (var f = c.length; b < f; b += 1) {
                        var g = Ui(a, c[b]);
                        y(e, g)
                    }
                }
                return d
            }

            function Vi(a, c, b) {
                var d;
                a = [Wi(a,
                    c,
                    function(e) {
                        d = e;
                        e.za.F(b)
                    }), function() {
                    d && d.unsubscribe()
                }];
                return C([Be, a], y)
            }

            function $p(a, c, b, d) {
                var e, f, g;
                if (b) {
                    var h = n(d, "ecommerce") || {};
                    var k = n(d, "event") || "";
                    h = pa(h) && ka(k) ? Rf(k, h) : void 0;
                    if (!h) a: {
                        var l = d;!ca(d) && ye(a, Ta(d)) && (l = Ja(l));
                        if (ca(l) && (h = l[0], k = l[1], l = l[2], ka(k) && pa(l) && "event" === h)) {
                            h = Rf(k, l);
                            break a
                        }
                        h = void 0
                    }
                    if (d = h || aq(d)) rb(a, (e = {}, e.counterKey = c, e.name = "ecommerce", e.data = d, e)), b((f = {}, f.__ym = (g = {}, g.ecommerce = [d], g), f))
                }
            }

            function aq(a) {
                var c = n(a, "ecommerce");
                if (pa(c)) return a =
                    fa(pc(bq), ea(c)), a = J(function(b, d) {
                        b[d] = c[d];
                        return b
                    }, {}, a), 0 === ea(a).length ? void 0 : a
            }

            function Rf(a, c) {
                var b, d, e = ka(a) ? cq[a] : a;
                if (e) {
                    var f = e.event,
                        g = e.La,
                        h = e.Bh,
                        k = void 0 === h ? "items" : h,
                        l = c.purchase || c;
                    if (h = l[k]) {
                        e = B(u(e.xa, dq), h);
                        var m = (b = {}, b[f] = g ? (d = {}, d[g] = e, d) : e, b);
                        b = ea(l);
                        g && 1 < b.length && (m[f].actionField = J(function(p, r) {
                            if (r === k) return p;
                            if ("currency" === r) return m.currencyCode = l.currency, p;
                            p[eq[r] || Wf[r] || r] = l[r];
                            return p
                        }, {}, b));
                        return m
                    }
                }
            }

            function dq(a, c) {
                var b = {};
                y(function(d) {
                    var e = a[d] ||
                        Wf[d] || d; - 1 !== ib(d, "item_category") ? (e = Wf.item_category, b[e] = b[e] ? b[e] + ("/" + c[d]) : c[d]) : b[e] = c[d]
                }, ea(c));
                return b
            }

            function fq(a, c, b) {
                var d, e, f = n(b, "target");
                if (f && (f = ge(a, f), f = he(a, f))) {
                    f = "?" + Cc(f);
                    var g = Nb(a, c, "Button goal. Counter " + c.id + ". Button: " + f + ".");
                    b = n(b, "isTrusted");
                    b = la(b) ? void 0 : (d = {}, d.__ym = (e = {}, e.ite = zb(b), e), d);
                    Ce(a, c, "btn", g).reachGoal(f, b)
                }
            }

            function gq(a, c, b, d) {
                var e = n(d, "target");
                e && (d = n(d, "isTrusted"), (e = jc("button,input", a, e)) && "submit" === e.type && (e = Bi(a, e))) && (b.push(e), O(a,
                    C([!1, a, c, b, e, d], Xi), 300))
            }

            function Xi(a, c, b, d, e, f) {
                var g, h, k = Ob(c)(e, d),
                    l = -1 !== k;
                if (a || l) l && d.splice(k, 1), a = Ci(c, e), a = "?" + Cc(a), d = C([c, b, "Form goal. Counter " + b.id + ". Form: " + a + "."], Yi), f = la(f) ? void 0 : (g = {}, g.__ym = (h = {}, h.ite = zb(f), h), g), Ce(c, b, "form", d).reachGoal(a, f)
            }

            function Yi(a, c, b) {
                return hq(a, c).then(v(C([Nb(a, c, b), E], vd), ja))
            }

            function Ci(a, c, b) {
                return Zi(a, c, ["i", "n", "p"], void 0, b)
            }

            function iq(a, c) {
                var b;
                a((b = {}, b.clickmap = W(c) ? !0 : c, b))
            }

            function jq(a, c, b, d, e) {
                var f, g = "clmap/" + e.id;
                c = (f = {},
                    f["page-url"] = c, f["pointer-click"] = b, f);
                f = {
                    K: Ka(),
                    J: c,
                    na: {
                        Ba: g
                    }
                };
                d(f, e)["catch"](D(a, "c.s.c"))
            }

            function kq(a, c, b, d, e) {
                if (Sc(a, "ymDisabledClickmap") || !c || !c.element) return !1;
                a = Na(c.element);
                if (e && !e(c.element, a) || K(c.button, [2, 3]) && "A" !== a || Ya(Aa(a), d)) return !1;
                d = c.element;
                if (c && b) {
                    if (50 > c.time - b.time) return !1;
                    e = Math.abs(b.position.x - c.position.x);
                    a = Math.abs(b.position.y - c.position.y);
                    c = c.time - b.time;
                    if (b.element === d && 2 > e && 2 > a && 1E3 > c) return !1
                }
                for (; d;) {
                    if (lq(d)) return !1;
                    d = d.parentElement
                }
                return !0
            }

            function mq(a,
                c) {
                var b = null;
                try {
                    if (b = c.target || c.srcElement) !b.ownerDocument && b.documentElement ? b = b.documentElement : b.ownerDocument !== a.document && (b = null)
                } catch (d) {}
                return b
            }

            function nq(a) {
                var c = a.which;
                a = a.button;
                return c || void 0 === a ? c : 1 === a || 3 === a ? 1 : 2 === a ? 3 : 4 === a ? 2 : 0
            }

            function $i(a, c) {
                var b = dc(a),
                    d = Xf(a);
                return {
                    x: c.pageX || c.clientX + d.x - (b.clientLeft || 0) || 0,
                    y: c.pageY || c.clientY + d.y - (b.clientTop || 0) || 0
                }
            }

            function De(a, c) {
                return {
                    N: function(b, d) {
                        var e, f = b.K,
                            g = b.Ja,
                            h = b.J,
                            k = b.ba;
                        k = void 0 === k ? {} : k;
                        if (f && h) {
                            var l = ia(a);
                            f.Wb("rqnl", 1);
                            for (var m = Fd(a), p = 1; m[p];) p += 1;
                            b.M || (b.M = {});
                            b.M.Tb = p;
                            m[p] = (e = {}, e.protocol = Ea.Ra, e.host = hc, e.resource = b.na.Ba, e.postParams = k.da, e.time = l(Y), e.counterType = c.ca, e.params = h, e.browserInfo = f.l(), e.counterId = c.id, e.ghid = zc(a), e);
                            g && (m[p].telemetry = g.l());
                            Yf(a)
                        }
                        d()
                    },
                    Da: function(b, d) {
                        aj(a, b);
                        d()
                    }
                }
            }

            function aj(a, c) {
                var b = Fd(a);
                c.K && !Va(b) && c.M && (delete b[c.M.Tb], Yf(a))
            }

            function Yf(a) {
                var c = Fd(a);
                Pa(a).D("retryReqs", c)
            }

            function oq(a, c) {
                if (a.Si()) {
                    var b = bj(c);
                    if (b && !gc("ym-disable-tracklink",
                            b)) {
                        var d = a.l,
                            e = a.Ng,
                            f = a.cb,
                            g = a.sender,
                            h = a.$g,
                            k = f.xc,
                            l = b.href;
                        var m = db(b.innerHTML && b.innerHTML.replace(/<\/?[^>]+>/gi, ""));
                        m || (m = (m = b.querySelector("img")) ? db(m.getAttribute("title") || m.getAttribute("alt")) : "");
                        m = l === m ? "" : m;
                        var p = n(c, "isTrusted");
                        if (gc("ym-external-link", b)) Ee(d, f, {
                            url: l,
                            ob: !0,
                            title: m,
                            Gc: p,
                            sender: g
                        });
                        else {
                            k = k ? Pc(d, k).hostname : R(d).hostname;
                            h = RegExp("\\.(" + I("|", B(pq, h)) + ")$", "i");
                            var r = b.protocol + "//" + b.hostname + b.pathname;
                            h = cj.test(r) || cj.test(l) || h.test(l) || h.test(r);
                            b = b.hostname;
                            Fe(k) === Fe(b) ? h ? Ee(d, f, {
                                url: l,
                                Ec: !0,
                                Gc: p,
                                title: m,
                                sender: g
                            }) : m && e.D("il", db(m).slice(0, 100)) : l && qq.test(l) || Ee(d, f, {
                                url: l,
                                Ic: !0,
                                ob: !0,
                                Ec: h,
                                Gc: p,
                                title: m,
                                sender: g
                            })
                        }
                    }
                }
            }

            function Ee(a, c, b) {
                var d, e, f, g = Ka();
                void 0 !== b.Gc && g.D("ite", zb(b.Gc));
                b.Ec && g.D("dl", 1);
                b.ob && g.D("ln", 1);
                var h = b.jg || {};
                g = {
                    K: g,
                    M: {
                        title: h.title || b.title,
                        Ic: !!b.Ic,
                        R: h.params
                    },
                    J: (d = {}, d["page-url"] = b.url, d["page-ref"] = c.xc || R(a).href, d)
                };
                d = "Link";
                b.Ec ? d = b.ob ? "Ext link - File" : "File" : b.ob && (d = "Ext link");
                rb(a, (e = {}, e.counterKey = M(c), e.name =
                    "event", e.data = (f = {}, f.schema = "Link click", f.name = (b.ob ? "external" : "internal") + " url: " + b.url, f), e));
                c = b.sender(g, c).then(Nb(a, c, d + ". Counter " + c.id + ". Url: " + b.url, b.jg));
                return Tc(a, "cl.p.s", c, h.callback || E, h.ctx)
            }

            function rq(a, c) {
                var b, d, e = (b = {}, b.string = !0, b.object = !0, b["boolean"] = c, b)[typeof c] || !1;
                a((d = {}, d.trackLinks = e, d))
            }

            function sq(a, c, b, d) {
                var e = R(a),
                    f = e.hostname;
                e = e.href;
                if (c = Gd(c).url) a = Pc(a, c), f = a.hostname, e = a.href;
                return [d + "://" + f + "/" + b, e || ""]
            }

            function dj(a) {
                return (a.split(":")[1] ||
                    "").replace(/^\/*/, "").replace(/^www\./, "").split("/")[0]
            }

            function tq(a, c, b, d) {
                var e;
                if (a = za(a, b)) {
                    var f = d.data;
                    b = "" + b.id;
                    var g = d.sended || [];
                    d.sended || (d.sended = g);
                    K(b, g) || !a.params || d.counter && "" + d.counter !== b || (a.params(f), g.push(b), d.parent && c.Sf((e = {}, e.type = "params", e.data = f, e)))
                }
            }

            function xh(a, c, b) {
                void 0 === b && (b = P);
                var d = pd(a);
                b(d);
                var e = u(d, uq);
                Ge(a, c, function(f) {
                    f.za.F(e)
                });
                return d
            }

            function uq(a, c) {
                var b = n(c, "ymetrikaEvent");
                b && a.T(n(b, "type"), b)
            }

            function Ge(a, c, b, d) {
                void 0 === b && (b = E);
                void 0 ===
                    d && (d = !1);
                var e = Ed(a);
                if (c && T(c.push)) {
                    var f = c.push;
                    c.push = function() {
                        var g = Ja(arguments),
                            h = g[0];
                        d && e.T(h);
                        g = f.apply(c, g);
                        d || e.T(h);
                        return g
                    };
                    a = {
                        za: e,
                        unsubscribe: function() {
                            c.push = f
                        }
                    };
                    b(a);
                    y(e.T, c);
                    return a
                }
            }

            function ke(a) {
                a = G(a);
                var c = a.C("dataLayer", []);
                a.D("dataLayer", c);
                return c
            }

            function Km(a, c) {
                var b, d;
                K(c, B(Q("ymetrikaEvent.type"), a)) || a.push((b = {}, b.ymetrikaEvent = (d = {}, d.type = c, d), b))
            }

            function ej(a, c) {
                var b = md(a, c),
                    d = [],
                    e = [];
                if (!b) return null;
                var f = C([a, b.ne], vq),
                    g = u(f, wq);
                b.$.F(["initToParent"],
                    function(h) {
                        g(d, b.children[h[1].counterId])
                    }).F(["parentConnect"], function(h) {
                    g(e, b.Ga[h[1].counterId])
                });
                return {
                    $: b.$,
                    Gj: function(h, k) {
                        return new L(function(l, m) {
                            b.ne(h, k, function(p, r) {
                                l([p, r])
                            });
                            O(a, u(Ra(), m), 5100, "is.o")
                        })
                    },
                    Rf: function(h) {
                        var k = {
                            Uf: [],
                            Ae: [],
                            data: h
                        };
                        d.push(k);
                        return f(b.children, k, h)
                    },
                    Sf: function(h) {
                        var k = {
                            Uf: [],
                            Ae: [],
                            data: h
                        };
                        e.push(k);
                        return f(b.Ga, k, h)
                    }
                }
            }

            function wq(a, c, b) {
                c = fa(function(d) {
                    return !K(b.info.counterId, d.Ae)
                }, c);
                y(function(d) {
                    var e;
                    b.info.counterId && a((e = {}, e[b.info.counterId] =
                        b, e), d, d.data)
                }, c)
            }

            function vq(a, c, b, d, e) {
                return (new L(function(f, g) {
                    var h = ea(b),
                        k = v(d.resolve || P, od(f)),
                        l = v(d.reject || P, od(g));
                    d.resolve = k;
                    d.reject = l;
                    y(function(m) {
                        var p;
                        d.Ae.push(+m);
                        var r = b[m],
                            q = O(a, u(Ra(), l), 5100, "is.m");
                        c(r.window, z(e, (p = {}, p.toCounter = Ga(m), p)), function(t, x) {
                            ha(a, q);
                            d.Uf.push(m);
                            d.resolve && d.resolve(x)
                        })
                    }, h)
                }))["catch"](D(a, "if.b"))
            }

            function xq(a) {
                var c = E,
                    b = null,
                    d = a.length;
                if (0 !== a.length && a[0]) {
                    var e = a.slice(-1)[0];
                    T(e) && (c = e, d = a.length + -1);
                    var f = a.slice(-2)[0];
                    T(f) && (c = f,
                        b = e, d = a.length + -2);
                    d = a.slice(0, d);
                    return {
                        Og: b,
                        dc: c,
                        R: 1 === d.length ? a[0] : Nc(d)
                    }
                }
            }

            function Tc(a, c, b, d, e) {
                var f = C([a, d, e], Zf);
                return b.then(f, function(g) {
                    f();
                    ue(a, c, g)
                })
            }

            function $f(a, c) {
                return {
                    N: function(b, d) {
                        var e, f, g = (b.M || {}).R,
                            h = b.ba;
                        h = void 0 === h ? {} : h;
                        if (g && (fj(c, g), !h.da && b.K && b.J)) {
                            var k = yb(a, g),
                                l = gj(a),
                                m = b.K.C("pv");
                            k && !b.J.nohit && (rb(a, (e = {}, e.counterKey = M(c), e.name = "params", e.data = (f = {}, f.val = g, f), e)), m ? encodeURIComponent(k).length > Ea.pg ? l.push([b.K, g]) : b.J["site-info"] = k : (h.da = k, b.ba = h, b.Pc ||
                                (b.Pc = {}), b.Pc.bi = !0))
                        }
                        d()
                    },
                    Da: function(b, d) {
                        var e = gj(a),
                            f = za(a, c),
                            g = f && f.params;
                        g && (f = fa(v(Uc, Aa(b.K)), e), y(function(h) {
                            g(h[1]);
                            h = He(a)(h, e);
                            e.splice(h, 1)
                        }, f));
                        d()
                    }
                }
            }

            function Ie(a, c) {
                return function(b) {
                    ag(a, c, b)
                }
            }

            function yq(a, c) {
                bg(a)(function(b) {
                    delete b[c]
                })
            }

            function ag(a, c, b) {
                bg(a)(function(d) {
                    d[c] = z(d[c] || {}, b)
                })
            }

            function bg(a) {
                a = G(a);
                var c = a.C("dsjf") || Fa({});
                a.Ia("dsjf", c);
                return c
            }

            function zq(a, c) {
                return function(b) {
                    var d, e, f = za(a, c);
                    f && (pa(b) ? Ta(ea(b)) ? (b = hj(b)) && Ta(b) && f.params((d = {}, d.__ym =
                        (e = {}, e.fpmh = b, e), d)) : Nb(a, c, "First party params error. Empty object.")() : Nb(a, c, "First party params error. Not an object.")())
                }
            }

            function hj(a) {
                return J(function(c, b) {
                    var d = b[0],
                        e = b[1],
                        f = pa(e);
                    if (!ka(e) && !f) return c;
                    e = f ? hj(e) : e;
                    Ta(e) && c.push([d, e]);
                    return c
                }, [], Ma(a))
            }

            function ij(a, c, b) {
                void 0 === b && (b = 0);
                c = Ma(c);
                c = J(function(d, e) {
                    var f = e[0],
                        g = e[1],
                        h = pa(g);
                    if (!ka(g) && !h) return d;
                    h ? g = ij(a, g, b + 1) : b || "yandex_cid" !== f ? ("phone_number" === f ? g = Aq(g) : "email" === f && (g = Bq(g)), g = jj(a, g)) : g = L.resolve(g);
                    d.push(g.then(function(k) {
                        return [f,
                            k
                        ]
                    }));
                    return d
                }, [], c);
                return L.all(c)
            }

            function Bq(a) {
                var c = db(a).toLowerCase().split("@"),
                    b = c[0];
                c = c[1];
                if (!c) return a;
                c = c.replace("googlemail.com", "gmail.com");
                kj(c) && (c = "yandex.ru");
                "yandex.ru" === c ? b = b.replace(cg, "-") : "gmail.com" === c && (b = b.replace(cg, ""));
                a = ib(b, "+"); - 1 !== a && (b = b.slice(0, a));
                return b + "@" + c
            }

            function Aq(a) {
                a = Tb(a);
                return "8" === a[0] ? "7" + a.slice(1) : a
            }

            function jj(a, c) {
                return new L(function(b, d) {
                    var e = (new a.TextEncoder).encode(c);
                    a.crypto.subtle.digest("SHA-256", e).then(function(f) {
                        f =
                            new a.Blob([f], {
                                type: "application/octet-binary"
                            });
                        var g = new a.FileReader;
                        g.onload = function(h) {
                            h = n(h, "target.result") || "";
                            var k = ib(h, ","); - 1 !== k ? b(h.substring(k + 1)) : d(Ic("fpm.i"))
                        };
                        g.readAsDataURL(f)
                    }, d)
                })
            }

            function za(a, c) {
                var b = G(a).C("counters", {}),
                    d = M(c);
                return b[d]
            }

            function lj(a, c) {
                G(a).D("dce:" + c, !0);
                var b = G(a).C("dclq:" + c);
                if (b) {
                    var d = Hd(a, c);
                    y(function(e) {
                        d[e[0]].apply(d, e[1])
                    }, b);
                    Id(b)
                }
            }

            function Nb(a, c, b, d) {
                return mj(c) ? E : u(C([a, M(c)].concat(d ? [b + ". Params:", d] : [b]), wb), ja)
            }

            function wb() {
                var a =
                    Ja(arguments),
                    c = a.slice(2);
                Hd(a[0], a[1]).log.apply(wb, c)
            }

            function Cq(a, c) {
                return {
                    log: Vc(a, "log", c, E),
                    warn: Vc(a, "log", c, E),
                    error: Vc(a, "log", c, E)
                }
            }

            function Vc(a, c, b, d) {
                return function() {
                    var e, f, g = Ja(arguments);
                    rb(a, (e = {}, e.counterKey = b, e.name = "log", e.data = (f = {}, f.args = g, f.type = c, f), e));
                    return d.apply(void 0, g)
                }
            }

            function qa(a, c) {
                var b = M(a);
                return nj()(Dq(b)).then(c)
            }

            function Eq(a, c, b) {
                var d, e;
                c = M(c);
                var f = dg(a);
                b = z({
                    bh: f(Y)
                }, b);
                rb(a, (d = {}, d.counterKey = c, d.name = "counterSettings", d.data = (e = {}, e.settings =
                    b, e), d));
                return nj()(Fq(c, b))
            }

            function Fq(a, c) {
                return function(b) {
                    var d = b[a];
                    d ? (d.yi = c, d.Ff = !0, d.Ef ? d.Ef(c) : d.promise = L.resolve(c)) : b[a] = {
                        promise: L.resolve(c),
                        yi: c,
                        Ff: !0
                    }
                }
            }

            function eg(a) {
                return !xd(a) && fg(a)
            }

            function Jd(a) {
                return eb(a) ? u(a, Gq) : !1
            }

            function Db(a) {
                if (a.fetch) {
                    var c = n(a, "AbortController");
                    return C([a, c ? new c : void 0], Hq)
                }
                return !1
            }

            function fg(a) {
                var c = n(a, "navigator.sendBeacon");
                return c && Ia("sendBeacon", c) ? C([a, H(c, n(a, "navigator"))], Iq) : !1
            }

            function Iq(a, c, b, d) {
                return new L(function(e,
                    f) {
                    var g;
                    if (!n(a, "navigator.onLine")) return f();
                    var h = z(d.$a, (g = {}, g["force-urlencoded"] = 1, g));
                    g = b + "?" + Cc(h) + (d.da ? "&" + d.da : "");
                    return 2E3 < g.length ? f(Ra("sb.tlq")) : c(g) ? e("") : f()
                })
            }

            function Gq(a, c, b) {
                return new L(function(d, e) {
                    var f, g, h = "_ymjsp" + Wa(a),
                        k = z((f = {}, f.callback = h, f), b.$a),
                        l = C([a, h], Jq);
                    a[h] = function(p) {
                        try {
                            l(), sc(m), d(p)
                        } catch (r) {
                            e(r)
                        }
                    };
                    k.wmode = "5";
                    var m = tc(a, (g = {}, g.src = oj(c, b, k), g));
                    if (!m) return l(), e(Ic("jp.s"));
                    f = u(m, sc);
                    f = v(f, u(Ra(b.ha), e));
                    g = Kd(a, f, b.Pa || 1E4);
                    g = C([a, g], ha);
                    m.onload =
                        g;
                    m.onerror = v(l, g, f)
                })
            }

            function Jq(a, c) {
                try {
                    delete a[c]
                } catch (b) {
                    a[c] = void 0
                }
            }

            function Wc(a) {
                var c = eb(a);
                return c ? C([a, c], Kq) : !1
            }

            function Kq(a, c, b, d) {
                return new L(function(e, f) {
                    var g = dc(a),
                        h = c("img"),
                        k = v(u(h, sc), u(Ra(d.ha), f)),
                        l = Kd(a, k, d.Pa || 3E3);
                    h.onerror = k;
                    h.onload = v(u(h, sc), u(null, e), C([a, l], ha));
                    k = z({}, d.$a);
                    delete k.wmode;
                    h.src = oj(b, d, k);
                    zd(a) && (z(h.style, {
                        position: "absolute",
                        visibility: "hidden",
                        width: "0px",
                        height: "0px"
                    }), g.appendChild(h))
                })
            }

            function Hq(a, c, b, d) {
                var e, f = z(d.zb ? (e = {}, e.wmode =
                        "7", e) : {}, d.$a),
                    g = c || {
                        signal: void 0,
                        abort: E
                    },
                    h = a.fetch(b + "?" + Cc(f), {
                        method: d.$c,
                        body: d.da,
                        credentials: !1 === d.He ? "omit" : "include",
                        headers: d.Za,
                        signal: g.signal
                    }),
                    k = u(d.ha, Ra);
                return new L(function(l, m) {
                    d.Pa && Kd(a, function() {
                        try {
                            g.abort()
                        } catch (p) {}
                        m(k())
                    }, d.Pa);
                    return h.then(function(p) {
                        if (!p.ok) {
                            if (d.ke) return Ua(pj(p));
                            de(d.ha)
                        }
                        return d.ke ? p.text() : d.zb ? p.json() : null
                    }).then(l)["catch"](u(k(), m))
                })
            }

            function Eb(a) {
                var c;
                if (c = n(a, "XMLHttpRequest"))
                    if (c = "withCredentials" in new a.XMLHttpRequest) {
                        a: {
                            if (Lq.test(a.location.host) &&
                                a.opera && T(a.opera.version) && (c = a.opera.version(), "string" === typeof c && "12" === c.split(".")[0])) {
                                c = !0;
                                break a
                            }
                            c = !1
                        }
                        c = !c
                    }
                return c ? u(a, Mq) : !1
            }

            function Mq(a, c, b) {
                var d, e = new a.XMLHttpRequest,
                    f = b.da,
                    g = z(b.zb ? (d = {}, d.wmode = "7", d) : {}, b.$a);
                return new L(function(h, k) {
                    e.open(b.$c || "GET", c + "?" + Cc(g), !0);
                    e.withCredentials = !1 !== b.He;
                    b.Pa && (e.timeout = b.Pa);
                    qj(Ma, Mb(function(m) {
                        e.setRequestHeader(m[0], m[1])
                    }))(b.Za);
                    var l = C([a, e, Ra(b.ha), b.zb, b.ke, h, k], Nq);
                    e.onreadystatechange = l;
                    try {
                        e.send(f)
                    } catch (m) {}
                })
            }

            function Nq(a,
                c, b, d, e, f, g, h) {
                if (4 === c.readyState)
                    if (200 === c.status || e || g(b), e) 200 === c.status ? f(c.responseText) : g(pj(c));
                    else {
                        e = null;
                        if (d) try {
                            (e = xb(a, c.responseText)) || g(b)
                        } catch (k) {
                            g(b)
                        }
                        f(e)
                    }
                return h
            }

            function oj(a, c, b) {
                (b = Cc(b)) && (a += "?" + b);
                c.da && (a += (b ? "&" : "?") + c.da);
                return a
            }

            function Oq(a, c, b) {
                var d = B(Uc, Vb[c] || Wb);
                y(function(e) {
                    return d.unshift(e)
                }, Je);
                return B(v(Xc([a, b]), ja), d)
            }

            function rj(a, c) {
                var b = R(a),
                    d = b.href,
                    e = b.host,
                    f = -1;
                if (!ka(c) || W(c)) return d;
                b = c.replace(sj, "");
                if (-1 !== b.search(Pq)) return b;
                var g =
                    b.charAt(0);
                if ("?" === g && (f = d.search(/\?/), -1 === f) || "#" === g && (f = d.search(/#/), -1 === f)) return d + b;
                if (-1 !== f) return d.substr(0, f) + b;
                if ("/" === g) {
                    if (f = ib(d, e), -1 !== f) return d.substr(0, f + e.length) + b
                } else return d = d.split("/"), d[d.length - 1] = b, I("/", d);
                return ""
            }

            function Ke(a, c) {
                return {
                    N: function(b, d) {
                        var e = tj(c);
                        e = C([b, e, d], Qq);
                        Rq(a, c, e)
                    },
                    Da: function(b, d) {
                        var e = b.K,
                            f = tj(c);
                        if (e) {
                            var g = f.ta;
                            f.Ve === e && g && (y(ja, g), f.ta = null)
                        }
                        d()
                    }
                }
            }

            function Qq(a, c, b) {
                var d = a.K;
                d ? Sf(a) ? (c.Ve = d, b()) : c.ta ? c.ta.push(b) : b() : b()
            }

            function Sf(a) {
                return (a =
                    a.K) && a.C("pv") && !a.C("ar")
            }

            function Rq(a, c, b) {
                if (Le(a) && jb(a)) {
                    var d = Sq(c);
                    if (!d.Qh) {
                        d.Qh = !0;
                        c = md(a, c);
                        if (!c) {
                            b();
                            return
                        }
                        d.ta = [];
                        var e = function() {
                            d.ta && (y(ja, d.ta), d.ta = null)
                        };
                        O(a, e, 3E3);
                        c.$.F(["initToChild"], e)
                    }
                    d.ta ? d.ta.push(b) : b()
                } else b()
            }

            function uj(a, c) {
                return {
                    N: function(b, d) {
                        var e = b.K;
                        if (e && (!c || c.Qf)) {
                            var f = a.document.title;
                            b.M && b.M.title && (f = b.M.title);
                            var g = kc("getElementsByTagName", a.document);
                            "string" !== typeof f && g && (f = g("title"), f = (f = n(f, "0.innerHtml")) ? f : "");
                            f = f.slice(0, Ea.qg);
                            e.D("t",
                                f)
                        }
                        d()
                    }
                }
            }

            function Pb(a) {
                return function(c, b) {
                    return {
                        N: function(d, e) {
                            var f = d.K,
                                g = d.J;
                            f && g && y(function(h) {
                                var k = Ld[h],
                                    l = "bi",
                                    m = f;
                                k || (k = gg[h], l = "tel", m = me(d));
                                k && (k = A(l + ":" + h, k, null)(c, b, d), m.Wb(h, k))
                            }, a || Tq());
                            e()
                        }
                    }
                }
            }

            function Uq(a, c) {
                var b = Md(a);
                c.F(["initToParent"], function(d) {
                    var e = d[0];
                    d = d[1];
                    window.window && (b.children[d.counterId] = {
                        info: d,
                        window: e.source
                    })
                }).F(["initToChild"], function(d) {
                    var e = d[0];
                    d = d[1];
                    e.source === a.parent && c.T("parentConnect", [e, d])
                }).F(["parentConnect"], function(d) {
                    var e = d[1];
                    e.counterId && (b.Ga[e.counterId] = {
                        info: e,
                        window: d[0].source
                    })
                })
            }

            function Vq(a) {
                if (Ia("MutationObserver", a.MutationObserver)) {
                    var c = Md(a).children,
                        b = new a.MutationObserver(function() {
                            y(function(d) {
                                n(c[d], "window.window") || delete c[d]
                            }, ea(c))
                        });
                    Cb(a)(Qa(E, function() {
                        b.observe(a.document.body, {
                            subtree: !0,
                            childList: !0
                        })
                    }))
                }
            }

            function Wq(a, c) {
                return function(b, d) {
                    var e, f = {
                        qc: ia(a)(Y),
                        key: a.Math.random(),
                        dir: 0
                    };
                    b.length && (f.qc = Ga(b[0]), f.key = parseFloat(b[1]), f.dir = Ga(b[2]));
                    z(d, c);
                    var g = (e = {
                            data: d
                        }, e.__yminfo =
                        I(":", ["__yminfo", f.qc, f.key, f.dir]), e);
                    return {
                        meta: f,
                        Yf: yb(a, g) || ""
                    }
                }
            }

            function Cb(a, c) {
                function b(e) {
                    n(c, d) ? e() : O(a, u(e, b), 100)
                }
                void 0 === c && (c = a);
                var d = (c.nodeType ? "contentWindow." : "") + "document.body";
                return Fa(function(e, f) {
                    b(f)
                })
            }

            function Nd(a, c) {
                var b = c.Rd,
                    d = b || "uid";
                b = b ? a.location.hostname : void 0;
                var e = wc(a),
                    f = Pa(a),
                    g = ia(a)(hg),
                    h = vj(a, c),
                    k = h[0];
                h = h[1];
                var l = e.C("d");
                wj(a, c);
                var m = !1;
                !h && k && (h = k, m = !0);
                if (!h) h = I("", [g, Wa(a, 1E6, 999999999)]), m = !0;
                else if (!l || 15768E3 < g - Ga(l)) m = !0;
                m && !c.Ta && (e.D(d,
                    h, 525600, b), e.D("d", "" + g, 525600, b));
                f.D(d, h);
                return h
            }

            function Xq(a, c) {
                return !c.Ta && wj(a, c)
            }

            function vj(a, c) {
                var b = Pa(a),
                    d = wc(a),
                    e = c.Rd || "uid";
                return [b.C(e), d.C(e)]
            }

            function zc(a) {
                var c = G(a),
                    b = c.C("hitId");
                b || (b = Wa(a), c.D("hitId", b));
                return b
            }

            function he(a, c, b) {
                var d = Na(c);
                return d && Zi(a, c, ua(["p", Yq[d], "c"]), Uf, b)
            }

            function ge(a, c) {
                var b = jc(ig, a, c);
                if (!b) {
                    var d = jc("div", a, c);
                    d && (sb(ig + ",div", d).length || (b = d))
                }
                return b
            }

            function Zi(a, c, b, d, e) {
                return J(function(f, g) {
                    var h = null;
                    g in xj ? h = c.getAttribute &&
                        c.getAttribute(xj[g]) : g in Yc && (h = "p" === g ? Yc[g](a, c, e) : "c" === g ? Yc[g](a, c, d) : Yc[g](a, c));
                    h && (h = h.slice(0, yj[g] || 100), f[g] = jg[g] ? "" + ec(h) : h);
                    return f
                }, {}, b)
            }

            function Wh(a, c, b) {
                if (Od(a)) return Ba(b.querySelectorAll(c));
                var d = zj(c.split(" "), b);
                return fa(function(e, f) {
                    return Ob(a)(e, d) === f
                }, d)
            }

            function zj(a, c) {
                var b = ra([], a),
                    d = b.shift();
                if (!d) return [];
                d = c.getElementsByTagName(d);
                return b.length ? rc(u(b, zj), Ba(d)) : Ba(d)
            }

            function bc(a, c) {
                if (c.querySelector) return c.querySelector(a);
                var b = sb(a, c);
                return b &&
                    b.length ? b[0] : null
            }

            function sb(a, c) {
                if (!c || !c.querySelectorAll) return [];
                var b = c.querySelectorAll(a);
                return b ? Ba(b) : []
            }

            function bj(a) {
                var c = null;
                try {
                    c = a.target || a.srcElement
                } catch (b) {}
                if (c) {
                    3 === c.nodeType && (c = c.parentNode);
                    for (a = c && c.nodeName && ("" + c.nodeName).toLowerCase(); n(c, "parentNode.nodeName") && ("a" !== a && "area" !== a || !c.href && !c.getAttribute("xlink:href"));) a = (c = c.parentNode) && c.nodeName && ("" + c.nodeName).toLowerCase();
                    return c.href ? c : null
                }
                return null
            }

            function tc(a, c) {
                var b = a.document,
                    d = z({
                        type: "text/javascript",
                        charset: "utf-8",
                        async: !0
                    }, c),
                    e = eb(a);
                if (e) {
                    var f = e("script");
                    qj(Ma, Mb(function(l) {
                        var m = l[0];
                        l = l[1];
                        "async" === m && l ? f.async = !0 : f[m] = l
                    }))(d);
                    try {
                        var g = kc("getElementsByTagName", b),
                            h = g("head")[0];
                        if (!h) {
                            var k = g("html")[0];
                            h = e("head");
                            k && k.appendChild(h)
                        }
                        h.insertBefore(f, h.firstChild);
                        return f
                    } catch (l) {}
                }
            }

            function Bf(a, c) {
                var b = Aj(a);
                K(c, b.rb) && (b.rb = fa(v(Aa(c), Dc), b.rb), b.rb.length || (sc(b.ib), b.ib = null))
            }

            function Af(a, c, b) {
                var d = Aj(c);
                K(b, d.rb) || d.rb.push(b);
                if (Va(d.ib)) {
                    b = eb(a);
                    if (!b) return null;
                    b =
                        b("iframe");
                    z(b.style, {
                        display: "none",
                        width: "1px",
                        height: "1px",
                        visibility: "hidden"
                    });
                    b.src = c;
                    a = dc(a);
                    if (!a) return null;
                    a.appendChild(b);
                    d.ib = b
                } else(a = n(d.ib, "contentWindow")) && a.postMessage("frameReinit", "*");
                return d.ib
            }

            function Zq(a, c) {
                var b = ca(a) ? a : [a];
                c = c || document;
                if (c.querySelectorAll) {
                    var d = I(", ", B(function(e) {
                        return "." + e
                    }, b));
                    return Ba(c.querySelectorAll(d))
                }
                if (c.getElementsByClassName) return rc(v(Da("getElementsByClassName", c), Ba), b);
                d = c.getElementsByTagName("*");
                b = "(" + I("|", b) + ")";
                return fa(u(b,
                    gc), Ba(d))
            }

            function mf(a, c, b) {
                for (var d = "", e = Ae(), f = Na(c) || "*"; c && c.parentNode && !K(f, ["BODY", "HTML"]);) d += e[f] || "*", d += Bj(a, c, b) || "", c = c.parentElement, f = Na(c) || "*";
                return db(d, 128)
            }

            function Bj(a, c, b) {
                if (a = Me(a, c)) {
                    a = a.childNodes;
                    for (var d = c && c.nodeName, e = 0, f = 0; f < a.length; f += 1)
                        if (d === (a[f] && a[f].nodeName)) {
                            if (c === a[f]) return e;
                            b && a[f] === b || (e += 1)
                        }
                }
                return 0
            }

            function Me(a, c) {
                var b = n(a, "document");
                return c && c !== b.documentElement ? c === Ec(a) ? b.documentElement : n(c, "parentNode") : null
            }

            function Kf(a, c) {
                var b =
                    kg(a, c),
                    d = b.left;
                b = b.top;
                var e = Ne(a, c);
                return [d, b, e[0], e[1]]
            }

            function Ne(a, c) {
                var b = n(a, "document");
                if (c === Ec(a) || c === b.documentElement) {
                    b = dc(a);
                    var d = Kc(a);
                    return [Math.max(b.scrollWidth, d[0]), Math.max(b.scrollHeight, d[1])]
                }
                return (b = Jc(c)) ? [b.width, b.height] : [c.offsetWidth, c.offsetHeight]
            }

            function kg(a, c) {
                var b = c,
                    d = n(a, "document"),
                    e = Na(b);
                if (!b || !b.ownerDocument || "PARAM" === e || b === Ec(a) || b === d.documentElement) return {
                    left: 0,
                    top: 0
                };
                if (d = Jc(b)) return b = Xf(a), {
                    left: Math.round(d.left + b.x),
                    top: Math.round(d.top +
                        b.y)
                };
                for (e = d = 0; b;) d += b.offsetLeft, e += b.offsetTop, b = b.offsetParent;
                return {
                    left: d,
                    top: e
                }
            }

            function jc(a, c, b) {
                if (!(c && c.Element && c.Element.prototype && c.document && b)) return null;
                if (c.Element.prototype.closest && Ia("closest", c.Element.prototype.closest) && b.closest) return b.closest(a);
                var d = ci(c);
                if (d) {
                    for (; b && 1 === b.nodeType && !d.call(b, a);) b = b.parentElement || b.parentNode;
                    return b && 1 === b.nodeType ? b : null
                }
                if (Od(c)) {
                    for (a = Ba((c.document || c.ownerDocument).querySelectorAll(a)); b && 1 === b.nodeType && -1 === Ob(c)(b,
                            a);) b = b.parentElement || b.parentNode;
                    return b && 1 === b.nodeType ? b : null
                }
                return null
            }

            function Od(a) {
                return !(!Ia("querySelectorAll", n(a, "Element.prototype.querySelectorAll")) || !a.document.querySelectorAll)
            }

            function sh(a, c, b) {
                var d = c.top,
                    e = c.bottom,
                    f = c.left,
                    g = b.w;
                b = b.h;
                a = a.Math;
                c = a.min(a.max(c.right, 0), g) - a.min(a.max(f, 0), g);
                return (a.min(a.max(e, 0), b) - a.min(a.max(d, 0), b)) * c
            }

            function Cj(a) {
                return Oe(a) && !Ya(Aa(a.type), $q) ? Pe(a) ? !a.checked : !a.value : ar(a) ? !a.value : br(a) ? 0 > a.selectedIndex : !0
            }

            function Na(a) {
                if (a) try {
                    var c =
                        a.nodeName;
                    if (ka(c)) return c;
                    c = a.tagName;
                    if (ka(c)) return c
                } catch (b) {}
            }

            function Dj(a, c) {
                var b = a.document.getElementsByTagName("form");
                return Ob(a)(c, Ba(b))
            }

            function cr(a, c, b) {
                b = kc("dispatchEvent", b || a.document);
                var d = null,
                    e = n(a, "Event.prototype.constructor");
                if (e && (Ia("(Event|Object|constructor)", e) || lg(a) && "[object Event]" === "" + e)) try {
                    d = new a.Event(c)
                } catch (f) {
                    if ((a = kc("createEvent", n(a, "document"))) && T(a)) {
                        try {
                            d = a(c)
                        } catch (g) {}
                        d && d.initEvent && d.initEvent(c, !1, !1)
                    }
                }
                d && b(d)
            }

            function Jc(a) {
                try {
                    return a.getBoundingClientRect &&
                        a.getBoundingClientRect()
                } catch (c) {
                    return "object" === typeof c && null !== c && 16389 === (c.uf && c.uf & 65535) ? {
                        top: 0,
                        bottom: 0,
                        left: 0,
                        width: 0,
                        height: 0,
                        right: 0
                    } : null
                }
            }

            function Xf(a) {
                var c = Ec(a),
                    b = n(a, "document");
                return {
                    x: a.pageXOffset || b.documentElement && b.documentElement.scrollLeft || c && c.scrollLeft || 0,
                    y: a.pageYOffset || b.documentElement && b.documentElement.scrollTop || c && c.scrollTop || 0
                }
            }

            function Kc(a) {
                var c = je(a);
                if (c) {
                    var b = c[2];
                    return [a.Math.round(c[0] * b), a.Math.round(c[1] * b)]
                }
                c = dc(a);
                return [n(c, "clientWidth") ||
                    a.innerWidth, n(c, "clientHeight") || a.innerHeight
                ]
            }

            function je(a) {
                var c = n(a, "visualViewport.width"),
                    b = n(a, "visualViewport.height");
                a = n(a, "visualViewport.scale");
                return la(c) || la(b) ? null : [Math.floor(c), Math.floor(b), a]
            }

            function dc(a) {
                var c = n(a, "document") || {},
                    b = c.documentElement;
                return "CSS1Compat" === c.compatMode ? b : Ec(a) || b
            }

            function Ec(a) {
                a = n(a, "document");
                try {
                    return a.getElementsByTagName("body")[0]
                } catch (c) {
                    return null
                }
            }

            function gc(a, c) {
                try {
                    return (new RegExp("(?:^|\\s)" + a + "(?:\\s|$)")).test(c.className)
                } catch (b) {
                    return !1
                }
            }

            function Fc(a) {
                var c;
                try {
                    if (c = a.target || a.srcElement) !c.ownerDocument && c.documentElement ? c = c.documentElement : c.ownerDocument !== document && (c = null)
                } catch (b) {}
                return c
            }

            function sc(a) {
                var c = a && a.parentNode;
                c && c.removeChild(a)
            }

            function Kb(a) {
                return a ? a.innerText || "" : ""
            }

            function Nf(a) {
                if (la(a)) return !1;
                a = a.nodeType;
                return 3 === a || 8 === a
            }

            function Ej(a, c, b) {
                void 0 === c && (c = "");
                void 0 === b && (b = "_ym");
                var d = "" + b + c;
                d && (d += "_");
                return {
                    Kd: dr(a),
                    C: function(e, f) {
                        var g = Fj(a, "" + d + e);
                        return Va(g) && !W(f) ? f : g
                    },
                    D: function(e,
                        f) {
                        Gj(a, "" + d + e, f);
                        return this
                    },
                    Fb: function(e) {
                        Hj(a, "" + d + e);
                        return this
                    }
                }
            }

            function Gj(a, c, b) {
                var d = mg(a);
                a = yb(a, b);
                if (!Va(a)) try {
                    d.setItem(c, a)
                } catch (e) {}
            }

            function Fj(a, c) {
                var b = mg(a);
                try {
                    return xb(a, b.getItem(c))
                } catch (d) {}
                return null
            }

            function Hj(a, c) {
                var b = mg(a);
                try {
                    b.removeItem(c)
                } catch (d) {}
            }

            function mg(a) {
                try {
                    return a.localStorage
                } catch (c) {}
                return null
            }

            function yb(a, c, b) {
                try {
                    return a.JSON.stringify(c, null, b)
                } catch (d) {
                    return null
                }
            }

            function me(a, c, b) {
                void 0 === b && (b = null);
                a.Ja || (a.Ja = nf());
                c && a.Ja.Wb(c,
                    b);
                return a.Ja
            }

            function Qe(a) {
                return {
                    N: function(c, b) {
                        var d = a.document,
                            e = c.K;
                        if (e && ng(a)) {
                            var f = da(a),
                                g = function(h) {
                                    ng(a) || (f.Zb(d, Ij, g), b());
                                    return h
                                };
                            f.F(d, Ij, g);
                            e.D("pr", "1")
                        } else b()
                    }
                }
            }

            function Pd(a) {
                return function(c, b, d) {
                    return function(e, f) {
                        var g = B(v(Uc, Xc([c, f]), ja), Jj[a] || []);
                        g = ra(g, d);
                        return Kj(c, b, g)(e)
                    }
                }
            }

            function Kj(a, c, b) {
                var d = Xb(a, c);
                return function(e) {
                    return Lj(b, e, !0).then(function() {
                        var f = e.na || {},
                            g = f.Ih,
                            h = void 0 === g ? "" : g;
                        g = f.Ba;
                        var k = void 0 === g ? "" : g;
                        f = f.Jh;
                        f = B(function(l) {
                            return Ea.Ra +
                                "//" + ("" + h + l || hc) + "/" + k
                        }, void 0 === f ? [hc] : f);
                        return d(e, f)
                    }).then(function(f) {
                        var g = f.Sc;
                        f = f.hg;
                        e.Bi = g;
                        e.Fj = f;
                        return Lj(b, e).then(u(g, P))
                    })
                }
            }

            function Xb(a, c) {
                return function(b, d) {
                    return Mj(a, c, d, b)
                }
            }

            function Mj(a, c, b, d, e, f) {
                var g;
                void 0 === e && (e = 0);
                void 0 === f && (f = 0);
                var h = z({
                        ha: []
                    }, d.ba),
                    k = c[f],
                    l = k[0];
                k = k[1];
                var m = b[e];
                h.Za && h.Za["Content-Type"] || !h.da || (h.Za = z({}, h.Za, (g = {}, g["Content-Type"] = "application/x-www-form-urlencoded", g)), h.da = "site-info=" + qe(h.da));
                h.$c = h.da ? "POST" : "GET";
                h.$a = er(a, d, l);
                h.Ba =
                    (d.na || {}).Ba;
                h.ha.push(l);
                z(d.ba, h);
                g = "" + m + (d.Pc && d.Pc.bi ? "/1" : "");
                var p = 0;
                p = fr(a, g, h);
                return k(g, h).then(function(r) {
                    var q = p,
                        t, x;
                    rb(a, (t = {}, t.name = "requestSuccess", t.data = (x = {}, x.body = r, x.requestId = q, x), t));
                    return {
                        Sc: r,
                        hg: e
                    }
                })["catch"](function(r) {
                    var q = p,
                        t, x;
                    rb(a, (t = {}, t.name = "requestFail", t.data = (x = {}, x.error = r, x.requestId = q, x), t));
                    q = f + 1 >= c.length;
                    t = e + 1 >= b.length;
                    q && t && Ua(r);
                    return Mj(a, c, b, d, !t && q ? e + 1 : e, q ? 0 : f + 1)
                })
            }

            function er(a, c, b) {
                var d = z({}, c.J);
                a = ia(a);
                c.K && (d["browser-info"] = Ka(c.K.l()).D("st",
                    a(hg)).Ha());
                !d.t && (c = c.Ja) && (c.D("ti", b), d.t = c.Ha());
                return d
            }

            function fr(a, c, b) {
                var d, e, f, g = Wa(a),
                    h = b.ha,
                    k = b.da,
                    l = b.Za,
                    m = b.$a;
                b = b.$c;
                rb(a, (d = {}, d.name = "request", d.data = (e = {}, e.url = c, e.requestId = g, e.senderParams = (f = {}, f.rBody = k, f.debugStack = h, f.rHeaders = l, f.rQuery = m, f.verb = b, f), e), d));
                return g
            }

            function Nj(a, c, b, d) {
                a[c] || (a[c] = []);
                b && !la(d) && Oj(a[c], b, d)
            }

            function Oj(a, c, b) {
                for (var d = [c, b], e = -1E4, f = 0; f < a.length; f += 1) {
                    var g = a[f],
                        h = g[0];
                    g = g[1];
                    if (b === g && h === c) return;
                    if (b < g && b >= e) {
                        a.splice(f, 0, d);
                        return
                    }
                    e =
                        g
                }
                a.push(d)
            }

            function Lj(a, c, b) {
                void 0 === b && (b = !1);
                return new L(function(d, e) {
                    function f(k, l) {
                        l();
                        d()
                    }
                    var g = a.slice();
                    g.push({
                        N: f,
                        Da: f
                    });
                    var h = cc(g, function(k, l) {
                        var m = b ? k.N : k.Da;
                        if (m) try {
                            m(c, l)
                        } catch (p) {
                            h(gr), e(p)
                        } else l()
                    });
                    h(Pj)
                })
            }

            function Sb(a, c, b) {
                var d = b || "as";
                if (a.postMessage && !a.attachEvent) {
                    b = da(a);
                    var e = "__ym__promise_" + Wa(a) + "_" + Wa(a),
                        f = E;
                    d = D(a, d, function(g) {
                        try {
                            var h = g.data
                        } catch (k) {
                            return
                        }
                        h === e && (f(), g.stopPropagation && g.stopPropagation(), c())
                    });
                    f = b.F(a, ["message"], d);
                    a.postMessage(e,
                        "*")
                } else O(a, c, 0, d)
            }

            function oh(a, c, b, d, e) {
                void 0 === d && (d = 1);
                void 0 === e && (e = "itc");
                c = cc(c, b);
                kd(a, c, d)(Qa(D(a, e), E))
            }

            function kd(a, c, b, d) {
                void 0 === b && (b = 1);
                void 0 === d && (d = Qj);
                og = Infinity === b;
                return Fa(function(e, f) {
                    function g() {
                        try {
                            var k = c(d(a, b));
                            h = h.concat(k)
                        } catch (l) {
                            return e(l)
                        }
                        c(hr);
                        if (c(Qd)) return f(h), Rj(a);
                        og ? (c(d(a, 1E4)), f(h), Rj(a)) : O(a, g, 100)
                    }
                    var h = [];
                    ir(g)
                })
            }

            function Rj(a) {
                if (pg.length) {
                    var c = pg.shift();
                    og ? c() : O(a, c, 100)
                } else qg = !1
            }

            function ir(a) {
                qg ? pg.push(a) : (qg = !0, a())
            }

            function Df(a) {
                return Fa(function(c,
                    b) {
                    b(a)
                })
            }

            function lp(a) {
                return Fa(function(c, b) {
                    a.then(b, c)
                })
            }

            function jr(a) {
                var c = [],
                    b = 0;
                return Fa(function(d, e) {
                    y(function(f, g) {
                        f(Qa(d, function(h) {
                            try {
                                c[g] = h, b += 1, b === a.length && e(c)
                            } catch (k) {
                                d(k)
                            }
                        }))
                    }, a)
                })
            }

            function kp(a) {
                var c = [],
                    b = !1;
                return Fa(function(d, e) {
                    function f(g) {
                        c.push(g) === a.length && d(c)
                    }
                    y(function(g) {
                        g(Qa(f, function(h) {
                            if (!b) try {
                                e(h), b = !0
                            } catch (k) {
                                f(k)
                            }
                        }))
                    }, a)
                })
            }

            function Qa(a, c) {
                return function(b) {
                    return b(a, c)
                }
            }

            function cc(a, c) {
                return Fa({
                    Sa: a,
                    Nd: c || P,
                    ue: !1,
                    wa: 0
                })
            }

            function Pj(a) {
                function c() {
                    function d() {
                        b = !0;
                        a.wa += 1
                    }
                    b = !1;
                    a.Nd(a.Sa[a.wa], function() {
                        d()
                    });
                    b || (a.wa += 1, d = u(a, Pj))
                }
                for (var b = !0; !Qd(a) && b;) c()
            }

            function Qj(a, c) {
                return function(b) {
                    var d = ia(a),
                        e = d(Y);
                    return Sj(function(f, g) {
                        d(Y) - e >= c && g(Tj)
                    })(b)
                }
            }

            function rg(a, c) {
                return function(b) {
                    var d = ia(a),
                        e = d(Y);
                    return sg(function(f) {
                        d(Y) - e >= c && Tj(f)
                    })(b)
                }
            }

            function sg(a) {
                return function(c) {
                    for (var b; c.Sa.length && !Qd(c);) b = c.Sa.pop(), b = c.Nd(b, c.Sa), a(c);
                    return b
                }
            }

            function kr(a) {
                Qd(a) && Ua(Ic("i"));
                var c = a.Nd(a.Sa[a.wa]);
                a.wa += 1;
                return c
            }

            function hr(a) {
                a.ue = !1
            }

            function Tj(a) {
                a.ue = !0
            }

            function gr(a) {
                a.wa = a.Sa.length
            }

            function Qd(a) {
                return a.ue || a.Sa.length <= a.wa
            }

            function Ab(a) {
                a = ia(a);
                return Math.round(a(Uj) / 50)
            }

            function Uj(a) {
                var c = a.Aa,
                    b = c[1];
                a = c[0] && b ? b() : Y(a) - a.Kh;
                return Math.round(a)
            }

            function hg(a) {
                return Math.round(Y(a) / 1E3)
            }

            function pb(a) {
                return Math.floor(Y(a) / 1E3 / 60)
            }

            function Y(a) {
                var c = a.Ce;
                return 0 !== c ? c : tg(a.l, a.Aa)
            }

            function dg(a) {
                var c = da(a),
                    b = Vj(a),
                    d = {
                        l: a,
                        Ce: 0,
                        Aa: b,
                        Kh: tg(a, b)
                    },
                    e = b[1];
                b[0] && e || c.F(a, ["beforeunload", "unload"], function() {
                    0 ===
                        d.Ce && (d.Ce = tg(a, d.Aa))
                });
                return Fa(d)
            }

            function lr(a) {
                return (10 > a ? "0" : "") + a
            }

            function Ji(a, c, b) {
                function d() {
                    f = 0;
                    g && (g = !1, f = O(a, d, b), e.T(h))
                }
                var e = Ed(a),
                    f, g = !1,
                    h;
                c.F(function(k) {
                    g = !0;
                    h = k;
                    f || d();
                    return E
                });
                return e
            }

            function mr(a, c) {
                return a.clearInterval(c)
            }

            function nr(a, c, b, d) {
                return a.setInterval(D(a, "i.err." + (d || "def"), c), b)
            }

            function O(a, c, b, d) {
                return Kd(a, D(a, "d.err." + (d || "def"), c), b)
            }

            function pd(a) {
                var c = {};
                return {
                    F: function(b, d) {
                        y(function(e) {
                            n(c, e) || (c[e] = Ed(a));
                            c[e].F(d)
                        }, b);
                        return this
                    },
                    ga: function(b,
                        d) {
                        y(function(e) {
                            n(c, e) && c[e].ga(d)
                        }, b);
                        return this
                    },
                    T: function(b, d) {
                        return n(c, b) ? D(a, "e." + d, c[b].T)(d) : []
                    }
                }
            }

            function Ed(a) {
                var c = [],
                    b = {};
                b.Aj = c;
                b.F = v(Da("push", c), u(b, P));
                b.ga = v(Fb(Ob(a))(c), Fb(Da("splice", c))(1), u(b, P));
                b.T = v(P, Fb(ja), or(c));
                return b
            }

            function Wj(a, c, b, d, e, f) {
                a = pr(a);
                var g = a.F,
                    h = a.ga;
                f = f ? h : g;
                if (c[f])
                    if (a.Ki) c[f](b, d, e);
                    else c[f]("on" + b, d)
            }

            function A(a, c, b) {
                return function() {
                    return D(arguments[0], a, c, b).apply(this, arguments)
                }
            }

            function D(a, c, b, d, e) {
                var f = Ua,
                    g = b || f;
                return function() {
                    var h =
                        d;
                    try {
                        h = g.apply(e || null, arguments)
                    } catch (k) {
                        ue(a, c, k)
                    }
                    return h
                }
            }

            function tg(a, c) {
                var b = c || Vj(a),
                    d = b[0];
                b = b[1];
                return !isNaN(d) && T(b) ? Math.round(b() + d) : a.Date.now ? a.Date.now() : (new a.Date).getTime()
            }

            function Vj(a) {
                a = yd(a);
                var c = n(a, "timing.navigationStart"),
                    b = n(a, "now");
                b && (b = H(b, a));
                return [c, b]
            }

            function yd(a) {
                return n(a, "performance") || n(a, "webkitPerformance")
            }

            function ue(a, c, b) {
                var d = "u.a.e",
                    e = "";
                b && ("object" === typeof b ? (b.unk && Ua(b), d = b.message, e = "string" === typeof b.stack && b.stack.replace(/\n/g,
                    "\\n") || "n.s.e.s") : d = "" + b);
                qr(d) || Ya(u(d, cb), rr) || sr(d) && .1 <= a.Math.random() || y(v(P, Xc(["jserrs", d, c, e]), ja), Xj)
            }

            function de() {
                var a = Ja(arguments);
                return Ua(Ra(a))
            }

            function Ra(a) {
                var c = "";
                ca(a) ? c = I(".", a) : ka(a) && (c = a);
                return Ic("err.kn(" + Ea.cc + ")" + c)
            }

            function pj(a) {
                return Ic("http." + a.status + ".st." + a.statusText + ".rt." + ("" + a.responseText).substring(0, 50))
            }

            function tr(a) {
                this.message = a
            }

            function rb(a, c) {
                if (Re(a)) {
                    var b = c.oa;
                    if (b) {
                        var d = b.split(":");
                        b = d[1];
                        d = Yj(uf(d[0]));
                        if ("1" === b || d) return
                    }
                    b = ur(a);
                    1E3 === b.length && b.shift();
                    b.push(c)
                }
            }

            function Se(a, c) {
                return -1 < Ac(R(a).href, "_ym_debug=" + c)
            }

            function di(a, c, b) {
                ug(a, "metrika_enabled", "1", 0, c, b, !0);
                var d = Zj(a);
                (d = d && d.metrika_enabled) && ak(a, "metrika_enabled", c, b, !0);
                return !!d
            }

            function ug(a, c, b, d, e, f, g) {
                void 0 === g && (g = !1);
                if (ei(a, te, c)) {
                    var h = c + "=" + encodeURIComponent(b) + ";";
                    h += "" + vr(a);
                    if (d) {
                        var k = new Date;
                        k.setTime(k.getTime() + 6E4 * d);
                        h += "expires=" + k.toUTCString() + ";"
                    }
                    e && (d = e.replace(wr, ""), h += "domain=" + d + ";");
                    try {
                        a.document.cookie = h + ("path=" + (f ||
                            "/")), g || (bk(a)[c] = b)
                    } catch (l) {}
                }
            }

            function te(a, c) {
                var b = bk(a);
                return b ? b[c] || null : null
            }

            function Zj(a) {
                try {
                    var c = a.document.cookie;
                    if (!la(c)) {
                        var b = {};
                        y(function(d) {
                            d = d.split("=");
                            var e = d[1];
                            b[db(d[0])] = db(ck(e))
                        }, (c || "").split(";"));
                        return b
                    }
                } catch (d) {}
                return null
            }

            function ei(a, c, b) {
                return !vg.length || K(b, Rd) ? !0 : J(function(d, e) {
                    return d && e(a, c, b)
                }, !0, vg)
            }

            function Cc(a) {
                return a ? v(Ma, Vf(function(c, b) {
                    var d = b[0],
                        e = b[1];
                    W(e) || la(e) || c.push(d + "=" + qe(e));
                    return c
                }, []), we("&"))(a) : ""
            }

            function xr(a) {
                return a ?
                    v(Mb(function(c) {
                        c = c.split("=");
                        var b = c[1];
                        return [c[0], la(b) ? void 0 : ck(b)]
                    }), Vf(function(c, b) {
                        c[b[0]] = b[1];
                        return c
                    }, {}))(a.split("&")) : {}
            }

            function ck(a) {
                var c = "";
                try {
                    c = decodeURIComponent(a)
                } catch (b) {}
                return c
            }

            function qe(a) {
                try {
                    return encodeURIComponent(a)
                } catch (c) {}
                a = I("", fa(function(c) {
                    return 55296 >= c.charCodeAt(0)
                }, a.split("")));
                return encodeURIComponent(a)
            }

            function db(a, c) {
                if (a) {
                    var b = dk ? dk.call(a) : ("" + a).replace(sj, "");
                    return c && b.length > c ? b.substring(0, c) : b
                }
                return ""
            }

            function kj(a) {
                var c = a.match(ek);
                if (c) {
                    a = c[1];
                    if (c = c[2]) return K(c, wg) ? c : !1;
                    if (a) return wg[0]
                }
                return !1
            }

            function R(a) {
                return J(function(c, b) {
                    var d = n(a, "location." + b);
                    c[b] = d ? "" + d : "";
                    return c
                }, {}, yr)
            }

            function fk(a) {
                return J(function(c, b) {
                    c[ff[b[0]].ea] = b[1];
                    return c
                }, {}, Ma(a))
            }

            function lc(a) {
                y(function(c) {
                    var b = c[1];
                    ff[c[0]] = {
                        ea: b.ea,
                        Ua: b.Ua
                    }
                }, Ma(a))
            }

            function am(a, c, b, d, e) {
                var f = "object" === typeof a ? a : {
                    id: a,
                    ca: d,
                    lc: e,
                    R: b
                };
                a = J(function(g, h) {
                    var k = h[1],
                        l = k.Ua;
                    k = f[k.ea];
                    g[h[0]] = l ? l(k) : k;
                    return g
                }, {}, Ma(c));
                fj(a, a.R || {});
                return a
            }

            function zr(a) {
                a =
                    M(a);
                return mc[a] && mc[a].Ri || null
            }

            function gk(a) {
                a = M(a);
                return mc[a] && mc[a].Qi
            }

            function fj(a, c) {
                var b = M(a),
                    d = n(c, "__ym.turbo_page"),
                    e = n(c, "__ym.turbo_page_id");
                mc[b] || (mc[b] = {});
                if (d || e) mc[b].Qi = d, mc[b].Ri = e
            }

            function hk(a) {
                return Te(a) || wd(a) || /mobile/i.test(lb(a)) || !W(n(a, "orientation"))
            }

            function rf(a, c) {
                if (Sd(a) && c) {
                    var b = lb(a).match(xg);
                    if (b && b.length) return +b[1] >= c
                }
                return !1
            }

            function sf(a, c) {
                var b = lb(a);
                return b && (b = b.match(Ar)) && 1 < b.length ? Ga(b[1]) >= c : !1
            }

            function ng(a) {
                return K("prerender", B(u(n(a,
                    "document"), n), ["webkitVisibilityState", "visibilityState"]))
            }

            function Wa(a, c, b) {
                var d = W(b);
                W(c) && d ? (d = 1, c = 1073741824) : d ? d = 1 : (d = c, c = b);
                return a.Math.floor(a.Math.random() * (c - d)) + d
            }

            function Br() {
                var a = Ja(arguments),
                    c = a[0];
                for (a = a.slice(1); a.length;) {
                    var b = a.shift(),
                        d;
                    for (d in b) Sc(b, d) && (c[d] = b[d]);
                    Sc(b, "toString") && (c.toString = b.toString)
                }
                return c
            }

            function Cr(a) {
                return function(c) {
                    return c ? a(c) : []
                }
            }

            function ik(a) {
                return W(a) ? [] : yg(function(c, b) {
                    c.push([b, a[b]]);
                    return c
                }, [], jk(a))
            }

            function jk(a) {
                var c = [],
                    b;
                for (b in a) Sc(a, b) && c.push(b);
                return c
            }

            function uf(a) {
                try {
                    return parseInt(a, 10)
                } catch (c) {
                    return null
                }
            }

            function ye(a, c) {
                return a.isFinite(c) && !a.isNaN(c) && "[object Number]" === Object.prototype.toString.call(c)
            }

            function Dr(a) {
                for (var c = [], b = a.length - 1; 0 <= b; --b) c[a.length - 1 - b] = a[b];
                return c
            }

            function ra(a, c) {
                y(v(P, Da("push", a)), c);
                return a
            }

            function zg(a, c) {
                return Array.prototype.sort.call(c, a)
            }

            function Id(a) {
                return a.splice(0, a.length)
            }

            function Ba(a) {
                return a ? ca(a) ? a : Ue ? Ue(a) : "number" === typeof a.length &&
                    0 <= a.length ? kk(a) : [] : []
            }

            function Er(a, c) {
                for (var b = 0; b < c.length; b += 1)
                    if (b in c && a.call(c, c[b], b)) return !0;
                return !1
            }

            function Fr(a, c) {
                return J(function(b, d, e) {
                    d = a(d, e);
                    return b.concat(ca(d) ? d : [d])
                }, [], c)
            }

            function lk(a, c) {
                return J(function(b, d, e) {
                    b.push(a(d, e));
                    return b
                }, [], c)
            }

            function Gr(a, c) {
                if (!Sd(a)) return !0;
                try {
                    c.call({
                        0: !0,
                        length: -Math.pow(2, 32) + 1
                    }, function() {
                        throw 1;
                    })
                } catch (b) {
                    return !1
                }
                return !0
            }

            function Hr(a, c) {
                for (var b = "", d = 0; d < c.length; d += 1) b += "" + (d ? a : "") + c[d];
                return b
            }

            function Ir(a, c) {
                return 1 <=
                    mk(Aa(a), c).length
            }

            function Jr(a, c) {
                for (var b = 0; b < c.length; b += 1)
                    if (a.call(c, c[b], b)) return c[b]
            }

            function mk(a, c) {
                return yg(function(b, d, e) {
                    a(d, e) && b.push(d);
                    return b
                }, [], c)
            }

            function vd(a, c, b) {
                return b ? a : c
            }

            function Kr(a, c) {
                return J(function(b, d, e) {
                    return b ? !!a(d, e) : !1
                }, !0, c)
            }

            function Zf(a, c, b) {
                try {
                    if (T(c)) {
                        var d = Ja(arguments).slice(3);
                        la(b) ? c.apply(null, d) : c.apply(b, d)
                    }
                } catch (e) {
                    Kd(a, u(e, Ua), 0)
                }
            }

            function Ua(a) {
                throw a;
            }

            function Kd(a, c, b) {
                return kc("setTimeout", a)(c, b)
            }

            function ha(a, c) {
                return kc("clearTimeout",
                    a)(c)
            }

            function Dd() {
                return []
            }

            function Gc() {
                return {}
            }

            function kc(a, c) {
                var b = n(c, a),
                    d = n(c, "constructor.prototype." + a) || b;
                try {
                    if (d && d.apply) return function() {
                        return d.apply(c, arguments)
                    }
                } catch (e) {
                    return b
                }
                return d
            }

            function gb(a, c, b) {
                return function() {
                    var d = G(arguments[0]),
                        e = b ? "global" : "m1240",
                        f = d.C(e, {}),
                        g = n(f, a);
                    g || (g = w(c), f[a] = g, d.D(e, f));
                    return g.apply(null, arguments)
                }
            }

            function Nc(a, c) {
                void 0 === c && (c = {});
                if (!a || 1 > a.length) return c;
                J(function(b, d, e) {
                    if (e === a.length - 1) return b;
                    e === a.length - 2 ? b[d] = a[e +
                        1] : Sc(b, d) || (b[d] = {});
                    return b[d]
                }, c, a);
                return c
            }

            function Td(a) {
                a = a.Ya = a.Ya || {};
                var c = a._metrika = a._metrika || {};
                return {
                    Ia: function(b, d) {
                        Ag.call(c, b) || (c[b] = d);
                        return this
                    },
                    D: function(b, d) {
                        c[b] = d;
                        return this
                    },
                    C: function(b, d) {
                        var e = c[b];
                        return Ag.call(c, b) || W(d) ? e : d
                    }
                }
            }

            function Sc(a, c) {
                return la(a) ? !1 : Ag.call(a, c)
            }

            function w(a, c) {
                var b = [],
                    d = [];
                var e = c ? c : P;
                return function() {
                    var f = Ja(arguments),
                        g = e.apply(void 0, f),
                        h = gf(g, d);
                    if (-1 !== h) return b[h];
                    f = a.apply(void 0, f);
                    b.push(f);
                    d.push(g);
                    return f
                }
            }

            function Ob(a) {
                if (Bg) return Bg;
                var c = !1;
                try {
                    c = [].indexOf && 0 === [void 0].indexOf(void 0)
                } catch (d) {}
                var b = a.Array && a.Array.prototype && na(a.Array.prototype.indexOf, "indexOf");
                a = void 0;
                return Bg = a = c && b ? function(d, e) {
                    return b.call(e, d)
                } : Lr
            }

            function Lr(a, c) {
                for (var b = 0; b < c.length; b += 1)
                    if (c[b] === a) return b;
                return -1
            }

            function ja(a, c) {
                return c ? a(c) : a()
            }

            function v() {
                var a = Ja(arguments),
                    c = a.shift();
                return function() {
                    var b = c.apply(void 0, arguments);
                    return J(nk, b, a)
                }
            }

            function Vf(a, c) {
                return C([a, c], J)
            }

            function yg(a, c, b) {
                for (var d = 0, e = b.length; d <
                    e;) c = a(c, b[d], d), d += 1;
                return c
            }

            function fb(a) {
                return Da("test", a)
            }

            function Da(a, c) {
                return H(c[a], c)
            }

            function u(a, c) {
                return H(c, null, a)
            }

            function C(a, c) {
                return H.apply(void 0, Cg([c, null], a))
            }

            function Mr(a) {
                return function() {
                    var c = Ja(arguments);
                    return a.apply(c[0], [c[1]].concat(c.slice(2)))
                }
            }

            function Nr() {
                var a = Ja(arguments),
                    c = a[0],
                    b = a[1],
                    d = a.slice(2);
                return function() {
                    var e = Cg(d, Ja(arguments));
                    if (Function.prototype.call) return Function.prototype.call.apply(c, Cg([b], e));
                    if (b) {
                        for (var f = "_b"; b[f];) f +=
                            "_" + f.length;
                        b[f] = c;
                        e = b[f] && ok(f, e, b);
                        delete b[f];
                        return e
                    }
                    return ok(c, e)
                }
            }

            function ok(a, c, b) {
                void 0 === c && (c = []);
                b = b || {};
                var d = c.length,
                    e = a;
                T(e) && (e = "d", b[e] = a);
                var f;
                d ? 1 === d ? f = b[e](c[0]) : 2 === d ? f = b[e](c[0], c[1]) : 3 === d ? f = b[e](c[0], c[1], c[2]) : 4 === d && (f = b[e](c[0], c[1], c[2], c[3])) : f = b[e]();
                return f
            }

            function Ja(a) {
                if (Ue) try {
                    return Ue(a)
                } catch (c) {}
                return kk(a)
            }

            function kk(a) {
                for (var c = a.length, b = [], d = 0; d < c; d += 1) b.push(a[d]);
                return b
            }

            function pa(a) {
                return !Va(a) && !W(a) && "[object Object]" === Object.prototype.toString.call(a)
            }

            function la(a) {
                return W(a) || Va(a)
            }

            function T(a) {
                return "function" === typeof a
            }

            function Fb(a) {
                return function(c) {
                    return function(b) {
                        return a(b, c)
                    }
                }
            }

            function sa(a) {
                return function(c) {
                    return function(b) {
                        return a(c, b)
                    }
                }
            }

            function nk(a, c) {
                return c(a)
            }

            function pq(a) {
                return a.replace(/\^/g, "\\^").replace(/\$/g, "\\$").replace(cg, "\\.").replace(/\[/g, "\\[").replace(/\]/g, "\\]").replace(/\|/g, "\\|").replace(/\(/g, "\\(").replace(/\)/g, "\\)").replace(/\?/g, "\\?").replace(/\*/g, "\\*").replace(/\+/g, "\\+").replace(/\{/g,
                    "\\{").replace(/\}/g, "\\}")
            }

            function Or(a) {
                return "" + a
            }

            function cb(a, c) {
                return !(!a || -1 === ib(a, c))
            }

            function Ac(a, c) {
                return ib(a, c)
            }

            function Pr(a, c) {
                for (var b = 0, d = a.length - c.length, e = 0; e < a.length; e += 1) {
                    b = a[e] === c[b] ? b + 1 : 0;
                    if (b === c.length) return e - c.length + 1;
                    if (!b && e > d) break
                }
                return -1
            }

            function ka(a) {
                return "string" === typeof a
            }

            function na(a, c) {
                return Ia(c, a) && a
            }

            function Ia(a, c) {
                var b = Ve(a, c);
                c && !b && Dg.push([a, c]);
                return b
            }

            function Ve(a, c) {
                if (!c || "function" !== typeof c) return !1;
                try {
                    var b = "" + c
                } catch (h) {
                    return !1
                }
                var d =
                    b.length;
                if (d > 35 + a.length) return !1;
                for (var e = d - 13, f = 0, g = 8; g < d; g += 1) {
                    f = "[native code]" [f] === b[g] || 7 === f && "-" === b[g] ? f + 1 : 0;
                    if (12 === f) return !0;
                    if (!f && g > e) break
                }
                return !1
            }

            function E() {}

            function Eg(a, c) {
                Eg = Object.setPrototypeOf || {
                    __proto__: []
                }
                instanceof Array && function(b, d) {
                    b.__proto__ = d
                } || function(b, d) {
                    for (var e in d) d.hasOwnProperty(e) && (b[e] = d[e])
                };
                return Eg(a, c)
            }

            function Dc(a) {
                return !a
            }

            function Za(a, c) {
                return c
            }

            function P(a) {
                return a
            }

            function Oa(a, c) {
                function b() {
                    this.constructor = a
                }
                Eg(a, c);
                a.prototype =
                    null === c ? Object.create(c) : (b.prototype = c.prototype, new b)
            }

            function Cg() {
                for (var a = 0, c = 0, b = arguments.length; c < b; c++) a += arguments[c].length;
                a = Array(a);
                var d = 0;
                for (c = 0; c < b; c++)
                    for (var e = arguments[c], f = 0, g = e.length; f < g; f++, d++) a[d] = e[f];
                return a
            }

            function n(a, c) {
                return a ? J(function(b, d) {
                    if (la(b)) return b;
                    try {
                        return b[d]
                    } catch (e) {}
                    return null
                }, a, c.split(".")) : null
            }

            function Qr(a) {
                return "[object Array]" === Object.prototype.toString.call(a)
            }

            function Rr() {}

            function Sr(a, c) {
                return function() {
                    a.apply(c, arguments)
                }
            }

            function La(a) {
                if (!(this instanceof La)) throw new TypeError("Promises must be constructed via new");
                if ("function" !== typeof a) throw new TypeError("not a function");
                this.Ma = 0;
                this.Ie = !1;
                this.Qa = void 0;
                this.Ab = [];
                pk(a, this)
            }

            function qk(a, c) {
                for (; 3 === a.Ma;) a = a.Qa;
                0 === a.Ma ? a.Ab.push(c) : (a.Ie = !0, La.Je(function() {
                    var b = 1 === a.Ma ? c.ki : c.oi;
                    if (null === b)(1 === a.Ma ? Fg : Ud)(c.promise, a.Qa);
                    else {
                        try {
                            var d = b(a.Qa)
                        } catch (e) {
                            Ud(c.promise, e);
                            return
                        }
                        Fg(c.promise, d)
                    }
                }))
            }

            function Fg(a, c) {
                try {
                    if (c === a) throw new TypeError("A promise cannot be resolved with itself.");
                    if (c && ("object" === typeof c || "function" === typeof c)) {
                        var b = c.then;
                        if (c instanceof La) {
                            a.Ma = 3;
                            a.Qa = c;
                            Gg(a);
                            return
                        }
                        if ("function" === typeof b) {
                            pk(Sr(b, c), a);
                            return
                        }
                    }
                    a.Ma = 1;
                    a.Qa = c;
                    Gg(a)
                } catch (d) {
                    Ud(a, d)
                }
            }

            function Ud(a, c) {
                a.Ma = 2;
                a.Qa = c;
                Gg(a)
            }

            function Gg(a) {
                2 === a.Ma && 0 === a.Ab.length && La.Je(function() {
                    a.Ie || La.xg(a.Qa)
                });
                for (var c = 0, b = a.Ab.length; c < b; c++) qk(a, a.Ab[c]);
                a.Ab = null
            }

            function Tr(a, c, b) {
                this.ki = "function" === typeof a ? a : null;
                this.oi = "function" === typeof c ? c : null;
                this.promise = b
            }

            function pk(a, c) {
                var b = !1;
                try {
                    a(function(d) {
                        b || (b = !0, Fg(c, d))
                    }, function(d) {
                        b || (b = !0, Ud(c, d))
                    })
                } catch (d) {
                    b || (b = !0, Ud(c, d))
                }
            }

            function ak(a, c, b, d, e) {
                void 0 === e && (e = !1);
                return ug(a, c, "", -100, b, d, e)
            }

            function Lc(a, c, b) {
                void 0 === c && (c = "_ym_");
                void 0 === b && (b = "");
                var d = Ur(a),
                    e = 1 === (d || "").split(".").length ? d : "." + d,
                    f = b ? "_" + b : "";
                return {
                    Fb: function(g, h, k) {
                        ak(a, "" + c + g + f, h || e, k);
                        return this
                    },
                    C: function(g) {
                        return te(a, "" + c + g + f)
                    },
                    D: function(g, h, k, l, m) {
                        ug(a, "" + c + g + f, h, k, l || e, m);
                        return this
                    }
                }
            }

            function xb(a, c) {
                if (!c) return null;
                try {
                    return a.JSON.parse(c)
                } catch (b) {
                    return null
                }
            }

            function ec(a) {
                a = "" + a;
                for (var c = 2166136261, b = a.length, d = 0; d < b; d += 1) c ^= a.charCodeAt(d), c += (c << 1) + (c << 4) + (c << 7) + (c << 8) + (c << 24);
                return c >>> 0
            }

            function bm(a, c, b, d) {
                var e = rk[b];
                return e ? function() {
                    var f = Ja(arguments);
                    try {
                        var g = d.apply(void 0, f);
                        var h = G(a);
                        h.Ia("mt", {});
                        var k = h.C("mt"),
                            l = k[e];
                        k[e] = l ? l + 1 : 1
                    } catch (m) {
                        Ua(m)
                    }
                    return g
                } : d
            }

            function Pc(a, c) {
                var b = Vr(a);
                return b ? (b.href = c, {
                    protocol: b.protocol,
                    host: b.host,
                    port: b.port,
                    hostname: b.hostname,
                    hash: b.hash,
                    search: b.search,
                    query: b.search.replace(/^\?/, ""),
                    pathname: b.pathname || "/",
                    path: (b.pathname || "/") + b.search,
                    href: b.href
                }) : {}
            }

            function sk(a) {
                return (a = R(a).hash.split("#")[1]) ? a.split("?")[0] : ""
            }

            function Wr(a, c) {
                var b = sk(a);
                tk = nr(a, function() {
                    var d = sk(a);
                    d !== b && (c(), b = d)
                }, 200, "t.h");
                return H(mr, null, a, tk)
            }

            function Xr(a, c, b, d) {
                var e, f, g = c.ca,
                    h = c.Fe,
                    k = c.xc,
                    l = G(a),
                    m = Ka((e = {}, e.wh = 1, e.pv = 1, e));
                e = n(d, "isTrusted");
                d && !la(e) && m.D("ite", zb(e));
                fe(g) && a.Ya && a.Ya.Direct && m.D("ad", "1");
                h && m.D("ut", "1");
                g = l.C("lastReferrer");
                d = R(a).href;
                k = {
                    J: (f = {}, f["page-url"] =
                        k || d, f["page-ref"] = g, f),
                    K: m
                };
                b(k, c)["catch"](D(a, "g.s"));
                l.D("lastReferrer", d)
            }

            function Yr(a, c, b) {
                function d() {
                    q || (r = !0, t = !1, q = !0, f())
                }

                function e() {
                    m = !0;
                    k(!1);
                    c()
                }

                function f() {
                    ha(a, l);
                    if (m) k(!1);
                    else {
                        var N = Math.max(0, b - (t ? x : x + p(Y) - F));
                        N ? l = O(a, e, N, "u.t.d.c") : e()
                    }
                }

                function g() {
                    t = r = q = !0;
                    x += p(Y) - F;
                    F = p(Y);
                    f()
                }

                function h() {
                    r || q || (x = 0);
                    F = p(Y);
                    r = q = !0;
                    t = !1;
                    f()
                }

                function k(N) {
                    N = N ? U.F : U.Zb;
                    N(a, ["blur"], g);
                    N(a, ["focus"], h);
                    N(a.document, ["click", "mousemove", "keydown", "scroll"], d)
                }
                var l = 0,
                    m = !1;
                if (lg(a)) return l =
                    O(a, c, b, "u.t.d"), C([a, l], ha);
                var p = ia(a),
                    r = !1,
                    q = !1,
                    t = !0,
                    x = 0,
                    F = p(Y),
                    U = da(a);
                k(!0);
                f();
                return function() {
                    ha(a, l);
                    k(!1)
                }
            }

            function ef(a, c, b, d) {
                return function() {
                    if (za(a, c)) {
                        var e = Ja(arguments);
                        return d.apply(void 0, e)
                    }
                }
            }

            function tb(a, c) {
                a = [a[0] >>> 16, a[0] & 65535, a[1] >>> 16, a[1] & 65535];
                c = [c[0] >>> 16, c[0] & 65535, c[1] >>> 16, c[1] & 65535];
                var b = [0, 0, 0, 0];
                b[3] += a[3] * c[3];
                b[2] += b[3] >>> 16;
                b[3] &= 65535;
                b[2] += a[2] * c[3];
                b[1] += b[2] >>> 16;
                b[2] &= 65535;
                b[2] += a[3] * c[2];
                b[1] += b[2] >>> 16;
                b[2] &= 65535;
                b[1] += a[1] * c[3];
                b[0] += b[1] >>>
                    16;
                b[1] &= 65535;
                b[1] += a[2] * c[2];
                b[0] += b[1] >>> 16;
                b[1] &= 65535;
                b[1] += a[3] * c[1];
                b[0] += b[1] >>> 16;
                b[1] &= 65535;
                b[0] += a[0] * c[3] + a[1] * c[2] + a[2] * c[1] + a[3] * c[0];
                b[0] &= 65535;
                return [b[0] << 16 | b[1], b[2] << 16 | b[3]]
            }

            function nc(a, c) {
                a = [a[0] >>> 16, a[0] & 65535, a[1] >>> 16, a[1] & 65535];
                c = [c[0] >>> 16, c[0] & 65535, c[1] >>> 16, c[1] & 65535];
                var b = [0, 0, 0, 0];
                b[3] += a[3] + c[3];
                b[2] += b[3] >>> 16;
                b[3] &= 65535;
                b[2] += a[2] + c[2];
                b[1] += b[2] >>> 16;
                b[2] &= 65535;
                b[1] += a[1] + c[1];
                b[0] += b[1] >>> 16;
                b[1] &= 65535;
                b[0] += a[0] + c[0];
                b[0] &= 65535;
                return [b[0] << 16 | b[1],
                    b[2] << 16 | b[3]
                ]
            }

            function Zc(a, c) {
                c %= 64;
                if (32 === c) return [a[1], a[0]];
                if (32 > c) return [a[0] << c | a[1] >>> 32 - c, a[1] << c | a[0] >>> 32 - c];
                c -= 32;
                return [a[1] << c | a[0] >>> 32 - c, a[0] << c | a[1] >>> 32 - c]
            }

            function mb(a, c) {
                c %= 64;
                return 0 === c ? a : 32 > c ? [a[0] << c | a[1] >>> 32 - c, a[1] << c] : [a[1] << c - 32, 0]
            }

            function xa(a, c) {
                return [a[0] ^ c[0], a[1] ^ c[1]]
            }

            function uk(a) {
                a = xa(a, [0, a[0] >>> 1]);
                a = tb(a, [4283543511, 3981806797]);
                a = xa(a, [0, a[0] >>> 1]);
                a = tb(a, [3301882366, 444984403]);
                return a = xa(a, [0, a[0] >>> 1])
            }

            function Zr(a, c) {
                void 0 === c && (c = 210);
                var b = a ||
                    "",
                    d = c || 0,
                    e = b.length - b.length % 16;
                d = {
                    V: [0, d],
                    X: [0, d]
                };
                for (var f = 0; f < e; f += 16) {
                    var g = d,
                        h = [a.charCodeAt(f + 4) & 255 | (a.charCodeAt(f + 5) & 255) << 8 | (a.charCodeAt(f + 6) & 255) << 16 | (a.charCodeAt(f + 7) & 255) << 24, a.charCodeAt(f) & 255 | (a.charCodeAt(f + 1) & 255) << 8 | (a.charCodeAt(f + 2) & 255) << 16 | (a.charCodeAt(f + 3) & 255) << 24],
                        k = [a.charCodeAt(f + 12) & 255 | (a.charCodeAt(f + 13) & 255) << 8 | (a.charCodeAt(f + 14) & 255) << 16 | (a.charCodeAt(f + 15) & 255) << 24, a.charCodeAt(f + 8) & 255 | (a.charCodeAt(f + 9) & 255) << 8 | (a.charCodeAt(f + 10) & 255) << 16 | (a.charCodeAt(f +
                            11) & 255) << 24];
                    h = tb(h, We);
                    h = Zc(h, 31);
                    h = tb(h, Xe);
                    g.V = xa(g.V, h);
                    g.V = Zc(g.V, 27);
                    g.V = nc(g.V, g.X);
                    g.V = nc(tb(g.V, [0, 5]), [0, 1390208809]);
                    k = tb(k, Xe);
                    k = Zc(k, 33);
                    k = tb(k, We);
                    g.X = xa(g.X, k);
                    g.X = Zc(g.X, 31);
                    g.X = nc(g.X, g.V);
                    g.X = nc(tb(g.X, [0, 5]), [0, 944331445])
                }
                e = b.length % 16;
                f = b.length - e;
                g = [0, 0];
                h = [0, 0];
                switch (e) {
                    case 15:
                        h = xa(h, mb([0, b.charCodeAt(f + 14)], 48));
                    case 14:
                        h = xa(h, mb([0, b.charCodeAt(f + 13)], 40));
                    case 13:
                        h = xa(h, mb([0, b.charCodeAt(f + 12)], 32));
                    case 12:
                        h = xa(h, mb([0, b.charCodeAt(f + 11)], 24));
                    case 11:
                        h = xa(h, mb([0,
                            b.charCodeAt(f + 10)
                        ], 16));
                    case 10:
                        h = xa(h, mb([0, b.charCodeAt(f + 9)], 8));
                    case 9:
                        h = xa(h, [0, b.charCodeAt(f + 8)]), h = tb(h, Xe), h = Zc(h, 33), h = tb(h, We), d.X = xa(d.X, h);
                    case 8:
                        g = xa(g, mb([0, b.charCodeAt(f + 7)], 56));
                    case 7:
                        g = xa(g, mb([0, b.charCodeAt(f + 6)], 48));
                    case 6:
                        g = xa(g, mb([0, b.charCodeAt(f + 5)], 40));
                    case 5:
                        g = xa(g, mb([0, b.charCodeAt(f + 4)], 32));
                    case 4:
                        g = xa(g, mb([0, b.charCodeAt(f + 3)], 24));
                    case 3:
                        g = xa(g, mb([0, b.charCodeAt(f + 2)], 16));
                    case 2:
                        g = xa(g, mb([0, b.charCodeAt(f + 1)], 8));
                    case 1:
                        g = xa(g, [0, b.charCodeAt(f)]), g = tb(g,
                            We), g = Zc(g, 31), g = tb(g, Xe), d.V = xa(d.V, g)
                }
                d.V = xa(d.V, [0, b.length]);
                d.X = xa(d.X, [0, b.length]);
                d.V = nc(d.V, d.X);
                d.X = nc(d.X, d.V);
                d.V = uk(d.V);
                d.X = uk(d.X);
                d.V = nc(d.V, d.X);
                d.X = nc(d.X, d.V);
                return ("00000000" + (d.V[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (d.V[1] >>> 0).toString(16)).slice(-8) + ("00000000" + (d.X[0] >>> 0).toString(16)).slice(-8) + ("00000000" + (d.X[1] >>> 0).toString(16)).slice(-8)
            }

            function Vd(a, c, b) {
                var d = c.getAttribute("itemtype");
                b = sb('[itemprop~="' + b + '"]', c);
                return d ? fa(function(e) {
                    return e.parentNode &&
                        jc("[itemtype]", a, e.parentNode) === c
                }, b) : b
            }

            function hb(a, c, b) {
                return (a = Vd(a, c, b)) && a.length ? a[0] : null
            }

            function $a(a) {
                if (!a) return "";
                a = ca(a) ? a : [a];
                return a.length ? a[0].getAttribute("content") || Kb(a[0]) : ""
            }

            function vk(a) {
                return a ? a.attributes && a.getAttribute("datetime") ? a.getAttribute("datetime") : $a(a) : ""
            }

            function sd(a, c, b) {
                a = c && (cb(c.className, "ym-disable-keys") || cb(c.className, "-metrika-nokeys"));
                return b && c ? a || !!Zq(["ym-disable-keys", "-metrika-nokeys"], c).length : a
            }

            function Gf(a, c) {
                return Oe(c) ? "password" ===
                    c.type || c.name && K(c.name.toLowerCase(), wk) || c.id && K(c.id.toLowerCase(), wk) : !1
            }

            function xk(a, c) {
                var b = Math.max(0, Math.min(c, 65535));
                ra(a, [b >> 8, b & 255])
            }

            function Ub(a, c) {
                ra(a, [c & 255])
            }

            function kb(a, c, b) {
                return -1 !== Ob(a)(b, $r) ? (Ub(c, b), !1) : !0
            }

            function S(a, c) {
                for (var b = Math.max(0, c | 0); 127 < b;) ra(a, [b & 127 | 128]), b >>= 7;
                ra(a, [b])
            }

            function Hg(a, c) {
                S(a, c.length);
                for (var b = 0; b < c.length; b += 1) S(a, c.charCodeAt(b))
            }

            function Ig(a, c) {
                var b = c;
                255 < b.length && (b = b.substr(0, 255));
                a.push(b.length);
                for (var d = 0; d < b.length; d +=
                    1) xk(a, b.charCodeAt(d))
            }

            function as(a, c) {
                var b = [];
                if (kb(a, b, 27)) return [];
                S(b, c);
                return b
            }

            function bs(a, c) {
                var b = Na(c);
                if (!b) return c[Xa] = -1, null;
                var d = +c[Xa];
                if (!isFinite(d) || 0 >= d) return null;
                if (c.attributes)
                    for (var e = c; e;) {
                        if (e.attributes.kj) return null;
                        e = e.parentElement
                    }
                e = 64;
                var f = Me(a, c),
                    g = f && f[Xa] ? f[Xa] : 0;
                0 > g && (g = 0);
                b = (b || "").toUpperCase();
                var h = cs()[b];
                h || (e |= 2);
                var k = Bj(a, c);
                k || (e |= 4);
                var l = Kf(a, c);
                (f = f ? Kf(a, f) : null) && l[0] === f[0] && l[1] === f[1] && l[2] === f[2] && l[3] === f[3] && (e |= 8);
                vc[d].xf = l[0] +
                    "x" + l[1];
                vc[d].size = l[2] + "x" + l[3];
                c.id && "string" === typeof c.id && (e |= 32);
                f = [];
                if (kb(a, f, 1)) return null;
                S(f, d);
                Ub(f, e);
                S(f, g);
                h ? Ub(f, h) : Ig(f, b);
                k && S(f, k);
                e & 8 || (S(f, l[0]), S(f, l[1]), S(f, l[2]), S(f, l[3]));
                e & 32 && Ig(f, c.id);
                Ub(f, 0);
                return f
            }

            function ds(a, c) {
                var b = c[Xa];
                if (!b || 0 > b || !If(c) || !c.form || bi(a, c.form)) return [];
                var d = Dj(a, c.form);
                if (0 > d) return [];
                if (Oe(c)) {
                    var e = {
                        text: 0,
                        color: 0,
                        qc: 0,
                        oj: 0,
                        "datetime-local": 0,
                        email: 0,
                        uf: 0,
                        Ej: 0,
                        search: 0,
                        Jj: 0,
                        time: 0,
                        url: 0,
                        month: 0,
                        Lj: 0,
                        password: 2,
                        Dj: 3,
                        mj: 4,
                        file: 6,
                        image: 7
                    };
                    e = e[c.type]
                } else {
                    e = {
                        hj: 1,
                        ij: 5
                    };
                    var f = Na(c);
                    e = W(f) ? "" : e[f]
                }
                if ("number" !== typeof e) return [];
                f = -1;
                for (var g = c.form.elements, h = g.length, k = 0, l = 0; k < h; k += 1)
                    if (g[k].name === c.name) {
                        if (g[k] === c) {
                            f = l;
                            break
                        }
                        l += 1
                    }
                if (0 > f) return [];
                g = [];
                if (kb(a, g, 7)) return [];
                S(g, b);
                S(g, d);
                S(g, e);
                Hg(g, c.name || "");
                S(g, f);
                return g
            }

            function uc(a, c, b) {
                void 0 === b && (b = []);
                for (var d = []; c && !co(a, c, b); c = Me(a, c)) d.push(c);
                y(function(e) {
                    vc.counter += 1;
                    var f = vc.counter;
                    e[Xa] = f;
                    vc[f] = {};
                    f = bs(a, e);
                    e = ds(a, e);
                    f && e && (ra(b, f), ra(b, e))
                }, es(d));
                return b
            }

            function fs(a) {
                var c = a.qa;
                if (!rd || c && !c.fromElement) return Zh(a)
            }

            function gs(a) {
                var c = a.qa;
                if (c && !c.toElement) return Jf(a)
            }

            function yk(a) {
                var c = Fc(a.qa);
                if (c && se(c)) {
                    var b = Yh(a, c),
                        d = b.concat;
                    var e = Ab(a.l),
                        f = [];
                    kb(a.l, f, 17) ? a = [] : (S(f, e), S(f, c[Xa]), a = f);
                    return d.call(b, a)
                }
            }

            function zk(a) {
                var c = a.l,
                    b = a.qa.target;
                if (b && se(b)) {
                    c = uc(c, b);
                    var d = c.concat;
                    var e = Ab(a.l),
                        f = [];
                    kb(a.l, f, 18) ? a = [] : (S(f, e), S(f, b[Xa]), a = f);
                    return d.call(c, a)
                }
            }

            function Ak(a) {
                var c = a.l,
                    b = Fc(a.qa);
                if (!b || Gf(c, b) || sd(c, b)) return [];
                if (If(b)) {
                    var d =
                        G(c).C("isEU"),
                        e = Qc(c, b, d),
                        f = e.Va;
                    d = e.qb;
                    e = e.hb;
                    if (Pe(b)) var g = b.checked;
                    else g = b.value, g = f ? I("", Bk(g.split(""))) : g;
                    c = uc(c, b);
                    f = c.concat;
                    var h = Ab(a.l);
                    d = d && !e;
                    e = [];
                    kb(a.l, e, 39) ? a = [] : (S(e, h), S(e, b[Xa]), Ig(e, String(g)), Ub(e, d ? 1 : 0), a = e);
                    return f.call(c, a)
                }
            }

            function Ye(a) {
                var c = a.l,
                    b = a.qa,
                    d = Fc(b);
                if (!d || "SCROLLBAR" === d.nodeName) return [];
                var e = [],
                    f = u(e, ra);
                d && se(d) ? f(Yh(a, d)) : f(uc(c, d));
                var g = $i(c, b);
                f = e.concat;
                a = Ab(a.l);
                var h = b.type,
                    k = [g.x, g.y];
                g = b.which;
                b = b.button;
                var l;
                var m = Ne(c, d);
                var p = m[0];
                for (m =
                    m[1]; d && (!p || !m);)
                    if (d = Me(c, d)) m = Ne(c, d), p = m[0], m = m[1];
                d ? (p = d[Xa], !p || 0 > p ? c = [] : (m = (l = {}, l.mousemove = 2, l.click = 32, l.dblclick = 33, l.mousedown = 4, l.mouseup = 30, l.touch = 12, l)[h]) ? (l = [], d = kg(c, d), kb(c, l, m) ? c = [] : (S(l, a), S(l, p), S(l, Math.max(0, k[0] - d.left)), S(l, Math.max(0, k[1] - d.top)), /^mouse(up|down)|click$/.test(h) && (c = g || b, Ub(l, 2 > c ? 1 : c === (g ? 2 : 4) ? 4 : 2)), c = l)) : c = []) : c = [];
                return f.call(e, c)
            }

            function hs(a) {
                var c = null,
                    b = a.l,
                    d = b.document;
                if (b.getSelection) {
                    d = void 0;
                    try {
                        d = b.getSelection()
                    } catch (g) {
                        return []
                    }
                    if (Va(d)) return [];
                    var e = "" + d;
                    c = d.anchorNode
                } else d.selection && d.selection.createRange && (d = d.selection.createRange(), e = d.text, c = d.parentElement());
                if ("string" !== typeof e) return [];
                try {
                    for (; c && 1 !== c.nodeType;) c = c.parentNode
                } catch (g) {
                    return []
                }
                if (!c) return [];
                d = Qc(b, c).Va || sd(b, c, !0);
                c = c.getElementsByTagName("*");
                for (var f = 0; f < c.length && !d;) d = c[f], d = Qc(b, d).Va || sd(b, d, !0), f += 1;
                if (e !== Jg) return Jg = e, d = d ? I("", Bk(e.split(""))) : e, e = Ab(a.l), 0 === d.length ? d = b = "" : 100 >= d.length ? (b = d, d = "") : 200 >= d.length ? (b = d.substr(0, 100), d = d.substr(100)) :
                    (b = d.substr(0, 97), d = d.substr(d.length - 97)), c = [], kb(a.l, c, 29) ? a = [] : (S(c, e), Hg(c, b), Hg(c, d), a = c), a
            }

            function is(a) {
                return Ye(a).concat(hs(a) || [])
            }

            function Ck(a) {
                return (a.shiftKey ? 2 : 0) | (a.ctrlKey ? 4 : 0) | (a.altKey ? 1 : 0) | (a.metaKey ? 8 : 0) | (a.ctrlKey || a.altKey ? 16 : 0)
            }

            function Dk(a) {
                var c = [];
                Kg || (Kg = !0, Jg && ra(c, as(a.l, Ab(a.l))), Sb(a.l, function() {
                    Kg = !1
                }, "fv.c"));
                return c
            }

            function Ek(a, c, b, d) {
                c = Fc(c);
                if (!c || Lf(a, c)) return [];
                var e = Qc(a, c),
                    f = e.qb,
                    g = e.hb;
                e = e.Va;
                var h = G(a);
                if (!g && (f && h.C("isEU") || sd(a, c))) a = [];
                else {
                    f =
                        uc(a, c);
                    g = f.concat;
                    var k = Ab(a);
                    h = [];
                    if (kb(a, h, 38)) a = [];
                    else {
                        S(h, k);
                        xk(h, b);
                        Ub(h, d);
                        a = c[Xa];
                        if (!a || 0 > a) a = 0;
                        S(h, a);
                        Ub(h, e ? 1 : 0);
                        a = h
                    }
                    a = g.call(f, a)
                }
                return a
            }

            function js(a) {
                var c = a.l,
                    b = a.qa,
                    d = b.keyCode,
                    e = Ck(b),
                    f = [],
                    g = u(f, ra);
                if ({
                        3: 1,
                        8: 1,
                        9: 1,
                        13: 1,
                        16: 1,
                        17: 1,
                        18: 1,
                        19: 1,
                        20: 1,
                        27: 1,
                        33: 1,
                        34: 1,
                        35: 1,
                        36: 1,
                        37: 1,
                        38: 1,
                        39: 1,
                        40: 1,
                        45: 1,
                        46: 1,
                        91: 1,
                        92: 1,
                        93: 1,
                        106: 1,
                        110: 1,
                        111: 1,
                        144: 1,
                        145: 1
                    }[d] || 112 <= d && 123 >= d || 96 <= d && 105 >= d || e & 16) 19 === d && 4 === (e & -17) && (d = 144), g(Ek(c, b, d, e | 16)), Lg = !1, Sb(c, function() {
                    Lg = !0
                }, "fv.kd"), !(67 === d &&
                    e & 4) || e & 1 || e & 2 || g(Dk(a));
                return f
            }

            function ks(a) {
                var c = a.l;
                a = a.qa;
                var b = [];
                Lg && !Mg && 0 !== a.which && (ra(b, Ek(c, a, a.charCode || a.keyCode, Ck(a))), Mg = !0, Sb(c, function() {
                    Mg = !1
                }, "fv.kp"));
                return b
            }

            function Fk(a) {
                var c = a.l,
                    b = Fc(a.qa);
                if (!b || bi(c, b)) return [];
                var d = [];
                if ("FORM" === b.nodeName) {
                    for (var e = b.elements, f = 0; f < e.length; f += 1) Cj(e[f]) || ra(d, uc(c, e[f]));
                    a = Ab(a.l);
                    e = Dj(c, b);
                    if (0 > e) c = [];
                    else {
                        f = b.elements;
                        var g = f.length;
                        b = [];
                        for (var h = 0; h < g; h += 1)
                            if (!Cj(f[h])) {
                                var k = f[h][Xa];
                                k && 0 < k && b.push(k)
                            }
                        f = [];
                        if (kb(c, f,
                                11)) c = [];
                        else {
                            S(f, a);
                            S(f, e);
                            S(f, b.length);
                            for (c = 0; c < b.length; c += 1) S(f, b[c]);
                            c = f
                        }
                    }
                    ra(d, c)
                }
                return d
            }

            function ls(a) {
                var c = a.flush;
                a = Fc(a.qa);
                "BODY" === Na(a) && c()
            }

            function vn(a, c) {
                var b, d = Fc(c),
                    e = Ea.kc,
                    f = Td(a);
                if (d && gc("ym-advanced-informer", d)) {
                    var g = f.C("ifc", 0) + 1;
                    f.D("ifc", g);
                    g = d.getAttribute("data-lang");
                    var h = Ga(d.getAttribute("data-cid") || "");
                    if (h || 0 === h)(e = n(a, "Ya." + e + ".informer")) ? e((b = {}, b.i = d, b.id = h, b.lang = g, b)) : f.D("ib", !0), b = c || window.event, b.preventDefault ? b.preventDefault() : b.returnValue = !1
                }
            }

            function nh(a, c, b, d) {
                return function() {
                    var e = Ja(arguments);
                    e = d.apply(void 0, e);
                    return W(e) ? za(a, c) : e
                }
            }

            function mh(a, c, b, d) {
                return D(a, "cm." + b, d)
            }

            function $l(a, c, b, d, e) {
                return b.length && e ? C(J(function(f, g, h) {
                    return b[h] ? f.concat(C([a, c, d], g)) : f
                }, [], b), v)()(e) : e
            }
            var $c = {
                    construct: "Metrika2",
                    callbackPostfix: "2",
                    version: "d7x9vdjtr9ih7tm6iawxyi8v",
                    host: "mc.yandex.ru"
                },
                Dg = [],
                cg = /\./g,
                Gk = na(String.prototype.indexOf, "indexOf"),
                ib = Gk ? function(a, c) {
                    return Gk.call(a, c)
                } : Pr,
                Aa = sa(function(a, c) {
                    return a ===
                        c
                }),
                od = sa(function(a, c) {
                    a(c);
                    return c
                }),
                Fa = sa(nk),
                Va = Aa(null),
                W = Aa(void 0),
                Ue = na(Array.from, "from"),
                Hk = na(Function.prototype.bind, "bind"),
                H = Hk ? Mr(Hk) : Nr,
                Ik = na(Array.prototype.reduce, "reduce"),
                J = Ik ? function(a, c, b) {
                    return Ik.call(b, a, c)
                } : yg,
                qj = v,
                Be = v(P, ja),
                Bg, gf = Ob(window),
                Lm = Fb(gf),
                Ag = Object.prototype.hasOwnProperty,
                G = w(Td),
                Q = Fb(n),
                Ta = Q("length"),
                Xc = sa(C),
                Ii = sa(Da),
                Jk = na(Array.prototype.every, "every"),
                Jp = Jk ? function(a, c) {
                    return Jk.call(c, a)
                } : Kr,
                Lb = C([1, null], vd),
                zb = C([1, 0], vd),
                Gb = Boolean,
                Kk = na(Array.prototype.filter,
                    "filter"),
                fa = Kk ? function(a, c) {
                    return Kk.call(c, a)
                } : mk,
                ua = u(Gb, fa),
                ms = sa(fa),
                Lk = na(Array.prototype.find, "find"),
                qb = Lk ? function(a, c) {
                    return Lk.call(c, a)
                } : Jr,
                Mk = na(Array.prototype.includes, "includes"),
                K = Mk ? function(a, c, b) {
                    return Mk.call(c, a, b)
                } : Ir,
                pc = Fb(K),
                Nk = na(Array.prototype.join, "join"),
                I = Nk ? function(a, c) {
                    return Nk.call(c, a)
                } : Hr,
                we = sa(I),
                Ok = w(function(a) {
                    var c = n(a, "navigator") || {};
                    a = n(c, "userAgent") || "";
                    c = n(c, "vendor") || "";
                    return {
                        lf: -1 < ib(c, "Apple"),
                        ig: a
                    }
                }),
                lb = w(Q("navigator.userAgent")),
                xg = /Firefox\/([0-9]+)/i,
                Sd = w(function(a) {
                    var c = n(a, "document.documentElement.style"),
                        b = n(a, "InstallTrigger");
                    a = -1 !== (n(a, "navigator.userAgent") || "").toLowerCase().search(xg);
                    xg.lastIndex = 0;
                    return !(!(c && "MozAppearance" in c) || la(b)) || a
                }),
                Pk = na(Array.isArray, "isArray"),
                ca = Pk ? function(a) {
                    return Pk(a)
                } : Qr,
                Qk = na(Array.prototype.map, "map"),
                B = Qk && Gr(window, Array.prototype.map) ? function(a, c) {
                    return c && 0 < c.length ? Qk.call(c, a) : []
                } : lk,
                y = B,
                Rk = na(Array.prototype.flatMap, "flatMap"),
                rc = Rk ? function(a, c) {
                    return Rk.call(c, a)
                } : Fr,
                Mb = sa(B),
                or = Fb(B),
                Sk = na(Array.prototype.some, "some"),
                Ya = Sk ? function(a, c) {
                    return Sk.call(c, a)
                } : Er,
                He = w(Ob),
                Uc = Q("0"),
                ns = sa(zg),
                Tk = na(Array.prototype.reverse, "reverse"),
                es = Tk ? function(a) {
                    return Tk.call(a)
                } : Dr,
                Uk = Fb(parseInt),
                Ga = Uk(10),
                Ng = Uk(2),
                Vk = na(Object.keys, "keys"),
                Wk = na(Object.entries, "entries"),
                Ma = Wk ? Cr(Wk) : ik,
                ea = Vk ? function(a) {
                    return Vk(a)
                } : jk,
                Xk = na(Object.values, "values"),
                os = v(ik, u(Q("1"), lk)),
                qh = Xk ? function(a) {
                    return Xk(a)
                } : os,
                z = Object.assign || Br,
                Xh = sa(function(a, c) {
                    return z({}, a, c)
                }),
                ld = w(v(Q("String.fromCharCode"),
                    u("fromCharCode", Ia), Dc)),
                Te = w(v(lb, fb(/ipad|iphone|ipod/i))),
                Qf = w(function(a) {
                    return n(a, "navigator.platform") || ""
                }),
                zd = w(function(a) {
                    a = Ok(a);
                    var c = a.ig;
                    return a.lf && !c.match("CriOS")
                }),
                ps = fb(/Android.*Version\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]|Android.*Version\/[0-9][0-9.]*\s(?:Mobile\s)?Safari\/[0-9][0-9.]*\sChrome\/[0-9][0-9.]*|; wv\).*Chrome\/[0-9][0-9.]*\sMobile/),
                qs = fb(/; wv\)/),
                xd = w(function(a) {
                    a = lb(a);
                    return qs(a) || ps(a)
                }),
                rs = /Chrome\/(\d+)\./,
                ss = w(function(a) {
                    return (a = (n(a, "navigator.userAgent") ||
                        "").match(rs)) && a.length ? 76 <= Ga(a[1]) : !1
                }),
                wd = w(function(a) {
                    var c = (lb(a) || "").toLowerCase();
                    a = Qf(a);
                    return cb(c, "android") && cb(c, "mobile") && /^android|linux armv/i.test(a)
                }),
                ts = "other none unknown wifi ethernet bluetooth cellular wimax mixed".split(" "),
                us = w(function(a) {
                    var c = n(a, "navigator.connection.type");
                    if (W(c)) return null;
                    a = He(a)(c, ts);
                    return -1 === a ? c : "" + a
                }),
                lg = w(v(Q("document.addEventListener"), Dc)),
                Yk = w(function(a) {
                    var c = n(a, "navigator") || {};
                    return J(function(b, d) {
                        return b || n(c, d)
                    }, "", ["language",
                        "userLanguage", "browserLanguage", "systemLanguage"
                    ])
                }),
                vh = w(function(a) {
                    var c = n(a, "navigator") || {};
                    a = Yk(a);
                    ka(a) || (a = "", c = n(c, "languages.0"), ka(c) && (a = c));
                    return a.toLowerCase().split("-")[0]
                }),
                jb = w(function(a) {
                    return (n(a, "top") || a) !== a
                }),
                vs = w(Q("top.contentWindow")),
                ws = w(function(a) {
                    var c = !1;
                    try {
                        c = a.navigator.javaEnabled()
                    } catch (b) {}
                    return c
                }),
                xs = w(function(a) {
                    var c = "__webdriver_evaluate __selenium_evaluate __webdriver_script_function __webdriver_script_func __webdriver_script_fn __fxdriver_evaluate __driver_unwrapped __webdriver_unwrapped __driver_evaluate __selenium_unwrapped __fxdriver_unwrapped".split(" "),
                        b = n(a, "external");
                    b = n(b, "toString") ? "" + b.toString() : "";
                    b = -1 !== ib(b, "Sequentum");
                    var d = n(a, "document.documentElement"),
                        e = ["selenium", "webdriver", "driver"];
                    return !!(Ya(u(a, n), ["_selenium", "callSelenium", "_Selenium_IDE_Recorder"]) || Ya(u(n(a, "document"), n), c) || b || d && Ya(H(d.getAttribute, d), e))
                }),
                ys = w(function(a) {
                    return !!(Ya(u(a, n), ["_phantom", "__nightmare", "callPhantom"]) || /(PhantomJS)|(HeadlessChrome)/.test(lb(a)) || n(a, "navigator.webdriver") || n(a, "isChrome") && !n(a, "chrome"))
                }),
                zs = w(function(a) {
                    return !(!n(a,
                        "ia_document.shareURL") || !n(a, "ia_document.referrer"))
                }),
                Wd = w(function(a) {
                    var c = lb(a) || "",
                        b = c.match(/Mac OS X ([0-9]+)_([0-9]+)/);
                    b = b ? [+b[1], +b[2]] : [0, 0];
                    c = c.match(/iPhone OS ([1-9]+)_([0-9]+)/);
                    return 14 <= (c ? +c[1] : 0) ? !0 : (Te(a) || 10 < b[0] || 10 === b[0] && 13 <= b[1]) && zd(a)
                }),
                Ar = /Edg\/(\d+)\./,
                Le = w(function(a) {
                    return Wd(a) || rf(a, 68) || sf(a, 79)
                }),
                As = $c.construct,
                hc = $c.host,
                Og = lg(window),
                Ea = {
                    sg: 24226447,
                    mg: 26302566,
                    wg: 51533966,
                    fj: 65446441,
                    Ra: "https:",
                    cc: "1240",
                    kc: As,
                    rg: Og ? 512 : 2048,
                    pg: Og ? 512 : 2048,
                    qg: Og ? 100 : 400,
                    gj: 100,
                    ug: "noindex"
                },
                Xd = [],
                M = w(function(a) {
                    return a.id + ":" + a.ca
                }),
                mc = {},
                fe = Aa("1"),
                Bs = setTimeout;
            La.prototype["catch"] = function(a) {
                return this.then(null, a)
            };
            La.prototype.then = function(a, c) {
                var b = new this.constructor(Rr);
                qk(this, new Tr(a, c, b));
                return b
            };
            La.prototype["finally"] = function(a) {
                var c = this.constructor;
                return this.then(function(b) {
                    return c.resolve(a()).then(function() {
                        return b
                    })
                }, function(b) {
                    return c.resolve(a()).then(function() {
                        return c.reject(b)
                    })
                })
            };
            La.all = function(a) {
                return new La(function(c,
                    b) {
                    function d(h, k) {
                        try {
                            if (k && ("object" === typeof k || "function" === typeof k)) {
                                var l = k.then;
                                if ("function" === typeof l) {
                                    l.call(k, function(m) {
                                        d(h, m)
                                    }, b);
                                    return
                                }
                            }
                            e[h] = k;
                            0 === --f && c(e)
                        } catch (m) {
                            b(m)
                        }
                    }
                    if (!a || "undefined" === typeof a.length) return b(new TypeError("Promise.all accepts an array"));
                    var e = Array.prototype.slice.call(a);
                    if (0 === e.length) return c([]);
                    for (var f = e.length, g = 0; g < e.length; g++) d(g, e[g])
                })
            };
            La.resolve = function(a) {
                return a && "object" === typeof a && a.constructor === La ? a : new La(function(c) {
                    c(a)
                })
            };
            La.reject = function(a) {
                return new La(function(c, b) {
                    b(a)
                })
            };
            La.race = function(a) {
                return new La(function(c, b) {
                    if (!a || "undefined" === typeof a.length) return b(new TypeError("Promise.race accepts an array"));
                    for (var d = 0, e = a.length; d < e; d++) La.resolve(a[d]).then(c, b)
                })
            };
            La.Je = "function" === typeof setImmediate && function(a) {
                setImmediate(a)
            } || function(a) {
                Bs(a, 0)
            };
            La.xg = function(a) {
                "undefined" !== typeof console && console && console.warn("Possible Unhandled Promise Rejection:", a)
            };
            var L = window.Promise,
                Cs = na(L, "Promise"),
                Zk = na(n(L, "resolve"), "resolve"),
                $k = na(n(L, "reject"), "reject"),
                al = na(n(L, "all"), "all");
            if (Cs && Zk && $k && al) {
                var Ze = function(a) {
                    return new Promise(a)
                };
                Ze.resolve = H(Zk, L);
                Ze.reject = H($k, L);
                Ze.all = H(al, L);
                L = Ze
            } else L = La;
            var ee = [],
                id = [],
                V = [],
                bb = [],
                Pg = [],
                Yb = [],
                Yj = pc([26812653]),
                mj = w(v(Q("id"), Yj), M),
                Zb = {
                    id: "id",
                    Fe: "ut",
                    ca: "type",
                    Rd: "ldc",
                    Ta: "nck",
                    xc: "url",
                    ih: "referrer"
                },
                Ds = /^\d+$/,
                ad = {
                    id: function(a) {
                        a = "" + (a || "0");
                        Ds.test(a) || (a = "0");
                        try {
                            var c = Ga(a)
                        } catch (b) {
                            c = 0
                        }
                        return c
                    },
                    ca: function(a) {
                        return "" + (a || 0 === a ?
                            a : "0")
                    },
                    Ta: Gb,
                    Fe: Gb
                };
            Zb.lc = "defer";
            ad.lc = Gb;
            Zb.R = "params";
            ad.R = function(a) {
                return pa(a) || ca(a) ? a : null
            };
            Zb.Ee = "userParams";
            Zb.eg = "triggerEvent";
            ad.eg = Gb;
            Zb.Qf = "sendTitle";
            ad.Qf = function(a) {
                return !!a || W(a)
            };
            Zb.ze = "trackHash";
            ad.ze = Gb;
            Zb.cg = "trackLinks";
            Zb.Tg = "enableAll";
            var ff = J(function(a, c) {
                    var b = c[0];
                    a[b] = {
                        ea: c[1],
                        Ua: ad[b]
                    };
                    return a
                }, {}, Ma(Zb)),
                yr = "hash host hostname href pathname port protocol search".split(" "),
                wg = "ru by kz az kg lv md tj tm uz ee fr lt com co.il com.ge com.am com.tr com.ru".split(" "),
                ek = /(?:^|\.)(?:(ya\.ru)|(?:yandex)\.(\w+|com?\.\w+))$/,
                Fe = w(function(a) {
                    return (a ? a.replace(/^www\./, "") : "").toLowerCase()
                }),
                ui = w(function(a) {
                    a = R(a).hostname;
                    var c = !1;
                    a && (c = -1 !== a.search(ek));
                    return c
                }),
                bl = v(R, Q("protocol"), Aa("https:")),
                vr = w(function(a) {
                    return ss(a) && bl(a) ? "SameSite=None;Secure;" : ""
                }),
                sj = /^\s+|\s+$/g,
                dk = na(String.prototype.trim, "trim"),
                cl = sa(function(a, c) {
                    return c.replace(a, "")
                }),
                Mi = cl(/\s/g),
                Tb = cl(/\D/g),
                Rd = ["metrika_enabled"],
                vg = [],
                bk = gb("gsc", Zj),
                wr = /:\d+$/,
                Ur = w(function(a) {
                    var c =
                        (R(a).host || "").split(".");
                    return 1 === c.length ? c[0] : J(function(b, d, e) {
                        e += 1;
                        2 <= e && !b && (e = I(".", c.slice(-e)), di(a, e) && (b = e));
                        return b
                    }, "", c)
                }),
                wc = w(Lc),
                Re = w(function(a) {
                    var c = wc(a),
                        b = "1" === c.C("debug"),
                        d = Se(a, "1") || Se(a, "2"),
                        e = a._ym_debug;
                    !e && !d || b || (a = R(a), c.D("debug", "1", void 0, a.host));
                    return !!(b || e || d)
                }),
                ur = gb("debuggerEvents", Dd, !0),
                rr = ["http.0.st..rt.", "network error occurred", "send beacon", "Content Security Policy", "DOM Exception 18"],
                Yd, Ic = function(a) {
                    return function(c, b) {
                        void 0 === b && (b = !1);
                        if (Yd) var d = new Yd(c);
                        else Ia("Error", a.Error) ? (Yd = a.Error, d = new a.Error(c)) : (Yd = tr, d = new Yd(c));
                        b && (d.unk = !0);
                        return d
                    }
                }(window),
                sr = fb(/^http./),
                qr = fb(/^err.kn/),
                Xj = [],
                pr = w(function(a) {
                    a = !(!a.addEventListener || !a.removeEventListener);
                    return {
                        Ki: a,
                        F: a ? "addEventListener" : "attachEvent",
                        ga: a ? "removeEventListener" : "detachEvent"
                    }
                }),
                Es = w(function(a) {
                    var c = !1;
                    if (!a.addEventListener) return c;
                    try {
                        var b = Object.defineProperty({}, "passive", {
                            get: function() {
                                c = !0;
                                return 1
                            }
                        });
                        a.addEventListener("test", E, b)
                    } catch (d) {}
                    return c
                }),
                Fs = sa(function(a, c) {
                    return a ? z({
                        capture: !0,
                        passive: !0
                    }, c || {}) : !!c
                }),
                da = w(function(a) {
                    var c = Es(a),
                        b = Fs(c),
                        d = {};
                    return z(d, {
                        F: function(e, f, g, h) {
                            y(function(k) {
                                var l = b(h);
                                Wj(a, e, k, g, l, !1)
                            }, f);
                            return H(d.Zb, d, e, f, g, h)
                        },
                        Zb: function(e, f, g, h) {
                            y(function(k) {
                                var l = b(h);
                                Wj(a, e, k, g, l, !0)
                            }, f)
                        }
                    })
                }),
                ia = w(dg),
                Sj = sa(function(a, c) {
                    for (var b = []; !Qd(c);) {
                        var d = kr(c);
                        a(d, function(e) {
                            return e(c)
                        });
                        b.push(d)
                    }
                    return b
                }),
                dl = sa(function(a, c) {
                    return Fa(function(b, d) {
                        return c(b, function(e) {
                            try {
                                d(a(e))
                            } catch (f) {
                                b(f)
                            }
                        })
                    })
                }),
                Qg =
                sa(function(a, c) {
                    return Fa(function(b, d) {
                        return c(b, function(e) {
                            try {
                                a(e)(Qa(b, d))
                            } catch (f) {
                                b(f)
                            }
                        })
                    })
                }),
                pg = [],
                qg = !1,
                og = !1,
                el = sa(function(a, c) {
                    var b = c || {};
                    return {
                        l: u(b, P),
                        C: function(d, e) {
                            var f = b[d];
                            return W(f) && !W(e) ? e : f
                        },
                        D: function(d, e) {
                            b[d] = e;
                            return this
                        },
                        Wb: function(d, e) {
                            return "" === e || la(e) ? this : this.D(d, e)
                        },
                        Ha: u(b, a)
                    }
                }),
                Ka = el(function(a) {
                    var c = "";
                    a = J(function(b, d) {
                        var e = d[0],
                            f = "" + e + ":" + d[1];
                        "t" === e ? c = f : b.push(f);
                        return b
                    }, [], Ma(a));
                    c && a.push(c);
                    return I(":", a)
                }),
                Rg, Jj = (Rg = {}, Rg.w = [
                    [function(a, c) {
                        return {
                            N: function(b,
                                d) {
                                var e, f = b.J;
                                f = (e = {}, e["page-url"] = f && f["page-url"] || "", e.charset = "utf-8", e);
                                "0" !== c.ca && (f["cnt-class"] = c.ca);
                                b.K || (b.K = Ka());
                                e = b.K;
                                var g = b.ba;
                                f = {
                                    na: {
                                        Ba: "watch/" + c.id
                                    },
                                    ba: z(void 0 === g ? {} : g, {
                                        zb: !!e.C("pv") && !e.C("ar") && !e.C("wh")
                                    }),
                                    J: z(b.J || {}, f)
                                };
                                z(b, f);
                                d()
                            }
                        }
                    }, 1]
                ], Rg),
                Sg = u(Jj, Nj),
                nb = Pd("w"),
                Ij = ["webkitvisibilitychange", "visibilitychange"],
                nf = el(function(a) {
                    a = Ma(a);
                    return I("", B(function(c) {
                        var b = c[0];
                        c = c[1];
                        return Va(c) ? "" : b + "(" + c + ")"
                    }, a))
                }),
                fl = "A B BIG BODY BUTTON DD DIV DL DT EM FIELDSET FORM H1 H2 H3 H4 H5 H6 HR I IMG INPUT LI OL P PRE SELECT SMALL SPAN STRONG SUB SUP TABLE TBODY TD TEXTAREA TFOOT TH THEAD TR U UL ABBR AREA BLOCKQUOTE CAPTION CENTER CITE CODE CANVAS DFN EMBED FONT INS KBD LEGEND LABEL MAP OBJECT Q S SAMP STRIKE TT ARTICLE AUDIO ASIDE FOOTER HEADER MENU METER NAV PROGRESS SECTION TIME VIDEO NOINDEX NOBR MAIN svg circle clippath ellipse defs foreignobject g glyph glyphref image line lineargradient marker mask path pattern polygon polyline radialgradient rect set text textpath title".split(" "),
                qq = /^\s*(data|javascript):/i,
                cj = new RegExp(I("", ["\\.(" + I("|", "3gp 7z aac ac3 acs ai avi ape apk asf bmp bz2 cab cdr crc32 css csv cue divx dmg djvu? doc(x|m|b)? emf eps exe flac? flv iso swf gif t?gz jpe?g? js m3u8? m4a mp(3|4|e?g?) m4v md5 mkv mov msi ods og(g|m|v) psd rar rss rtf sea sfv sit sha1 svg tar tif?f torrent ts txt vob wave? wma wmv wmf webm ppt(x|m|b)? xls(x|m|b)? pdf phps png xpi g?zip".split(" ")) + ")$"]), "i"),
                Sa, rk = (Sa = {}, Sa.hit = "h", Sa.params = "p", Sa.reachGoal = "g", Sa.userParams = "up",
                    Sa.trackHash = "th", Sa.accurateTrackBounce = "atb", Sa.notBounce = "nb", Sa.addFileExtension = "fe", Sa.extLink = "el", Sa.file = "fc", Sa.trackLinks = "tl", Sa.destruct = "d", Sa.setUserID = "ui", Sa.getClientID = "ci", Sa.clickmap = "cm", Sa.enableAll = "ea", Sa),
                Gs = w(function() {
                    var a = 0;
                    return function() {
                        return a += 1
                    }
                }),
                Hs = v(M, Gs, ja),
                gg = {
                    mc: function(a) {
                        a = Td(a).C("mt", {});
                        a = Ma(a);
                        return a.length ? J(function(c, b, d) {
                            return "" + c + (d ? "-" : "") + b[0] + "-" + b[1]
                        }, "", a) : null
                    },
                    clc: function(a) {
                        var c = G(a).C("cls", {
                                jc: 0,
                                x: 0,
                                y: 0
                            }),
                            b = c.jc,
                            d = c.x;
                        c = c.y;
                        return b ? b + "-" + a.Math.floor(d / b) + "-" + a.Math.floor(c / b) : b + "-" + d + "-" + c
                    },
                    rqnt: function(a, c, b) {
                        a = b.J;
                        return !a || a.nohit ? null : Hs(c)
                    }
                },
                dr = w(function(a) {
                    Gj(a, "_ymBRC", "1");
                    var c = "1" !== Fj(a, "_ymBRC");
                    c || Hj(a, "_ymBRC");
                    return c
                }),
                Pa = w(Ej),
                bd = w(Ej, function(a, c, b) {
                    return "" + c + b
                }),
                Is = w(Q("document.documentElement")),
                Js = w(function(a) {
                    a = n(a, "document") || {};
                    return ("" + (a.characterSet || a.charset || "")).toLowerCase()
                }),
                eb = w(v(Q("document"), u("createElement", kc))),
                ci = w(function(a) {
                    var c = n(a, "Element.prototype");
                    return c ?
                        (a = qb(function(b) {
                            var d = c[b];
                            return !!d && Ia(b, d)
                        }, ["matches", "webkitMatchesSelector", "mozMatchesSelector", "msMatchesSelector", "oMatchesSelector"])) ? c[a] : null : null
                }),
                Ks = Aa("INPUT"),
                Oe = v(Na, Ks),
                Ls = Aa("TEXTAREA"),
                ar = v(Na, Ls),
                Ms = Aa("SELECT"),
                br = v(Na, Ms),
                Pe = v(Q("type"), fb(/^(checkbox|radio)$/)),
                If = v(Na, fb(/^INPUT|SELECT|TEXTAREA$/)),
                se = v(Na, fb(/^INPUT|SELECT|TEXTAREA|BUTTON$/)),
                Mf = "INPUT CHECKBOX RADIO TEXTAREA SELECT PROGRESS".split(" "),
                $q = ["submit", "image", "hidden"],
                Ae = w(function() {
                    for (var a = 59, c = {},
                            b = 0; b < fl.length; b += 1) c[fl[b]] = String.fromCharCode(a), a += 1;
                    return c
                }),
                Aj = w(function(a) {
                    return {
                        rj: a,
                        ib: null,
                        rb: []
                    }
                }),
                yj = {},
                jg = {};
            yj.p = 500;
            var xj = {
                i: "id",
                n: "name",
                h: "href",
                ty: "type"
            };
            jg.h = !0;
            jg.c = !0;
            var Yc = {};
            Yc.p = mf;
            Yc.c = function(a, c, b) {
                (a = db(n(c, "textContent"))) && b && (b = b(c), b.length && Ya(v(Q("textContent"), db, Aa(a)), b) && (a = ""));
                Oe(c) && (a = db(c.getAttribute && c.getAttribute("value") || a));
                return a
            };
            var cd, ig = "button," + I(",", B(function(a) {
                    return 'input[type="' + a + '"]'
                }, ["button", "submit", "reset", "file"])) +
                ",a",
                Uf = u(ig, sb),
                Yq = (cd = {}, cd.A = "h", cd.BUTTON = "i", cd.DIV = "i", cd.INPUT = "ty", cd),
                gl = /\/$/,
                wj = gb("r", function(a, c) {
                    var b = vj(a, c),
                        d = b[0];
                    return !b[1] && d
                }),
                Md = w(function() {
                    return {
                        Ga: {},
                        pending: {},
                        children: {}
                    }
                }),
                Tg = Q("postMessage"),
                Ns = A("s.f", function(a, c, b, d, e) {
                    c = c(d);
                    var f = Md(a),
                        g = I(":", [c.meta.qc, c.meta.key]);
                    if (Tg(b)) {
                        f.pending[g] = e;
                        try {
                            b.postMessage(c.Yf, "*")
                        } catch (h) {
                            delete f.pending[g];
                            return
                        }
                        O(a, function() {
                            delete f.pending[g]
                        }, 5E3, "if.s")
                    }
                }),
                Os = A("s.fh", function(a, c, b, d, e, f) {
                    var g = null,
                        h = null,
                        k =
                        Md(a),
                        l = null;
                    try {
                        g = xb(a, f.data), h = g.__yminfo, l = g.data
                    } catch (m) {
                        return
                    }
                    if (!la(h) && h.substring && "__yminfo" === h.substring(0, 8) && !la(l) && (g = h.split(":"), 4 === g.length))
                        if (h = c.id, c = g[1], a = g[2], g = g[3], !ca(l) && l.type && "0" === g && l.counterId) {
                            if (!l.toCounter || l.toCounter == h) {
                                k = null;
                                try {
                                    k = f.source
                                } catch (m) {}!Va(k) && Tg(k) && (f = d.T(l.type, [f, l]), e = B(v(P, Xh(e)), f.concat([{}])), l = b([c, a, l.counterId], e), k.postMessage(l.Yf, "*"))
                            }
                        } else g === "" + h && ca(l) && fa(function(m) {
                                return !(!m.hid || !m.counterId)
                            }, l).length === l.length &&
                            (b = k.pending[I(":", [c, a])]) && b.apply(null, [f].concat(l))
                }),
                md = w(function(a, c) {
                    var b, d = kc("getElementsByTagName", n(a, "document")),
                        e = Md(a),
                        f = Tg(a),
                        g = pd(a),
                        h = da(a);
                    if (!d || !f) return null;
                    d = d.call(a.document, "iframe");
                    f = (b = {}, b.counterId = c.id, b.hid = "" + zc(a), b);
                    Le(a) && (f.duid = Nd(a, c));
                    Uq(a, g);
                    Vq(a);
                    b = Wq(a, f);
                    var k = C([a, u([], b)], Ns);
                    y(function(l) {
                        var m = null;
                        try {
                            m = l.contentWindow
                        } catch (p) {}
                        m && k(m, {
                            type: "initToChild"
                        }, function(p, r) {
                            g.T("initToParent", [p, r])
                        })
                    }, d);
                    jb(a) && k(a.parent, {
                        type: "initToParent"
                    }, function(l,
                        m) {
                        g.T("parentConnect", [l, m])
                    });
                    h.F(a, ["message"], C([a, c, b, g, f], Os));
                    return {
                        $: g,
                        Ga: e.Ga,
                        children: e.children,
                        ne: k
                    }
                }, v(Za, M)),
                nd = w(function(a, c) {
                    if (!Le(a) || !jb(a)) return Nd(a, c);
                    var b = md(a, c);
                    return b && b.Ga[c.id] ? b.Ga[c.id].info.duid || Nd(a, c) : Nd(a, c)
                }, function(a, c) {
                    return "{" + c.Rd + c.Ta
                }),
                Ps = w(v(ia, Fa(function(a) {
                    return -(new a.l.Date).getTimezoneOffset()
                }))),
                Qs = v(ia, Fa(function(a) {
                    a = new a.l.Date;
                    return I("", B(lr, [a.getFullYear(), a.getMonth() + 1, a.getDate(), a.getHours(), a.getMinutes(), a.getSeconds()]))
                })),
                Rs = v(ia, Fa(hg)),
                yi = w(v(ia, Fa(function(a) {
                    return a.Aa[0]
                }))),
                Ss = w(function(a) {
                    a = G(a);
                    var c = a.C("counterNum", 0) + 1;
                    a.D("counterNum", c);
                    return c
                }, v(Za, M)),
                oa, Ld = (oa = {}, oa.vf = u($c.version, P), oa.nt = us, oa.fu = function(a, c, b) {
                        var d = b.J;
                        if (!d) return null;
                        c = (n(a, "document.referrer") || "").replace(gl, "");
                        b = (d["page-ref"] || "").replace(gl, "");
                        d = d["page-url"];
                        a = R(a).href !== d;
                        c = c !== b;
                        b = 0;
                        a && c ? b = 3 : c ? b = 1 : a && (b = 2);
                        return b
                    }, oa.en = Js, oa.la = Yk, oa.ut = function(a, c, b) {
                        var d = b.M;
                        b = b.J;
                        d = d && d.Ic;
                        b && (ui(a) || c.Fe || d) && (b.ut =
                            Ea.ug);
                        return null
                    }, oa.v = u(Ea.cc, P), oa.cn = Ss, oa.dp = function(a) {
                        var c = G(a),
                            b = c.C("bt", {});
                        if (W(c.C("bt"))) {
                            var d = n(a, "navigator.getBattery");
                            try {
                                b.p = d && d.call(a.navigator)
                            } catch (e) {}
                            c.D("bt", b);
                            b.p && b.p.then && b.p.then(D(a, "bi:dp.p", function(e) {
                                b.Zi = n(e, "charging") && 0 === n(e, "chargingTime")
                            }))
                        }
                        return zb(b.Zi)
                    }, oa.ls = w(function(a, c) {
                        var b = bd(a, c.id),
                            d = ia(a),
                            e = b.C("lsid");
                        return +e ? e : (d = Wa(a, 0, d(Y)), b.D("lsid", d), d)
                    }, Za), oa.hid = zc, oa.phid = function(a, c) {
                        if (!jb(a)) return null;
                        var b = md(a, c);
                        if (!b) return null;
                        var d = ea(b.Ga);
                        return d.length ? b.Ga[d[0]].info.hid : null
                    }, oa.z = Ps, oa.i = Qs, oa.et = Rs, oa.c = v(Q("navigator.cookieEnabled"), Lb), oa.rn = v(P, Wa), oa.rqn = function(a, c, b) {
                        b = b.J;
                        if (!b || b.nohit) return null;
                        c = M(c);
                        a = bd(a, c);
                        c = (a.C("reqNum", 0) || 0) + 1;
                        a.D("reqNum", c);
                        if (a.C("reqNum") === c) return c;
                        a.Fb("reqNum");
                        return null
                    }, oa.u = nd, oa.w = function(a) {
                        a = Kc(a);
                        return a[0] + "x" + a[1]
                    }, oa.s = function(a) {
                        var c = n(a, "screen");
                        if (c) {
                            a = n(c, "width");
                            var b = n(c, "height");
                            c = n(c, "colorDepth") || n(c, "pixelDepth");
                            return I("x", [a, b, c])
                        }
                        return null
                    },
                    oa.sk = Q("devicePixelRatio"), oa.ifr = v(jb, Lb), oa.j = v(ws, Lb), oa.sti = function(a) {
                        return jb(a) && vs(a) ? "1" : null
                    }, oa),
                Tq = w(function() {
                    return ra(ea(Ld), ea(gg))
                }),
                Sq = w(Gc, M),
                tj = w(function() {
                    return {
                        Ve: null,
                        ta: []
                    }
                }, M),
                Pq = /^[a-z][\w.+-]+:/i,
                Ug, Wb = [
                    [Qe, 1],
                    [Ke, 2],
                    [Pb(), 3],
                    [uj, 4]
                ],
                Je = [],
                ub = u(Wb, Oj),
                Vb = (Ug = {}, Ug.h = Wb, Ug),
                Z = u(Vb, Nj);
            ub(function(a) {
                return {
                    N: function(c, b) {
                        var d = c.J;
                        if (!c.K || !d) return b();
                        var e = d["page-ref"],
                            f = d["page-url"];
                        e && f !== e ? d["page-ref"] = rj(a, e) : delete d["page-ref"];
                        d["page-url"] = rj(a, f).slice(0,
                            Ea.rg);
                        return b()
                    }
                }
            }, -100);
            var Lq = /[^a-z0-9.:-]/,
                Vg, Wg = {},
                hl = ua([eg && [eg, 0], Db && [Db, 1],
                    [Eb, 2], Jd && [Jd, 3],
                    [Wc, 4]
                ]),
                oc = ua([eg, Db, Eb, Jd, Wc]),
                Xg = [Eb];
            Xg.unshift(Db);
            Xg.push(Jd);
            var il = ua(Xg),
                dd = ua([Wc]);
            ua([Db, Eb]);
            var Ts = ua([Db, Wc]),
                jl = ua([Db, Eb, Jd, Wc]),
                ya = (Vg = {}, Vg.h = il, Vg),
                Yg = w(function(a, c) {
                    var b = Wg["*"] ? Wg["*"] : c && Wg[c];
                    b || (b = c ? ya[c] || [] : oc);
                    b = J(function(d, e) {
                        var f = e(a);
                        if (f) {
                            var g = qb(v(Uc, Aa(e)), hl);
                            g && d.push([g[1], f])
                        }
                        return d
                    }, [], b);
                    b.length || de();
                    return b
                }, Za),
                Zg, Us = H(L.reject, L, Ra()),
                Ca = (Zg = {}, Zg.h = nb, Zg),
                va = A("g.sen", function(a, c, b) {
                    var d = Yg(a, c);
                    b = b ? Oq(a, c, b) : [];
                    var e = Ca[c],
                        f = e ? e(a, d, b) : nb(a, d, b);
                    return function() {
                        var g = Ja(arguments),
                            h = g[0];
                        g = g.slice(1);
                        var k = h.ba;
                        h = z(h, {
                            ba: z(void 0 === k ? {} : k, {
                                ha: [c]
                            })
                        });
                        return f.apply(null, [h].concat(g))
                    }
                }, Us),
                Dq = sa(function(a, c) {
                    if (!c[a]) {
                        var b, d = new L(function(e) {
                            b = e
                        });
                        c[a] = {
                            Ef: b,
                            promise: d,
                            Ff: !1
                        }
                    }
                    return c[a].promise
                }),
                nj = w(v(Gc, Fa)),
                Zd = w(function(a, c) {
                    var b = n(a, "console"),
                        d = n(b, "log");
                    d = Ve("log", d) ? H(d, b) : E;
                    var e = n(b, "warn");
                    e = Ve("warn", e) ? H(e, b) :
                        d;
                    var f = n(b, "error");
                    b = Ve("error", f) ? H(f, b) : d;
                    return {
                        log: Vc(a, "log", c, d),
                        error: Vc(a, "error", c, b),
                        warn: Vc(a, "warn", c, e)
                    }
                }, Za),
                Vs = A("dc.init", function(a, c) {
                    function b(e) {
                        for (var f = [], g = 1; g < arguments.length; g++) f[g - 1] = arguments[g];
                        G(a).C("dce:" + c, !1) && d[e].apply(d, f);
                        G(a).C("dclq:" + c).push([e, f])
                    }
                    var d = Zd(a, c);
                    G(a).Ia("dclq:" + c, []);
                    return Re(a) ? {
                        log: u("log", b),
                        warn: u("warn", b),
                        error: u("error", b)
                    } : Cq(a, c)
                }),
                Hd = w(Vs, Za),
                Ws = A("p.dc", function(a, c) {
                    var b = M(c);
                    lj(a, "");
                    lj(a, b)
                }),
                cm = A("h.p", function(a, c) {
                    var b,
                        d, e = va(a, "h", c),
                        f = c.xc || "" + R(a).href,
                        g = c.ih || a.document.referrer,
                        h = {
                            K: Ka((b = {}, b.pv = 1, b)),
                            J: (d = {}, d["page-url"] = f, d["page-ref"] = g, d),
                            M: {}
                        };
                    h.M.R = c.R;
                    h.M.Ee = c.Ee;
                    c.lc && h.J && (h.J.nohit = "1");
                    return e(h, c).then(function(k) {
                        k && (c.lc || Nb(a, c, "PageView. Counter " + c.id + ". URL: " + f + ". Referrer: " + g, c.R)(), Sb(a, C([a, c, k], Eq)))
                    })["catch"](D(a, "h.g.s"))
                }),
                $g = ["yandex_metrika_callback" + $c.callbackPostfix, "yandex_metrika_callbacks" + $c.callbackPostfix],
                Xs = A("cb.i", function(a) {
                    var c = $g[0],
                        b = $g[1];
                    if (T(a[c])) a[c]();
                    "object" === typeof a[b] && y(function(d, e) {
                        a[b][e] = null;
                        Zf(a, d)
                    }, a[b]);
                    y(function(d) {
                        try {
                            delete a[d]
                        } catch (e) {
                            a[d] = void 0
                        }
                    }, $g)
                }),
                kl = w(function(a) {
                    return !!n(a, "crypto.subtle.digest") && !!n(a, "TextEncoder") && !!n(a, "FileReader") && !!n(a, "Blob")
                }),
                Ys = A("fpm", function(a, c) {
                    if (!bl(a)) return E;
                    var b = M(c);
                    if (!kl(a)) return wb(a, b, "Not supported"), E;
                    var d = za(a, c);
                    return d ? function(e) {
                        return (new L(function(f, g) {
                            return pa(e) ? ea(e).length ? f(ij(a, e).then(function(h) {
                                var k, l;
                                h && h.length && d.params((k = {}, k.__ym = (l = {},
                                    l.fpp = h, l), k))
                            }, E)) : g(Ra("fpm.l")) : g(Ra("fpm.o"))
                        }))["catch"](D(a, "fpm.en"))
                    } : E
                }),
                $e = sa(function(a, c) {
                    var b = {};
                    bg(a)(function(d) {
                        b = d[c] || {}
                    });
                    return b
                }),
                Zs = A("c.c.cc", function(a) {
                    var c = G(a),
                        b = v($e(a), function(d) {
                            var e, f = (e = {}, e.clickmap = !!d.clickmap, e);
                            return z({}, d, f)
                        });
                    return D(a, "g.c.cc", v(H(c.C, c, "counters", {}), ea, Mb(b)))
                }),
                $s = A("gt.c.rs", function(a, c) {
                    var b, d = M(c),
                        e = c.id,
                        f = c.ca,
                        g = c.Jg,
                        h = c.ze,
                        k = C([a, d], yq);
                    ag(a, d, (b = {}, b.id = e, b.type = +f, b.clickmap = g, b.trackHash = !!h, b));
                    return k
                }),
                gj = w(Dd),
                Gd = w(Gc,
                    M),
                at = A("pa.int", function(a, c) {
                    var b;
                    return b = {}, b.params = function() {
                        var d, e, f = Ja(arguments),
                            g = xq(f);
                        if (!g) return null;
                        f = g.Og;
                        var h = g.R;
                        g = g.dc;
                        if (!pa(h) && !ca(h)) return null;
                        var k = va(a, "1", c),
                            l = Gd(c).url,
                            m = !mj(c),
                            p = "arams. Counter " + c.id,
                            r = "P" + p,
                            q = h,
                            t = "";
                        (t = n(h, "__ym.user_id")) && (r = "Set user id " + t);
                        K("__ymu", ea(h)) && (r = "User p" + p);
                        q.__ym && (q = z({}, h), q.__ym = J(function(x, F) {
                            var U = n(h, "__ym." + F);
                            U && (x[F] = U);
                            return x
                        }, {}, Xd), ea(q.__ym).length || delete q.__ym, m = !!ea(q).length);
                        q = t ? void 0 : JSON.stringify(q);
                        p = Nb(a, c, r, q);
                        k = k({
                            M: {
                                R: h
                            },
                            K: Ka((d = {}, d.pa = 1, d.ar = 1, d)),
                            J: (e = {}, e["page-url"] = l || R(a).href, e)
                        }, c).then(m ? p : E);
                        return Tc(a, "p.s", k, g, f)
                    }, b
                }),
                oe = w(ej, v(Za, M)),
                bt = A("y.p", function(a, c) {
                    var b = ej(a, c);
                    if (b) {
                        var d = ke(a),
                            e = C([a, b, c], tq);
                        xh(a, d, function(f) {
                            f.F(["params"], e)
                        });
                        b.$.F(["params"], v(Q("1"), e))
                    }
                }),
                Vr = w(function(a) {
                    if (a = eb(a)) return a("a")
                }),
                ll = {
                    vj: fb(/[/&=?#]/)
                },
                Ce = A("go.in", function(a, c, b, d) {
                    var e;
                    void 0 === b && (b = "goal");
                    return e = {}, e.reachGoal = function(f, g, h, k) {
                        var l, m;
                        if (!f || ll[b] && ll[b](f)) return null;
                        var p = g,
                            r = h || E;
                        T(g) && (r = g, p = void 0, k = h);
                        var q = Nb(a, c, "Reach goal. Counter: " + c.id + ". Goal id: " + f, p),
                            t = "goal" === b;
                        g = va(a, "g", c);
                        var x = sq(a, c, f, b);
                        h = x[0];
                        x = x[1];
                        p = g({
                            M: {
                                R: p
                            },
                            K: Ka((l = {}, l.ar = 1, l)),
                            J: (m = {}, m["page-url"] = h, m["page-ref"] = x, m)
                        }, c).then(function() {
                            var F, U;
                            t && q();
                            rb(a, (F = {}, F.counterKey = M(c), F.name = "event", F.data = (U = {}, U.schema = b, U.name = f, U), F));
                            d && d()
                        });
                        return Tc(a, "g.s", p, r, k)
                    }, e
                }),
                ct = A("guid.int", function(a, c) {
                    var b;
                    return b = {}, b.getClientID = function(d) {
                        var e = Nd(a, c);
                        d && Zf(a, d, null, e);
                        return e
                    }, b
                }),
                tk, dt = A("th.e", function(a, c) {
                    function b() {
                        g || (k = Sc(a, "onhashchange") ? da(a).F(a, ["hashchange"], h) : Wr(a, h))
                    }
                    var d, e = va(a, "t", c),
                        f = Ie(a, M(c)),
                        g = !1,
                        h = D(a, "h.h.ch", H(Xr, null, a, c, e)),
                        k = E;
                    c.ze && (b(), g = !0);
                    e = D(a, "tr.hs.h", function(l) {
                        var m;
                        l ? b() : k();
                        g = !!l;
                        f((m = {}, m.trackHash = g, m))
                    });
                    return d = {}, d.trackHash = e, d.u = k, d
                }),
                et = sa(function(a, c) {
                    ka(c) ? a.push(c) : y(v(P, Da("push", a)), c)
                }),
                Fd = gb("retryReqs", function(a) {
                    var c = Pa(a),
                        b = c.C("retryReqs", {}),
                        d = ia(a)(Y);
                    y(function(e) {
                        var f = e[0];
                        e = e[1];
                        (!e || !e.time ||
                            e.time + 864E5 < d) && delete b[f]
                    }, Ma(b));
                    c.D("retryReqs", b);
                    return b
                }, !0),
                ml = v(Ac, Aa(0)),
                nl = Fb(ml),
                ft = [nl("watch"), nl("clmap")],
                gt = A("g.r", function(a) {
                    var c = ia(a),
                        b = Fd(a),
                        d = c(Y),
                        e = zc(a);
                    return J(function(f, g) {
                        var h = g[0],
                            k = g[1];
                        k && Ya(Fa(k.resource), ft) && !k.d && k.ghid && k.ghid !== e && k.time && 500 < d - k.time && k.time + 864E5 > d && 2 >= k.browserInfo.rqnl && (k.d = 1, h = {
                                protocol: k.protocol,
                                host: k.host,
                                Ba: k.resource,
                                wi: k.postParams,
                                R: k.params,
                                Bg: k.browserInfo,
                                tj: k.ghid,
                                time: k.time,
                                Tb: Ga(h),
                                Mg: k.counterId,
                                ca: k.counterType
                            }, k.telemetry &&
                            (h.Ja = k.telemetry), f.push(h));
                        return f
                    }, [], Ma(b))
                }),
                ht = A("nb.p", function(a, c) {
                    function b(F) {
                        l() || (F = "number" === typeof F ? F : 15E3, x = Yr(a, d(!1), F), m())
                    }

                    function d(F) {
                        return function(U) {
                            var N, ma, wa;
                            void 0 === U && (U = (N = {}, N.ctx = {}, N.callback = E, N));
                            if (F || !q && !k.Kd) {
                                q = !0;
                                m();
                                x && x();
                                var Bb = p(Y);
                                N = (Ga(k.C("lastHit")) || 0) < Bb - 18E5;
                                var Cd = .1 > Math.random();
                                k.D("lastHit", Bb);
                                Bb = Ka((ma = {}, ma.nb = 1, ma.cl = t, ma.ar = 1, ma));
                                ma = Gd(c);
                                ma = {
                                    J: (wa = {}, wa["page-url"] = ma.url || R(a).href, wa),
                                    K: Bb,
                                    M: {
                                        force: F
                                    }
                                };
                                wa = Zd(a, M(c)).warn;
                                !U.callback &&
                                    U.ctx && wa('"callback" argument missing');
                                (wa = F || N || Cd) || (wa = a.location.href, N = a.document.referrer, wa = !(wa && N ? dj(wa) === dj(N) : !wa && !N));
                                if (wa) return wa = g(ma, c), Tc(a, "l.o.l", wa, U.callback, U.ctx)
                            }
                            return null
                        }
                    }
                    var e, f, g = va(a, "n", c),
                        h = M(c),
                        k = bd(a, c.id),
                        l = u(u(h, $e(a)), v(ja, Q("accurateTrackBounce"))),
                        m = u((e = {}, e.accurateTrackBounce = !0, e), Ie(a, h)),
                        p = ia(a),
                        r = p(Y),
                        q = !1,
                        t = 0,
                        x;
                    qa(c, function(F) {
                        t = F.bh - r
                    });
                    c.Ke && b(c.Ke);
                    e = (f = {}, f.notBounce = d(!0), f.u = x, f);
                    e.accurateTrackBounce = b;
                    return e
                }),
                lq = sa(gc)("(ym-disable-clickmap|ym-clickmap-ignore)"),
                it = A("clm.p", function(a, c) {
                    if (ld(a)) return E;
                    var b = va(a, "m", c),
                        d = M(c),
                        e = ia(a),
                        f = e(Y),
                        g = u(u(d, $e(a)), v(ja, Q("clickmap"))),
                        h, k = null;
                    d = D(a, "clm.p.c", function(l) {
                        var m = g();
                        if (m) {
                            var p = G(a),
                                r = p.C("cls", {
                                    jc: 0,
                                    x: 0,
                                    y: 0
                                });
                            p.D("cls", {
                                jc: r.jc + 1,
                                x: r.x + l.clientX,
                                y: r.y + l.clientY
                            });
                            p = "object" === typeof m ? m : {};
                            r = p.filter;
                            m = p.isTrackHash || !1;
                            var q = B(function(x) {
                                return ("" + x).toUpperCase()
                            }, p.ignoreTags || []);
                            W(h) && (h = p.quota || null);
                            var t = !!p.quota;
                            l = {
                                element: mq(a, l),
                                position: $i(a, l),
                                button: nq(l),
                                time: e(Y)
                            };
                            p = R(a).href;
                            if (kq(a, l, k, q, r)) {
                                if (t) {
                                    if (!h) return;
                                    --h
                                }
                                q = Ne(a, l.element);
                                r = q[0];
                                q = q[1];
                                t = kg(a, l.element);
                                r = ["rn", Wa(a), "x", Math.floor(65535 * (l.position.x - t.left) / (r || 1)), "y", Math.floor(65535 * (l.position.y - t.top) / (q || 1)), "t", Math.floor((l.time - f) / 100), "p", mf(a, l.element), "X", l.position.x, "Y", l.position.y];
                                r = I(":", r);
                                m && (r += ":wh:1");
                                jq(a, p, r, b, c);
                                k = l
                            }
                        }
                    });
                    return da(a).F(n(a, "document"), ["click"], d)
                }),
                jt = A("trigger.in", function(a, c) {
                    c.eg && Sb(a, C([a, "yacounter" + c.id + "inited"], cr), "t.i")
                }),
                kt = A("c.m.p", function(a, c) {
                    var b,
                        d = M(c);
                    return b = {}, b.clickmap = u(Ie(a, d), iq), b
                }),
                Bi = u("form", jc),
                Rp = u("form", sb),
                hq = w(v(Za, Fb(qa)(Q("settings.form_goals"))), Za),
                lt = A("s.f.i", function(a, c) {
                    var b = [],
                        d = [],
                        e = da(a);
                    b.push(e.F(a, ["click"], D(a, "s.f.c", C([a, c, d], gq))));
                    b.push(e.F(a, ["submit"], D(a, "s.f.e", function(f) {
                        var g = n(f, "target");
                        f = n(f, "isTrusted");
                        Xi(!0, a, c, d, g, f)
                    })));
                    Yi(a, c, "Form goal. Counter " + c.id + ". Init.");
                    return C([Be, b], y)
                }),
                mt = A("s.f.i", function(a, c) {
                    return qa(c, function(b) {
                        if (n(b, "settings.button_goals")) return b = da(a).F(a, ["click"], D(a, "c.t.c", v(C([a, c], ef(a, c, "", fq))))), Nb(a, c, "Button goal. Counter " + c.id + ". Init.")(), b
                    })
                }),
                $b, $d, ah, ed, Hb, Wf = ($b = {}, $b.transaction_id = "id", $b.item_brand = "brand", $b.index = "position", $b.item_variant = "variant", $b.value = "revenue", $b.item_category = "category", $b.item_list_name = "list", $b),
                ic = ($d = {}, $d.item_id = "id", $d.item_name = "name", $d.promotion_name = "coupon", $d),
                eq = (ah = {}, ah.promotion_name = "name", ah),
                ol = (ed = {}, ed.promotion_name = "name", ed.promotion_id = "id", ed.item_id = "product_id", ed.item_name =
                    "product_name", ed),
                bq = "currencyCode add delete remove purchase checkout detail impressions click promoView promoClick".split(" "),
                cq = (Hb = {}, Hb.view_item = {
                        event: "detail",
                        xa: ic,
                        La: "products"
                    }, Hb.add_to_cart = {
                        event: "add",
                        xa: ic,
                        La: "products"
                    }, Hb.remove_from_cart = {
                        event: "remove",
                        xa: ic,
                        La: "products"
                    }, Hb.begin_checkout = {
                        event: "checkout",
                        xa: ic,
                        La: "products"
                    }, Hb.purchase = {
                        event: "purchase",
                        xa: ic,
                        La: "products"
                    }, Hb.view_item_list = {
                        event: "impressions",
                        xa: ic
                    }, Hb.select_item = {
                        event: "click",
                        La: "products",
                        xa: ic
                    },
                    Hb.view_promotion = {
                        event: "promoView",
                        La: "promotions",
                        xa: ol
                    }, Hb.select_promotion = {
                        event: "promoClick",
                        La: "promotions",
                        xa: ol
                    }, Hb),
                Wi = A("dl.w", function(a, c, b) {
                    function d() {
                        var g = n(a, c);
                        (e = ca(g) && Ge(a, g, b)) || (f = O(a, d, 1E3, "ec.dl"))
                    }
                    var e, f = 0;
                    d();
                    return function() {
                        return ha(a, f)
                    }
                }),
                nt = A("p.e", function(a, c) {
                    var b = za(a, c);
                    if (b) {
                        var d = G(a);
                        b = b.params;
                        var e = D(a, "h.ee", C([a, M(c), b], $p));
                        return c.rd ? (d.D("ecs", 0), Vi(a, c.rd, e)) : qa(c, function(f) {
                            if ((f = n(f, "settings.ecommerce")) && ka(f)) return d.D("ecs", 1), Vi(a, f,
                                e)
                        })
                    }
                }),
                Si = w(function(a) {
                    return I("[^\\d<>]*", a.split(""))
                }),
                mn = w(function(a) {
                    return new RegExp(Si(a), "g")
                }),
                Xp = /\S/,
                Li = u(["style", "display:inline;margin:0;padding:0;font-size:inherit;color:inherit;line-height:inherit"], Nc),
                pl = w(function(a) {
                    return ld(a) || !Od(a)
                }),
                ot = A("phc.h", function(a, c) {
                    if (!hk(a) && !pl(a)) return qa(c, function(b) {
                        if (!n(b, "settings.phchange")) {
                            var d = Pa(a),
                                e = cb(R(a).search, "_ym_hide_phones=1") || d.C("_ym_hide_phones", 0);
                            b = n(b, "settings.phhide");
                            e && !b && (b = ["*"], d.D("_ym_hide_phones",
                                1));
                            b && Di(a, c, b)
                        }
                    })["catch"](D(a, "phc.hs"))
                }),
                ql = w(function(a) {
                    a = R(a);
                    a = xr(a.search.substring(1));
                    a["_ym_status-check"] = a["_ym_status-check"] || "";
                    a._ym_lang = a._ym_lang || "ru";
                    return a
                }),
                Gi = v(ql, Q("_ym_status-check"), Ga),
                pt = v(ql, Q("_ym_lang")),
                Op = /^http:\/\/([\w\-.]+\.)?webvisor\.com\/?$/,
                Pp = /^https:\/\/([\w\-.]+\.)?metri[kc]a\.yandex\.(ru|by|kz|com|com\.tr)\/?$/,
                Fi = fb(/^https:\/\/(yastatic\.net\/s3\/metrika|s3\.mds\.yandex\.net\/internal-metrika-betas|[\w-]+\.dev\.webvisor\.com|[\w-]+\.dev\.metrika\.yandex\.ru)\/(\w|-|\/|(\.)(?!\.))+\.js$/),
                Tp = ["form", "button", "phone", "status"],
                bh = [],
                Qp = w(function(a, c, b) {
                    y(v(Xc([a, c, b]), ja), bh);
                    if (b.inline) {
                        c = Ei(b);
                        var d = b.data;
                        b = b.id;
                        Ai(a, c, void 0 === b ? "" : b, void 0 === d ? "" : d)
                    } else b.resource && Fi(b.resource) && (a._ym__postMessageEvent = c, a._ym__inpageMode = b.inpageMode, a._ym__initMessage = b.initMessage, Up(a, b.resource))
                }, function(a, c, b) {
                    return b.id
                }),
                qt = A("cs.init", function(a, c) {
                    var b, d = Gi(a);
                    if (d && c.id === d && "0" === c.ca) {
                        var e = Ei((b = {}, b.lang = pt(a), b.fileId = "status", b));
                        O(a, C([a, e, "" + d], Ai), 0, "cs")
                    }
                }),
                rt = A("suid.int",
                    function(a, c) {
                        var b;
                        return b = {}, b.setUserID = function(d, e, f) {
                            if (ka(d) || ye(a, d)) {
                                var g = za(a, c);
                                d = Nc(["__ym", "user_id", d]);
                                g.params(d, e || E, f)
                            } else Zd(a, M(c)).error("Incorrect user ID")
                        }, b
                    }),
                Rc = {
                    position: "absolute"
                },
                zi = {
                    position: "fixed"
                },
                Tf = {
                    borderRadius: "50%"
                },
                st = gb("siteStatistics", function(a, c) {
                    if (!hk(a)) return Cb(a)(Qa(E, C([c, v(Q("settings.sm"), Aa(1), C([C([a, c.id], Mp), E], vd), ja)], qa)))
                }),
                tt = A("up.int", function(a, c) {
                    var b;
                    return b = {}, b.userParams = D(a, "up.c", function(d, e, f) {
                        var g, h = za(a, c),
                            k = Hd(a, M(c)).warn;
                        h ? pa(d) ? (d = (g = {}, g.__ymu = d, g), (g = h.params) && g(d, e || E, f)) : k("Wrong user params") : k("No counter instance found")
                    }), b
                }),
                ut = /[\*\.\?\(\)]/g,
                vt = w(function(a, c, b) {
                    try {
                        var d = b.replace("\\s", " ").replace(ut, "");
                        Hd(a, "").warn('Function "' + d + '" has been overridden, this may cause issues with Metrika counter')
                    } catch (e) {}
                }, Za),
                wt = A("r.nn", function(a) {
                    Re(a) && Ge(a, Dg, function(c) {
                        c.za.F(function(b) {
                            vt(a, b[1], b[0]);
                            Dg.splice(100)
                        })
                    })
                }),
                xt = A("e.a.p", function(a, c) {
                    var b, d = za(a, c);
                    d = C([v(P, Fa(!0)), ua(B(u(d, n), ["clickmap",
                        "trackLinks", "accurateTrackBounce"
                    ]))], B);
                    c.Tg && d();
                    return b = {}, b.enableAll = d, b
                }),
                Lp = w(Gc),
                yt = A("fpi", function(a) {
                    var c = yd(a);
                    if (c && !a.document.hidden) {
                        var b = da(a).F(a, ["visibilitychange", "webkitvisibilitychange"], function() {
                            a.document.hidden && (G(a).D("fht", c.now()), b())
                        });
                        Ld.fp = Kp
                    }
                }),
                zt = u("add", xe),
                At = u("remove", xe),
                Bt = u("detail", xe),
                Ct = u("purchase", xe),
                Dt = "FB_IAB FBAV OKApp GSA/ yandex yango uber EatsKit YKeyboard iOSAppUslugi YangoEats PassportSDK".split(" "),
                kf = w(function(a) {
                    var c = Ok(a);
                    a = c.ig;
                    if (!c.lf) return !1;
                    c = Da("indexOf", a);
                    c = Ya(v(c, Aa(-1), Dc), Dt);
                    var b = /CFNetwork\/[0-9][0-9.]*.*Darwin\/[0-9][0-9.]*/.test(a),
                        d = /YaBrowser\/[\d.]+/.test(a),
                        e = /Mobile/.test(a);
                    return c || b || d && e || !/Safari/.test(a) && e
                }),
                Om = w(function(a) {
                    var c = lb(a);
                    return c ? cb(c, "YangoEats") || xd(a) : !1
                }),
                Hp = /([0-9\\.]+) Safari/,
                Et = /\sYptp\/\d\.(\d+)\s/,
                rl = w(function(a) {
                    var c;
                    a: {
                        if ((c = lb(a)) && (c = Et.exec(c)) && 1 < c.length) {
                            c = Ga(c[1]);
                            break a
                        }
                        c = 0
                    }
                    return 50 <= c && 99 >= c || sf(a, 79) ? !1 : !Wd(a) || kf(a)
                }),
                sl = "monospace;sans-serif;serif;Andale Mono;Arial;Arial Black;Arial Hebrew;Arial MT;Arial Narrow;Arial Rounded MT Bold;Arial Unicode MS;Bitstream Vera Sans Mono;Book Antiqua;Bookman Old Style;Calibri;Cambria;Cambria Math;Century;Century Gothic;Century Schoolbook;Comic Sans;Comic Sans MS;Consolas;Courier;Courier New;Garamond;Geneva;Georgia;Helvetica;Helvetica Neue;Impact;Lucida Bright;Lucida Calligraphy;Lucida Console;Lucida Fax;LUCIDA GRANDE;Lucida Handwriting;Lucida Sans;Lucida Sans Typewriter;Lucida Sans Unicode;Microsoft Sans Serif;Monaco;Monotype Corsiva;MS Gothic;MS Outlook;MS PGothic;MS Reference Sans Serif;MS Sans Serif;MS Serif;MYRIAD;MYRIAD PRO;Palatino;Palatino Linotype;Segoe Print;Segoe Script;Segoe UI;Segoe UI Light;Segoe UI Semibold;Segoe UI Symbol;Tahoma;Times;Times New Roman;Times New Roman PS;Trebuchet MS;Verdana;Wingdings;Wingdings 2;Wingdings 3".split(";"),
                Ft = w(function(a) {
                    a = eb(a)("canvas");
                    var c = n(a, "getContext");
                    if (!c) return null;
                    try {
                        var b = H(c, a)("2d");
                        b.font = "72px mmmmmmmmmmlli";
                        var d = b.measureText("mmmmmmmmmmlli").width;
                        return function(e) {
                            b.font = "72px " + e;
                            return b.measureText("mmmmmmmmmmlli").width === d
                        }
                    } catch (e) {
                        return null
                    }
                }),
                tl = na(String.prototype.repeat, "repeat"),
                Uh = tl ? function(a, c) {
                    return tl.call(a, c)
                } : Ep,
                Qh = u(!0, function(a, c, b, d) {
                    b = c.length && (b - d.length) / c.length;
                    if (0 >= b) return d;
                    c = Uh(c, b);
                    return a ? c + d : d + c
                }),
                We = [2277735313, 289559509],
                Xe = [1291169091,
                    658871167
                ],
                Gt = A("p.cd", function(a, c) {
                    if (wd(a) || Te(a)) {
                        var b = Pa(a);
                        if (la(b.C("jn"))) {
                            b.D("jn", !1);
                            var d = a.chrome || zd(a) ? function() {} : /./,
                                e = Zd(a, M(c));
                            d.toString = function() {
                                b.D("jn", !0);
                                return "Yandex.Metrika counter is initialized"
                            };
                            e.log("%c%s", "color: inherit", d)
                        }
                    }
                }),
                Ht = w(function(a) {
                    a = n(a, "navigator.plugins");
                    return !!(a && Ta(a) && Ya(v(Q("name"), fb(/Chrome PDF Viewer/)), a))
                }),
                Qb = sa(function(a, c) {
                    return G(c).C(a, null)
                }),
                Bp = {
                    "*": "+",
                    "-": "/",
                    jj: "=",
                    "+": "*",
                    "/": "-",
                    "=": "_"
                },
                It = w(function(a) {
                    return T(n(a,
                        "yandex.getSiteUid")) ? a.yandex.getSiteUid() : null
                }),
                Jt = w(u("panoramaId", ve)),
                Kt = w(function(a) {
                    return ve("pubcid.org", a) || ve("_pubCommonId", a)
                }),
                Lt = w(u("_sharedid", ve)),
                Mt = w(function(a, c) {
                    if (c.Ta) return null;
                    var b = Lc(a, "").C("_ga");
                    return b && jd(ie(b))
                }, v(Za, M)),
                xp = [
                    ["domainLookupEnd", "domainLookupStart"],
                    ["connectEnd", "connectStart"],
                    ["responseStart", "requestStart"],
                    ["responseEnd", "responseStart"],
                    ["fetchStart", "navigationStart"],
                    ["redirectEnd", "redirectStart"],
                    [function(a, c) {
                        return n(c, "redirectCount") ||
                            n(a, "navigation.redirectCount")
                    }],
                    ["domInteractive", "domLoading"],
                    ["domContentLoadedEventEnd", "domContentLoadedEventStart"],
                    ["domComplete", "navigationStart"],
                    ["loadEventStart", "navigationStart"],
                    ["loadEventEnd", "loadEventStart"],
                    ["domContentLoadedEventStart", "navigationStart"]
                ],
                vb, wp = [
                    ["domainLookupEnd", "domainLookupStart"],
                    ["connectEnd", "connectStart"],
                    ["responseStart", "requestStart"],
                    ["responseEnd", "responseStart"],
                    ["fetchStart"],
                    ["redirectEnd", "redirectStart"],
                    ["redirectCount"],
                    ["domInteractive",
                        "responseEnd"
                    ],
                    ["domContentLoadedEventEnd", "domContentLoadedEventStart"],
                    ["domComplete"],
                    ["loadEventStart"],
                    ["loadEventEnd", "loadEventStart"],
                    ["domContentLoadedEventStart"]
                ],
                wi = (vb = {}, vb.responseEnd = 1, vb.domInteractive = 1, vb.domContentLoadedEventStart = 1, vb.domContentLoadedEventEnd = 1, vb.domComplete = 1, vb.loadEventStart = 1, vb.loadEventEnd = 1, vb.unloadEventStart = 1, vb.unloadEventEnd = 1, vb.secureConnectionStart = 1, vb),
                zp = w(Dd),
                tp = w(Gc),
                up = w(function(a) {
                    var c = n(a, "webkitRequestFileSystem");
                    if (T(c) && !wd(a)) return (new L(H(c,
                        a, 0, 0))).then(function() {
                        var d = n(a, "navigator.storage") || {};
                        return d.estimate ? d.estimate() : {}
                    }).then(function(d) {
                        return (d = d.quota) && 12E7 > d ? !0 : !1
                    })["catch"](u(!0, P));
                    if (Sd(a)) return c = n(a, "navigator.serviceWorker"), L.resolve(W(c));
                    c = n(a, "openDatabase");
                    if (zd(a) && T(c)) {
                        var b = !1;
                        try {
                            c(null, null, null, null)
                        } catch (d) {
                            b = !0
                        }
                        return L.resolve(b)
                    }
                    return L.resolve(!n(a, "indexedDB") && (n(a, "PointerEvent") || n(a, "MSPointerEvent")))
                }),
                Nt = /(\?|&)turbo_uid=([\w\d]+)($|&)/,
                Ot = w(function(a, c) {
                    var b = wc(a),
                        d = R(a).search.match(Nt);
                    return d && 2 <= d.length ? (d = d[2], c.Ta || b.D("turbo_uid", d), d) : (b = b.C("turbo_uid")) ? b : ""
                }),
                Pt = A("pa.plgn", function(a, c) {
                    var b = oe(a, c);
                    b && b.$.F(["pluginInfo"], D(a, "c.plgn", function() {
                        var d = G(a);
                        d.D("cmc", d.C("cmc", 0) + 1);
                        return fk(c)
                    }))
                }),
                Rb, ob, Hm = (Rb = {}, Rb.am = "com.am", Rb.tr = "com.tr", Rb.ge = "com.ge", Rb.il = "co.il", Rb["\u0440\u0444"] = "ru", Rb["xn--p1ai"] = "ru", Rb["\u0431\u0435\u043b"] = "by", Rb["xn--90ais"] = "by", Rb),
                ul = {
                    "mc.edadeal.ru": /^([^/]+\.)?edadeal\.ru$/,
                    "mc.yandexsport.ru": /^([^/]+\.)?yandexsport\.ru$/,
                    "mc.kinopoisk.ru": /^([^/]+\.)?kinopoisk\.ru$/
                },
                Im = (ob = {}, ob.ka = "ge", ob.ro = "md", ob.tg = "tj", ob.tk = "tm", ob.et = "ee", ob.hy = "com.am", ob.he = "co.li", ob.ky = "kg", ob.be = "by", ob.tr = "com.tr", ob.kk = "kz", ob),
                vl = /^https?:\/\//,
                Qt = {
                    1882689622: 1,
                    2318205080: 1,
                    3115871109: 1,
                    3604875100: 1,
                    339366994: 1,
                    2890452365: 1,
                    849340123: 1,
                    173872646: 1,
                    2343947156: 1,
                    655012937: 1,
                    3724710748: 1,
                    3364370932: 1,
                    1996539654: 1,
                    2065498185: 1,
                    823651274: 1,
                    12282461: 1,
                    1555719328: 1,
                    1417229093: 1,
                    138396985: 1,
                    3015043526: 1
                },
                wl = w(function() {
                    return J(function(a,
                        c) {
                        var b = ec(c + "/tag.js");
                        a[b] = 1;
                        return a
                    }, {}, ["mc.yandex.ru/metrika", "mc.yandex.com/metrika", "cdn.jsdelivr.net/npm/yandex-metrica-watch"])
                }),
                Rt = w(function(a) {
                    a = yd(a);
                    if (!a || !T(a.getEntriesByType)) return null;
                    a = a.getEntriesByType("resource");
                    var c = wl();
                    return (a = qb(function(b) {
                        b = b.name.replace(vl, "").split("?")[0];
                        b = ec(b);
                        return c[b]
                    }, a)) ? zb(a.transferSize) : null
                }),
                pp = "ar:1:pv:1:v:" + Ea.cc + ":vf:" + $c.version,
                qp = Ea.Ra + "//" + hc + "/watch/" + Ea.mg,
                xl = {},
                St = A("exps.int", function(a, c) {
                    var b;
                    return b = {}, b.experiments =
                        function(d, e, f) {
                            var g, h;
                            void 0 === e && (e = E);
                            if (d && 0 < d.length) {
                                var k = va(a, "e", c),
                                    l = Gd(c).url;
                                d = k({
                                    K: Ka((g = {}, g.ex = 1, g.ar = 1, g)),
                                    J: (h = {}, h["page-url"] = l || R(a).href, h.exp = d, h)
                                }, c);
                                return Tc(a, "exps.s", d, e, f)
                            }
                        }, b
                }),
                lf = [],
                Tt = A("p.fh", function(a, c) {
                    var b, d;
                    void 0 === c && (c = !0);
                    var e = Pa(a),
                        f = ia(a),
                        g = e.C("wasSynced"),
                        h = {
                            id: 3,
                            ca: "0"
                        };
                    return c && g && g.time + 864E5 > f(Y) ? L.resolve(g) : va(a, "f", h)({
                        K: Ka((b = {}, b.pv = 1, b)),
                        J: (d = {}, d["page-url"] = R(a).href, d["page-ref"] = a.document.referrer, d)
                    }, h).then(function(k) {
                        var l;
                        k = (l = {}, l.time = f(Y), l.params = n(k, "settings"), l.bkParams = n(k, "userData"), l);
                        e.D("wasSynced", k);
                        return k
                    })["catch"](D(a, "f.h"))
                }),
                Ut = sa(function(a, c) {
                    0 === parseFloat(n(c, "settings.c_recp")) && (a.Sd.D("ymoo" + a.oa, a.bg(pb)), a.md && a.md.destruct && a.md.destruct())
                }),
                qf = v(Q("settings.pcs"), Aa("1")),
                fp = [
                    [
                        ["'(-$&$&$'", 30102, 0],
                        ["'(-$&$&$'", 29009, 0]
                    ],
                    [
                        ["oWdZ[nc[jh_YW$Yec", 30103, 1],
                        ["oWdZ[nc[jh_YW$Yec", 29010, 1]
                    ]
                ],
                gp = [
                    [
                        ["oWdZ[nc[jh_YW$Yec", 30103, 1]
                    ],
                    [
                        ["oWdZ[nc[jh_YW$Yec", 29010, 1]
                    ]
                ],
                vi = {
                    J: {
                        t: 'UV|L7,!"T[rwe&D_>ZIb\\aW#98Y.PC6k'
                    }
                },
                cp = {
                    $f: 60,
                    error: 15
                },
                bp = {
                    $f: 5,
                    error: 1
                },
                ti = {
                    id: 42822899,
                    ca: "0"
                },
                yl = hc.split("."),
                Vt = yl.pop(),
                zl = I(".", yl),
                Gm = w(function(a) {
                    a = R(a).hostname.split(".");
                    return a[a.length - 1]
                }),
                uh = w(function(a) {
                    return -1 !== R(a).hostname.search(/(?:^|\.)(?:ya|yandex|beru|kinopoisk|edadeal)\.(?:\w+|com?\.\w+)$/)
                }),
                Wt = /^(.*\.)?((yandex(-team)?)\.(com?\.)?[a-z]+|(auto|kinopoisk|beru|bringly)\.ru|ya\.(ru|cc)|yadi\.sk|yastatic\.net|.*\.yandex|turbopages\.org|turbo\.site|diplodoc\.(com|tech)|datalens\.tech)$/,
                ne = w(function(a) {
                    a =
                        R(a).hostname;
                    var c = !1;
                    a && (c = -1 !== a.search(Wt));
                    return c
                }),
                Xt = /^(.*\.)?((yandex(-team)?)\.(com?\.)?[a-z]+|(auto|kinopoisk|beru|bringly)\.ru|ya\.(ru|cc)|yadi\.sk|.*\.yandex|turbopages\.org|turbo\.site)$/,
                ip = w(function(a) {
                    a = R(a).hostname;
                    var c = !1;
                    a && (c = -1 !== a.search(Xt));
                    return c
                }),
                Al = Ea.Ra + "//" + hc + "/metrika",
                Oc = Al + "/metrika_match.html",
                af, mp = (af = {}, af.s = "p", af["8"] = "i", af),
                jp = gb("csp", function(a, c) {
                    return va(a, "s", c)({}, ["https://ymetrica1.com/watch/3/1"])
                }),
                ch = "et w v z i u vf".split(" "),
                Bl = Pd("wv"),
                Yt = Pd("pub"),
                ii = function() {
                    function a(c, b) {
                        this.l = c;
                        this.type = b
                    }
                    a.isEnabled = function(c) {
                        return !!c.JSON
                    };
                    a.prototype.Ha = function(c) {
                        return Df(yb(this.l, c))
                    };
                    a.prototype.ub = function(c) {
                        var b = c.data;
                        "string" !== typeof b && (b = yb(this.l, c.data));
                        return b
                    };
                    a.prototype.lb = function(c) {
                        return encodeURIComponent(c).length
                    };
                    a.prototype.qe = function(c, b) {
                        for (var d = Math.ceil(c.length / b), e = [], f = 0; f < b; f += 1) e.push(c.slice(f * d, d * (f + 1)));
                        return e
                    };
                    return a
                }(),
                Xo = w(function(a) {
                    function c(f, g, h, k) {
                        d[0] = g;
                        h[k] = e[3];
                        h[k +
                            1] = e[2];
                        h[k + 2] = e[1];
                        h[k + 3] = e[0]
                    }

                    function b(f, g, h, k) {
                        d[0] = g;
                        h[k] = e[0];
                        h[k + 1] = e[1];
                        h[k + 2] = e[2];
                        h[k + 3] = e[3]
                    }
                    if ("undefined" === typeof a.Float32Array || "undefined" === typeof a.Uint8Array) return Yo;
                    var d = new Float32Array([-0]),
                        e = new Uint8Array(d.buffer);
                    return 128 === e[3] ? b : c
                }),
                To = ri(!1),
                So = ri(!0),
                aa, Hc, Cl = (aa = {}, aa.mousemove = 0, aa.mouseup = 1, aa.mousedown = 2, aa.click = 3, aa.scroll = 4, aa.windowblur = 5, aa.windowfocus = 6, aa.focus = 7, aa.blur = 8, aa.eof = 9, aa.selection = 10, aa.change = 11, aa.input = 12, aa.touchmove = 13, aa.touchstart =
                    14, aa.touchend = 15, aa.touchcancel = 16, aa.touchforcechange = 17, aa.zoom = 18, aa.resize = 19, aa.keystroke = 20, aa.deviceRotation = 21, aa.fatalError = 22, aa.hashchange = 23, aa.stylechange = 24, aa.articleInfo = 25, aa.publishersHeader = 26, aa.pageData = 27, aa.mutationAdd = 28, aa.mutationRemove = 29, aa.mutationTextChange = 30, aa.mutationAttributesChange = 31, aa),
                Dl = (Hc = {}, Hc.page = 0, Hc.event = 1, Hc.mutation = 2, Hc.publishers = 3, Hc.activity = 4, Hc),
                hi = function() {
                    function a(c, b) {
                        var d, e, f = this;
                        this.isSync = !1;
                        this.Eb = [];
                        this.Vg = (d = {}, d.ad = "mutationAdd",
                            d.re = "mutationRemove", d.tc = "mutationTextChange", d.ac = "mutationAttributesChange", d.page = "pageData", d);
                        this.Qg = (e = {}, e.ad = "addedNodesMutation", e.re = "removedNodesMutation", e.tc = "textChangeMutation", e.ac = "attributesChangeMutation", e.touchmove = "touchEvent", e.touchstart = "touchEvent", e.touchend = "touchEvent", e.touchforcechange = "touchEvent", e.touchcancel = "touchEvent", e.resize = "resizeEvent", e.scroll = "scrollEvent", e.change = "changeEvent", e.mousemove = "mouseEvent", e.mousedown = "mouseEvent", e.mouseup = "mouseEvent",
                            e.click = "mouseEvent", e.focus = "focusEvent", e.blur = "focusEvent", e.deviceRotation = "deviceRotationEvent", e.zoom = "zoomEvent", e.keystroke = "keystrokesEvent", e.selection = "selectionEvent", e.stylechange = "stylechangeEvent", e.fatalError = "fatalErrorEvent", e.pageData = "page", e);
                        this.ph = function(g) {
                            var h = g.type;
                            return g.event || "publishersHeader" !== h && "articleInfo" !== h ? {
                                type: Dl[h],
                                event: Cl[f.Vg[g.event] || g.event]
                            } : {
                                type: Dl.publishers,
                                event: Cl[h]
                            }
                        };
                        this.tf = function(g) {
                            var h = !W(g.partNum),
                                k = f.ph(g);
                            k = {
                                stamp: g.stamp,
                                type: k.type,
                                event: k.event,
                                frameId: g.frameId,
                                chunk: h ? g.data : void 0,
                                partNum: g.partNum,
                                end: g.end
                            };
                            !h && g.data && (h = f.Qg[g.event] || g.event || g.type) && (k[h] = g.data);
                            return k
                        };
                        this.l = c;
                        this.type = b
                    }
                    a.prototype.Ha = function(c, b) {
                        var d = this;
                        void 0 === b && (b = !1);
                        var e = cc(c, this.tf),
                            f = this.isSync || b ? Infinity : 10;
                        e = kd(this.l, e, f);
                        var g = [e];
                        this.Eb.push(e);
                        return e(Qg(function(h) {
                            h = ki(d.l, Io, {
                                zi: h
                            });
                            h = kd(d.l, h, f, rg);
                            g.push(h);
                            d.Eb.push(h);
                            return h
                        }))(Qg(function(h) {
                            h = ji(d.l, h.slice(-4));
                            h = kd(d.l, h, f, rg);
                            g.push(h);
                            d.Eb.push(h);
                            return h
                        }))(dl(function(h) {
                            h = h[h.length - 1];
                            y(function(k) {
                                k = He(d.l)(k, d.Eb);
                                d.Eb.splice(k, 1)
                            }, g);
                            return h
                        }))
                    };
                    a.prototype.ub = function(c) {
                        return ki(this.l, li, this.tf(c))(sg(E))
                    };
                    a.prototype.lb = function(c) {
                        return c[0]
                    };
                    a.prototype.qe = function(c, b) {
                        for (var d = ji(this.l, c)(sg(E)), e = Math.ceil(d.length / b), f = [], g = 0; g < b; g += 1) f.push(d.slice(g * e, e * (g + 1)));
                        return f
                    };
                    a.isEnabled = function(c) {
                        var b = Re(c),
                            d = !1;
                        try {
                            d = (d = 2 === (new c.Blob(["\u00e4"])).size) && 2 === (new c.Blob([new c.Uint8Array([1, 2])])).size
                        } catch (e) {}
                        return !b &&
                            d && !(!c.Uint8Array || !n(c, "Uint8Array.prototype.slice"))
                    };
                    return a
                }(),
                El = "resize scroll mousemove mousedown click windowfocus keydown orientationchange change focus touchmove touchstart".split(" "),
                Zt = "id pageTitle stamp chars authors updateDate publicationDate pageUrlCanonical topics rubric".split(" "),
                $t = function() {
                    function a(c, b, d, e, f) {
                        var g = this;
                        this.Fc = !1;
                        this.meta = {};
                        this.scroll = {
                            x: 0,
                            y: 0
                        };
                        this.involvedTime = this.rf = 0;
                        this.Td = this.zf = "";
                        this.fa = [];
                        this.oe = this.Ka = 0;
                        this.xb = {
                            h: 0,
                            w: 0
                        };
                        this.buffer = [];
                        this.ng = Zt;
                        this.flush = function() {
                            g.oe = O(g.l, g.flush, 2500);
                            var h = g.Bd();
                            if (g.buffer.length || h) {
                                var k = Id(g.buffer);
                                h && k.push(h);
                                g.zf = g.Td;
                                g.ma.Ha(k)(Qa(D(g.l, "p.b.st"), function(l) {
                                    l && g.Vb(l)
                                }))
                            }
                        };
                        this.Vb = e;
                        this.ma = d;
                        this.bc = H(this.bc, this);
                        this.Bd = H(this.Bd, this);
                        this.flush = H(this.flush, this);
                        this.l = c;
                        this.oa = f;
                        this.Tc = b;
                        this.Od = "pai" + b.id;
                        this.Jb();
                        this.Re = da(this.l);
                        this.time = ia(this.l);
                        this.gg();
                        this.Ed = G(this.l);
                        this.De = null
                    }
                    a.prototype.start = function() {
                        this.oe = O(this.l, this.flush, 2500);
                        if (!this.Fc) {
                            this.Ii();
                            var c = this.Ed.C(this.Od, []),
                                b = !c.length;
                            c.push(H(this.Vh, this));
                            this.Ed.Ia(this.Od, c);
                            b && this.If();
                            this.De = da(this.l).F(this.l, ["click"], H(this.Gi, this));
                            this.bc({
                                type: "page",
                                target: this.l
                            })
                        }
                    };
                    a.prototype.stop = function() {
                        this.Wi();
                        this.Fc = !0;
                        this.flush();
                        ha(this.l, this.oe)
                    };
                    a.prototype.nf = function(c) {
                        return jc("html", this.l, c) !== this.l.document.documentElement
                    };
                    a.prototype.If = function() {
                        var c = this;
                        D(this.l, "p.ic" + this.Tc.id, function() {
                            if (!c.Fc) {
                                var b = c.Ed.C(c.Od),
                                    d = c.Tc.ah();
                                y(function(e) {
                                    var f = B(function(g) {
                                        return z({},
                                            g)
                                    }, d);
                                    T(e) && e(f)
                                }, b);
                                c.Ka = O(c.l, H(c.If, c), 1E3, "p")
                            }
                        })()
                    };
                    a.prototype.Vh = function(c) {
                        this.Fc || (this.Xi(c), this.Yi(), this.Fg())
                    };
                    a.prototype.Kg = function(c, b) {
                        return (c.le || 0) <= (b.le || 0) ? b : c
                    };
                    a.prototype.Gi = function(c) {
                        if (this.fa.length) {
                            c = bj(c);
                            var b = R(this.l).hostname,
                                d;
                            if (d = c) d = Fe(c.hostname) === Fe(b);
                            d && (c = J(this.Kg, this.fa[0], this.fa).id, b = zc(this.l), bd(this.l, this.oa.split(":")[0]).D("pai", c + "-" + b))
                        }
                    };
                    a.prototype.bc = function(c) {
                        var b = this;
                        D(this.l, "p.ec." + this.Tc.id, function() {
                            var d, e;
                            try {
                                var f =
                                    c.type;
                                var g = c.target
                            } catch (p) {
                                return
                            }
                            var h = "page" === f;
                            if ("scroll" === f || h) {
                                var k = [b.l, b.l.document, b.l.document.documentElement, Ec(b.l)];
                                K(g, k) && b.Jb()
                            }("resize" === f || h) && b.gg();
                            f = b.time(Y);
                            var l = Math.min(f - b.rf, 5E3);
                            b.involvedTime += Math.round(l);
                            b.rf = f;
                            if (b.meta && b.scroll && b.xb) {
                                var m = b.xb.h * b.xb.w;
                                b.fa = B(function(p) {
                                    var r = z({}, p),
                                        q = b.meta[r.id],
                                        t = Jc(p.Db);
                                    if (!q || b.nf(r.element) || !t) return r;
                                    p = b.l.Math;
                                    q = p.max((b.scroll.y + b.xb.h - q.y) / q.height, 0);
                                    var x = t.height * t.width;
                                    t = sh(b.l, t, b.xb);
                                    r.le = t / m;
                                    r.visibility =
                                        t / x;
                                    if (.9 <= r.visibility || .1 <= r.le) r.involvedTime += l;
                                    r.maxScrolled = p.round(1E4 * q) / 1E4;
                                    return r
                                }, b.fa);
                                rb(b.l, (d = {}, d.name = "publishers", d.counterKey = b.oa, d.data = (e = {}, e.involvedTime = b.involvedTime, e.contentItems = B(function(p) {
                                    var r;
                                    return z((r = {}, r.contentElement = p.Db, r), p)
                                }, b.fa), e), d))
                            }
                        })()
                    };
                    a.prototype.Xi = function(c) {
                        var b = B(function(d) {
                            return d.id
                        }, this.fa);
                        this.fa = this.fa.concat(fa(function(d) {
                            return !K(d.id, b)
                        }, c))
                    };
                    a.prototype.gg = function() {
                        var c = je(this.l) || Kc(this.l);
                        this.xb = {
                            w: c[0],
                            h: c[1]
                        }
                    };
                    a.prototype.Yi = function() {
                        var c = this;
                        D(this.l, "p.um." + this.Tc.id, function() {
                            var b = [];
                            c.Jb();
                            c.meta = J(function(d, e) {
                                    var f;
                                    if (c.nf(e.element)) b.push(e), delete d[e.id];
                                    else {
                                        var g = (f = {}, f.id = e.id, f.involvedTime = Math.max(e.involvedTime, 0), f.maxScrolled = e.maxScrolled || 0, f.chars = e.update ? e.update("chars") || 0 : 0, f);
                                        e.Db && (f = Jc(e.Db)) && (g.x = Math.max(Math.round(f.left) + c.scroll.x, 0), g.y = Math.max(Math.round(f.top) + c.scroll.y, 0), g.width = Math.round(f.width), g.height = Math.round(f.height));
                                        d[e.id] = g
                                    }
                                    return d
                                }, {},
                                c.fa);
                            y(function(d) {
                                d = He(c.l)(d, c.fa);
                                c.fa.splice(d, 1)
                            }, b)
                        })()
                    };
                    a.prototype.Bd = function() {
                        var c, b, d = B(u(this.meta, n), ea(this.meta));
                        return d.length && (this.Td = yb(this.l, d), this.zf !== this.Td) ? (c = {}, c.type = "publishersHeader", c.data = (b = {}, b.articleMeta = d || [], b.involvedTime = this.involvedTime, b), c) : null
                    };
                    a.prototype.Fg = function() {
                        var c = this;
                        if (this.fa.length) {
                            var b = B(function(d) {
                                var e, f = J(function(g, h) {
                                    d[h] && (g[h] = d[h]);
                                    return g
                                }, {}, c.ng);
                                d.Tf = !0;
                                return e = {}, e.type = "articleInfo", e.stamp = f.stamp, e.data =
                                    f, e
                            }, fa(function(d) {
                                return !d.Tf
                            }, this.fa));
                            b.length && (this.buffer = this.buffer.concat(b), wb(this.l, this.oa, "Publisher content info found: ", b))
                        }
                    };
                    a.prototype.Ii = function() {
                        this.Re.F(this.l, El, this.bc)
                    };
                    a.prototype.Wi = function() {
                        this.De && this.De();
                        this.Re.Zb(this.l, El, this.bc)
                    };
                    a.prototype.Jb = function() {
                        this.scroll = {
                            x: this.l.pageXOffset || n(this.l, "document.documentElement.scrollLeft") || 0,
                            y: this.l.pageYOffset || n(this.l, "document.documentElement.scrollLeft") || 0
                        }
                    };
                    return a
                }(),
                ae, dh = (ae = {}, ae[1] = 500, ae[2] =
                    500, ae[3] = 0, ae),
                au = ["topics", "rubric", "authors"],
                eh = function() {
                    function a(c, b) {
                        var d, e = this;
                        this.id = "a";
                        this.Jd = !1;
                        this.Gb = {};
                        this.tb = {
                            "schema.org": "Article NewsArticle Movie BlogPosting Review Recipe Answer".split(" "),
                            wf: ["article"]
                        };
                        this.Be = (d = {}, d.Answer = 3, d.Review = 2, d);
                        this.Ue = w(function(f, g, h) {
                            wb(e.l, e.oa, "Warning: invalid value " + h + " in " + g + " in field " + f + ", this item will be ignored")
                        }, function(f, g, h) {
                            return "" + f + g + h
                        });
                        this.$i = function(f) {
                            au.forEach(function(g) {
                                f[g] && (f[g] = f[g].reduce(function(h,
                                    k) {
                                    var l = k.name,
                                        m = k.position;
                                    if (!l) return e.Ue(g, "name", l), h;
                                    if ("string" === typeof m) {
                                        l = uf(m);
                                        if (null === l || e.l.isNaN(l)) return e.Ue(g, "position", m), h;
                                        k.position = l
                                    }
                                    h.push(k);
                                    return h
                                }, []))
                            });
                            return f
                        };
                        this.Lg = w(function(f, g) {
                            wb(e.l, e.oa, "Warning: content has only " + g.chars + " chars. Required " + dh[g.type], g)
                        });
                        this.l = c;
                        this.root = dc(c);
                        this.oa = b
                    }
                    a.prototype.Na = function(c) {
                        return c.element
                    };
                    a.prototype.af = function(c, b) {
                        var d = this,
                            e;
                        D(this.l, "P.s." + b, function() {
                            e = d.Gb[b].call(d, c)
                        })();
                        return e
                    };
                    a.prototype.xi =
                        function(c) {
                            var b = z({}, c);
                            this.Jd && !b.id && K(c.type, [3, 2]) && (c = I(", ", B(Q("name"), b.authors || [])), b.pageTitle = c + ": " + b.pageTitle);
                            b.pageTitle || (b.pageTitle = this.zh(b.Db));
                            b.pageUrlCanonical || (c = b.id, b.pageUrlCanonical = ("string" !== typeof c ? 0 : /^(https?:)\/\//.test(c)) ? b.id : this.xh());
                            b.id || (b.id = b.pageTitle || b.pageUrlCanonical);
                            return b
                        };
                    a.prototype.Ea = function(c) {
                        var b = this,
                            d = {},
                            e = this.Na(c);
                        if (!e) return null;
                        d.type = c.type;
                        y(function(g) {
                            d[g] = b.af(c, g)
                        }, ea(this.Gb));
                        var f = ia(this.l);
                        d.stamp = f(Uj);
                        d.element =
                            c.element;
                        d.Db = e;
                        d = this.$i(this.xi(d));
                        d.id = d.id ? ec(d.id) : 1;
                        d.update = function(g) {
                            return b.Na(c) ? b.af(c, g) : void 0
                        };
                        return d
                    };
                    a.prototype.zh = function(c) {
                        for (var b = 1; 5 >= b; b += 1) {
                            var d = $a(bc("h" + b, c));
                            if (d) return d
                        }
                    };
                    a.prototype.xh = function() {
                        var c = bc('[rel="canonical"]', this.root);
                        if (c) return c.href
                    };
                    a.prototype.ff = function() {
                        return 1
                    };
                    a.prototype.wc = function() {
                        return []
                    };
                    a.prototype.ah = function() {
                        var c = this,
                            b = this.wc(),
                            d = 1;
                        return J(function(e, f) {
                            var g = c.Ea({
                                element: f,
                                type: c.ff(f)
                            }) || [];
                            ca(g) || (g = [g]);
                            g = J(function(h, k) {
                                var l = h.values,
                                    m = h.hf;
                                k && k.chars > dh[k.type] && !K(k.id, m) ? (l.push(k), m.push(k.id)) : k && k.chars <= dh[k.type] && c.Lg(k.id, k);
                                return {
                                    values: l,
                                    hf: m
                                }
                            }, {
                                values: [],
                                hf: B(Q("id"), e)
                            }, g).values;
                            return e.concat(B(function(h) {
                                var k;
                                h = z((k = {
                                    index: d,
                                    Tf: !1
                                }, k.involvedTime = 0, k), h);
                                d += 1;
                                return h
                            }, g))
                        }, [], b)
                    };
                    return a
                }(),
                Fl = function(a) {
                    function c() {
                        var b, d = null !== a && a.apply(this, arguments) || this;
                        d.id = "j";
                        d.Jd = !0;
                        d.Oe = I(",", ['script[type="application/ld+json"]', 'script[type="application/json+ld"]', 'script[type="ld+json"]',
                            'script[type="json+ld"]'
                        ]);
                        d.Gb = (b = {}, b.id = function(e) {
                            var f = e.data["@id"];
                            e = e.data.mainEntity || e.data.mainEntityOfPage;
                            !f && pa(e) && (f = e["@id"]);
                            return f
                        }, b.chars = function(e) {
                            var f = e.data;
                            return ka(f.text) ? f.text.length : Kb(this.Na(e)).length
                        }, b.authors = function(e) {
                            e = e.data;
                            var f = [];
                            f = f.concat(this.vc(e, "author"));
                            f = f.concat(this.vc(e.mainEntity, "author"));
                            return f.concat(this.vc(e.mainEntityOfPage, "author"))
                        }, b.pageTitle = function(e) {
                            var f = e.data,
                                g = f.headline || "";
                            f.alternativeHeadline && (g += " " + f.alternativeHeadline);
                            "" === g && (f.name ? g = f.name : f.itemReviewed && (g = f.itemReviewed));
                            3 === e.type && pa(f.parentItem) && (g = f.parentItem.text);
                            return g
                        }, b.updateDate = function(e) {
                            return e.data.dateModified || ""
                        }, b.publicationDate = function(e) {
                            return e.data.datePublished || ""
                        }, b.pageUrlCanonical = function(e) {
                            return e.data.url
                        }, b.topics = function(e) {
                            return this.vc(e.data, "about", ["name", "alternateName"])
                        }, b.rubric = function(e) {
                            var f = this,
                                g = this.Na(e);
                            e = ua(B(function(h) {
                                h = xb(f.l, Kb(h));
                                if (pa(h) || ca(h)) {
                                    var k = f.bf(h);
                                    if (k) return J(function(l,
                                        m) {
                                        return l ? l : pa(m) && "BreadcrumbList" === m["@type"] ? m : l
                                    }, null, k);
                                    if ("BreadcrumbList" === h["@type"]) return h
                                }
                                return null
                            }, [e.element].concat(sb(this.Oe, document.body === g ? document.documentElement : g))));
                            return e.length && (e = e[0].itemListElement, ca(e)) ? ua(B(function(h) {
                                return pa(h) && h.item && pa(h.item) && !f.l.isNaN(h.position) ? {
                                    name: h.item.name || h.name,
                                    position: h.position
                                } : null
                            }, e)) : []
                        }, b);
                        return d
                    }
                    Oa(c, a);
                    c.prototype.vc = function(b, d, e) {
                        void 0 === e && (e = ["name"]);
                        if (!b || !b[d]) return [];
                        b = ca(b[d]) ? b[d] : [b[d]];
                        b = ua(B(function(f) {
                            return f ? "string" === typeof f ? f : J(function(g, h) {
                                return g || "" + f[h]
                            }, "", e) : null
                        }, b));
                        return B(function(f) {
                            var g;
                            return g = {}, g.name = f, g
                        }, b)
                    };
                    c.prototype.Na = function(b) {
                        var d = b.element,
                            e = b.data || {};
                        b = e["@id"];
                        var f = e.url;
                        e = null;
                        f && ka(f) && (e = this.Te(f));
                        !e && b && ka(b) && (e = this.Te(b));
                        e || (e = b = d.parentNode, !jc("head", this.l, d) && b && 0 !== Kb(b).length) || (e = this.l.document.body);
                        return e
                    };
                    c.prototype.Te = function(b) {
                        try {
                            var d = Pc(this.l, b).hash;
                            if (d) {
                                var e = bc(d, this.l.document.body);
                                if (e) return e
                            }
                        } catch (f) {}
                        return null
                    };
                    c.prototype.Zd = function(b) {
                        return this.Be[b["@type"]] || 1
                    };
                    c.prototype.Ea = function(b) {
                        var d = this,
                            e = b.element,
                            f = b.data;
                        if (!f && (f = xb(this.l, Kb(e)), !f || !/schema\.org/.test(f["@context"]) && !ca(f))) return null;
                        var g = this.bf(f);
                        if (g) return B(function(k) {
                            return pa(k) && K(k["@type"], d.tb["schema.org"]) ? a.prototype.Ea.call(d, {
                                element: e,
                                data: k,
                                type: d.Zd(k)
                            }) : null
                        }, g);
                        b.data = f;
                        if ("QAPage" === b.data["@type"]) {
                            var h = b.data.mainEntity || b.data.mainEntityOfPage;
                            if (!h) return null
                        }
                        "Question" === b.data["@type"] && (h = b.data);
                        return h ? (b = rc(u(h, n), ["acceptedAnswer", "suggestedAnswer"]), B(function(k) {
                            var l;
                            if (!pa(k) || !K(k["@type"], d.tb["schema.org"])) return null;
                            k = {
                                element: e,
                                type: d.Zd(k),
                                data: z((l = {}, l.parentItem = h, l), k)
                            };
                            return a.prototype.Ea.call(d, k)
                        }, b)) : K(b.data["@type"], this.tb["schema.org"]) ? a.prototype.Ea.call(this, z(b, {
                            type: this.Zd(b.data)
                        })) : null
                    };
                    c.prototype.wc = function() {
                        return sb(this.Oe, this.root)
                    };
                    c.prototype.bf = function(b) {
                        if (ca(b)) return b;
                        if (b && ca(b["@graph"])) return b["@graph"]
                    };
                    return c
                }(eh),
                fh = function(a) {
                    function c() {
                        var b,
                            d = null !== a && a.apply(this, arguments) || this;
                        d.id = "s";
                        d.Jd = !0;
                        d.Vi = Da("exec", new RegExp("schema.org\\/(" + I("|", ea(d.Be)) + ")$"));
                        d.Gb = (b = {}, b.id = function(e) {
                            e = e.element;
                            var f = hb(this.l, e, "identifier");
                            return f ? $a(f) : (f = hb(this.l, e, "mainEntityOfPage")) && f.getAttribute("itemid") ? f.getAttribute("itemid") : null
                        }, b.chars = function(e) {
                            var f = 0;
                            e = e.element;
                            for (var g = ["articleBody", "reviewBody", "recipeInstructions", "description", "text"], h = 0; h < g.length; h += 1) {
                                var k = hb(this.l, e, g[h]);
                                if (k) {
                                    f = $a(k).length;
                                    break
                                }
                            }
                            e =
                                Kb(e);
                            0 === f && e && (f += e.length);
                            return f
                        }, b.topics = function(e) {
                            var f = this,
                                g = Vd(this.l, e.element, "about");
                            return B(function(h) {
                                var k = {
                                    name: $a(h)
                                };
                                if (g = hb(f.l, h, "name")) k.name = $a(g);
                                return k
                            }, g)
                        }, b.rubric = function(e) {
                            var f = this;
                            (e = bc('[itemtype$="schema.org/BreadcrumbList"]', e.element)) || (e = bc('[itemtype$="schema.org/BreadcrumbList"]', this.root));
                            return e ? B(function(g) {
                                return {
                                    name: $a(hb(f.l, g, "name")),
                                    position: $a(hb(f.l, g, "position"))
                                }
                            }, Vd(this.l, e, "itemListElement")) : []
                        }, b.updateDate = function(e) {
                            return (e =
                                hb(this.l, e.element, "dateModified")) ? vk(e) : ""
                        }, b.publicationDate = function(e) {
                            return (e = hb(this.l, e.element, "datePublished")) ? vk(e) : ""
                        }, b.pageUrlCanonical = function(e) {
                            e = Vd(this.l, e.element, "url");
                            if (e.length) {
                                var f = e[0];
                                return f.href ? f.href : $a(e)
                            }
                            return null
                        }, b.pageTitle = function(e) {
                            var f = "",
                                g = e.element,
                                h = hb(this.l, g, "headline");
                            h && (f += $a(h));
                            (h = hb(this.l, g, "alternativeHeadline")) && (f += " " + $a(h));
                            "" === f && ((h = hb(this.l, g, "name")) || (h = hb(this.l, g, "itemReviewed")), h && (f += $a(h)));
                            3 === e.type && (e = jc('[itemtype$="schema.org/Question"]',
                                this.l, g)) && (e = hb(this.l, e, "text")) && (f += $a(e));
                            return f
                        }, b.authors = function(e) {
                            var f = this;
                            e = Vd(this.l, e.element, "author");
                            return B(function(g) {
                                var h, k = (h = {}, h.name = "", h);
                                /.+schema.org\/(Person|Organization)/.test(g.getAttribute("itemtype") || "") && (h = hb(f.l, g, "name")) && (k.name = $a(h));
                                k.name || (k.name = g.getAttribute("content") || Kb(g) || g.getAttribute("href"));
                                return k
                            }, e)
                        }, b);
                        return d
                    }
                    Oa(c, a);
                    c.prototype.ff = function(b) {
                        b = b.getAttribute("itemtype") || "";
                        return (b = this.Vi(b)) ? this.Be[b[1]] : 1
                    };
                    c.prototype.Ea =
                        function(b) {
                            return b.element && Kb(b.element).length ? a.prototype.Ea.call(this, b) : null
                        };
                    c.prototype.wc = function() {
                        var b = I(",", B(function(d) {
                            return '[itemtype$="schema.org/' + d + '"]'
                        }, this.tb["schema.org"]));
                        return sb(b, this.root)
                    };
                    return c
                }(eh),
                Gl = function(a) {
                    function c(b, d) {
                        var e, f = a.call(this, b, d) || this;
                        f.id = "o";
                        f.Gb = (e = {}, e.chars = function(g) {
                                g = this.Na(g);
                                return Kb(g).length
                            }, e.authors = function(g) {
                                return this.xd(g.data.author)
                            }, e.pageTitle = function(g) {
                                return this.Ac(g.data.title) || ""
                            }, e.updateDate = function(g) {
                                return this.Ac(g.data.modified_time)
                            },
                            e.publicationDate = function(g) {
                                return this.Ac(g.data.published_time)
                            }, e.pageUrlCanonical = function(g) {
                                return this.Ac(g.data.url)
                            }, e.rubric = function(g) {
                                return this.xd(g.data.section)
                            }, e.topics = function(g) {
                                return this.xd(g.data.tag)
                            }, e);
                        f.Ug = new RegExp("^(og:)?((" + I("|", f.tb.wf) + "):)?");
                        return f
                    }
                    Oa(c, a);
                    c.prototype.xd = function(b) {
                        var d;
                        return b ? ca(b) ? B(function(e) {
                            var f;
                            return f = {}, f.name = e ? "" + e : null, f
                        }, b) : [(d = {}, d.name = b ? "" + b : null, d)] : []
                    };
                    c.prototype.Ac = function(b) {
                        return ca(b) ? b.length ? "" + b[0] : null :
                            b ? "" + b : null
                    };
                    c.prototype.wc = function() {
                        var b = sb('meta[property="og:type"]', this.l.document.body);
                        return [this.l.document.head].concat(b)
                    };
                    c.prototype.oh = function(b) {
                        var d = this,
                            e = b.element,
                            f = {},
                            g = this.Na(b);
                        e = sb("meta[property]", e === this.l.document.head ? e : g);
                        if (e.length) y(function(h) {
                            try {
                                if (h.parentNode === g || h.parentNode === d.l.document.head) {
                                    var k = h.getAttribute("property").replace(d.Ug, ""),
                                        l = $a(h);
                                    f[k] ? ca(f[k]) ? f[k].push(l) : f[k] = [f[k], l] : f[k] = l
                                }
                            } catch (m) {
                                ue(d.l, "og.ed", m)
                            }
                        }, e);
                        else return null;
                        return K(f.type,
                            this.tb.wf) ? z(b, {
                            data: f
                        }) : null
                    };
                    c.prototype.Na = function(b) {
                        b = b.element;
                        var d = this.l.document;
                        return b === d.head ? d.body : b.parentNode
                    };
                    c.prototype.Ea = function(b) {
                        return (b = this.oh(b)) ? a.prototype.Ea.call(this, b) : null
                    };
                    return c
                }(eh),
                be = {};
            Fl && (be.json_ld = Fl);
            fh && (be.schema = fh, be.microdata = fh);
            Gl && (be.opengraph = Gl);
            var bu = A("p.p", function(a, c) {
                    function b(m) {
                        var p = z({}, l);
                        p.ba.da = m;
                        return f(p, c)["catch"](D(a, "s.ww.p"))
                    }
                    var d, e = gi(a, "9", "8");
                    if (!Ia("querySelectorAll", a.document.querySelectorAll) || !e) return L.resolve();
                    var f = va(a, "p", c),
                        g = Ka(),
                        h = bd(a, c.id),
                        k = h.C("pai");
                    k && (h.Fb("pai"), g.D("pai", k));
                    var l = {
                        J: (d = {}, d["wv-type"] = e.type, d),
                        K: g,
                        ba: {}
                    };
                    return qa(c, D(a, "ps.s", function(m) {
                        if (m = n(m, "settings.publisher.schema")) {
                            gk(c) && (m = "microdata");
                            var p = be[m];
                            if (p && e) {
                                var r = M(c);
                                p = new p(a, r);
                                p = new $t(a, p, e, b, r);
                                p.start();
                                wb(a, r, 'Publishers analytics schema "' + m + '"');
                                return H(p.stop, p)
                            }
                        }
                    }))
                }),
                cu = function() {
                    function a(c, b) {
                        this.type = "0";
                        this.l = c;
                        this.mh = b
                    }
                    a.prototype.Ha = function(c) {
                        return Df(rc(H(this.ub, this), c))
                    };
                    a.prototype.ub =
                        function(c, b) {
                            var d = this,
                                e = [],
                                f = this.mh(this.l, b && b.type, c.type);
                            f && (e = rc(function(g) {
                                return g({
                                    l: d.l,
                                    qa: c
                                }) || []
                            }, f));
                            return e
                        };
                    a.prototype.lb = function(c) {
                        return c.length
                    };
                    a.prototype.qe = function(c) {
                        return [c]
                    };
                    a.prototype.isEnabled = function() {
                        return !0
                    };
                    return a
                }(),
                Hl = function() {
                    function a(c, b, d) {
                        this.Pe = 0;
                        this.$d = 1;
                        this.bd = 5E3;
                        this.l = c;
                        this.ma = b;
                        this.Vb = d
                    }
                    a.prototype.Wc = function() {
                        this.Pe = O(this.l, v(H(this.flush, this), H(this.Wc, this)), this.bd, "b.f")
                    };
                    a.prototype.send = function(c, b) {
                        var d = this.Vb(c,
                            b || [], this.$d);
                        this.$d += 1;
                        return d
                    };
                    a.prototype.push = function() {};
                    a.prototype.flush = function() {};
                    return a
                }(),
                Xn = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.buffer = [];
                        b.og = 7500;
                        b.bd = 3E4;
                        b.Wc();
                        return b
                    }
                    Oa(c, a);
                    c.prototype.push = function(b, d) {
                        var e = this.ma.ub(b, d);
                        ra(this.buffer, e);
                        this.ma.lb(this.buffer) > this.og && this.flush()
                    };
                    c.prototype.flush = function() {
                        var b = this.buffer;
                        b.length && (this.send(b), this.buffer = [])
                    };
                    return c
                }(Hl),
                mo = /opera mini/i,
                ai = ["phone", "email"],
                Il = "first(-|\\.|_|\\s){0,2}name last(-|\\.|_|\\s){0,2}name zip postal address passport (bank|credit)(-|\\.|_|\\s){0,2}card card(-|\\.|_|\\s){0,2}number card(-|\\.|_|\\s){0,2}holder cvv card(-|\\.|_|\\s){0,2}exp card(-|\\.|_|\\s){0,2}name card.*month card.*year card.*month card.*year password birth(-|\\.|_|\\s){0,2}(day|date) second(-|\\.|_|\\s){0,2}name third(-|\\.|_|\\s){0,2}name patronymic middle(-|\\.|_|\\s){0,2}name birth(-|\\.|_|\\s){0,2}place house street city flat state contact.*".split(" "),
                jo = /^[\w\u0410-\u042f\u0430-\u044f]$/,
                ko = [65, 90],
                lo = [97, 122],
                ho = "color radio checkbox date datetime-local email month number password range search tel text time url week".split(" "),
                fo = new RegExp("(" + I("|", Il) + ")", "i"),
                eo = new RegExp("(" + I("|", ai) + ")", "i"),
                wk = ["password", "passwd", "pswd"],
                go = new RegExp("(" + I("|", Il.concat("\u0438\u043c\u044f \u0444\u0430\u043c\u0438\u043b\u0438\u044f \u043e\u0442\u0447\u0435\u0441\u0442\u0432\u043e \u0438\u043d\u0434\u0435\u043a\u0441 \u0442\u0435\u043b\u0435\u0444\u043e\u043d \u0430\u0434\u0440\u0435\u0441 \u043f\u0430\u0441\u043f\u043e\u0440\u0442 \u043d\u043e\u043c\u0435\u0440(-|\\.|_|\\s){0,2}\u043a\u0430\u0440\u0442\u044b \u0434\u0430\u0442\u0430(-|\\.|_|\\s){0,2}\u0440\u043e\u0436\u0434\u0435\u043d\u0438\u044f \u0434\u043e\u043c \u0443\u043b\u0438\u0446\u0430 \u043a\u0432\u0430\u0440\u0442\u0438\u0440\u0430 \u0433\u043e\u0440\u043e\u0434 \u043e\u0431\u043b\u0430\u0441\u0442\u044c".split(" "))) +
                    ")", "i"),
                Xa = "metrikaId_" + Math.random(),
                vc = {
                    counter: 0
                },
                cs = w(function() {
                    var a;
                    return a = {}, a.A = 1, a.ABBR = 2, a.ACRONYM = 3, a.ADDRESS = 4, a.APPLET = 5, a.AREA = 6, a.B = 7, a.BASE = 8, a.BASEFONT = 9, a.BDO = 10, a.BIG = 11, a.BLOCKQUOTE = 12, a.BODY = 13, a.BR = 14, a.BUTTON = 15, a.CAPTION = 16, a.CENTER = 17, a.CITE = 18, a.CODE = 19, a.COL = 20, a.COLGROUP = 21, a.DD = 22, a.DEL = 23, a.DFN = 24, a.DIR = 25, a.DIV = 26, a.DL = 27, a.DT = 28, a.EM = 29, a.FIELDSET = 30, a.FONT = 31, a.FORM = 32, a.FRAME = 33, a.FRAMESET = 34, a.H1 = 35, a.H2 = 36, a.H3 = 37, a.H4 = 38, a.H5 = 39, a.H6 = 40, a.HEAD = 41, a.HR = 42, a.HTML =
                        43, a.I = 44, a.IFRAME = 45, a.IMG = 46, a.INPUT = 47, a.INS = 48, a.ISINDEX = 49, a.KBD = 50, a.LABEL = 51, a.LEGEND = 52, a.LI = 53, a.LINK = 54, a.MAP = 55, a.MENU = 56, a.META = 57, a.NOFRAMES = 58, a.NOSCRIPT = 59, a.OBJECT = 60, a.OL = 61, a.OPTGROUP = 62, a.OPTION = 63, a.P = 64, a.PARAM = 65, a.PRE = 66, a.Q = 67, a.S = 68, a.SAMP = 69, a.SCRIPT = 70, a.SELECT = 71, a.SMALL = 72, a.SPAN = 73, a.STRIKE = 74, a.STRONG = 75, a.STYLE = 76, a.SUB = 77, a.SUP = 78, a.TABLE = 79, a.TBODY = 80, a.TD = 81, a.TEXTAREA = 82, a.TFOOT = 83, a.TH = 84, a.THEAD = 85, a.TITLE = 86, a.TR = 87, a.TT = 88, a.U = 89, a.UL = 90, a.VAR = 91, a.NOINDEX =
                        100, a
                }),
                $r = [17, 18, 38, 32, 39, 15, 11, 7, 1],
                du = function() {
                    var a = "first(-|\\.|_|\\s){0,2}name last(-|\\.|_|\\s){0,2}name zip postal phone address passport (bank|credit)(-|\\.|_|\\s){0,2}card card(-|\\.|_|\\s){0,2}number card(-|\\.|_|\\s){0,2}holder cvv card(-|\\.|_|\\s){0,2}exp card(-|\\.|_|\\s){0,2}name card.*month card.*year card.*month card.*year password email birth(-|\\.|_|\\s){0,2}(day|date) second(-|\\.|_|\\s){0,2}name third(-|\\.|_|\\s){0,2}name patronymic middle(-|\\.|_|\\s){0,2}name birth(-|\\.|_|\\s){0,2}place house street city flat state".split(" ");
                    return {
                        sj: new RegExp("(" + I("|", a) + ")", "i"),
                        Cj: new RegExp("(" + I("|", a.concat("\u0438\u043c\u044f;\u0444\u0430\u043c\u0438\u043b\u0438\u044f;\u043e\u0442\u0447\u0435\u0441\u0442\u0432\u043e;\u0438\u043d\u0434\u0435\u043a\u0441;\u0442\u0435\u043b\u0435\u0444\u043e\u043d;\u0430\u0434\u0440\u0435\u0441;\u043f\u0430\u0441\u043f\u043e\u0440\u0442;\u041d\u043e\u043c\u0435\u0440(-|\\.|_|\\s){0,2}\u043a\u0430\u0440\u0442\u044b;\u0434\u0430\u0442\u0430(-|\\.|_|\\s){0,2} \u0440\u043e\u0436\u0434\u0435\u043d\u0438\u044f;\u0434\u043e\u043c;\u0443\u043b\u0438\u0446\u0430;\u043a\u0432\u0430\u0440\u0442\u0438\u0440\u0430;\u0433\u043e\u0440\u043e\u0434;\u043e\u0431\u043b\u0430\u0441\u0442\u044c".split(";"))) +
                            ")", "i"),
                        qj: /ym-record-keys/i,
                        hi: "\u2022",
                        Bj: 88
                    }
                }(),
                Bk = Mb(u(du.hi, P)),
                rd = !0,
                Jg = "",
                Kg = !1,
                Lg = !0,
                Mg = !1,
                bo = sa(function(a, c) {
                    var b = C([a, "efv." + c.event], D);
                    c.O = B(v(P, b), c.O);
                    return c
                }),
                Jl = w(function(a) {
                    var c = [],
                        b = [],
                        d = [];
                    a.document.attachEvent && !a.opera && (c.push(Jf), b.push(fs), b.push(gs));
                    a.document.addEventListener ? c.push(zk) : (b.push(yk), d.push(zk));
                    return ao(a, [{
                            target: a,
                            type: "window",
                            event: "beforeunload",
                            O: [E]
                        }, {
                            target: a,
                            type: "window",
                            event: "unload",
                            O: [E]
                        }, {
                            event: "click",
                            O: [Ye]
                        }, {
                            event: "dblclick",
                            O: [Ye]
                        },
                        {
                            event: "mousedown",
                            O: [Ye]
                        }, {
                            event: "mouseup",
                            O: [is]
                        }, {
                            event: "keydown",
                            O: [js]
                        }, {
                            event: "keypress",
                            O: [ks]
                        }, {
                            event: "copy",
                            O: [Dk]
                        }, {
                            event: "blur",
                            O: c
                        }, {
                            event: "focusin",
                            O: b
                        }, {
                            event: "focusout",
                            O: d
                        }
                    ].concat(!a.document.attachEvent || a.opera ? [{
                        target: a,
                        type: "window",
                        event: "focus",
                        O: [Zh]
                    }, {
                        target: a,
                        type: "window",
                        event: "blur",
                        O: [Jf]
                    }] : []).concat(a.document.addEventListener ? [{
                        event: "focus",
                        O: [yk]
                    }, {
                        event: "change",
                        O: [Ak]
                    }, {
                        event: "submit",
                        O: [Fk]
                    }] : [{
                        type: "formInput",
                        event: "change",
                        O: [Ak]
                    }, {
                        type: "form",
                        event: "submit",
                        O: [Fk]
                    }]))
                }),
                Zn = w(function(a) {
                    return Ec(a) ? [{
                        target: a,
                        type: "document",
                        event: "mouseleave",
                        O: [ls]
                    }] : []
                }),
                eu = ["submit", "beforeunload", "unload"],
                fu = w(function(a, c) {
                    var b = c(a);
                    return J(function(d, e) {
                        d[e.type + ":" + e.event] = e.O;
                        return d
                    }, {}, b)
                }),
                gu = u(Jl, function(a, c, b, d) {
                    return fu(c, a)[b + ":" + d] || []
                }),
                $n = /^\s*function submit\(\)/,
                hu = A("fw.p", function(a, c) {
                    var b;
                    if (!(b = c.Rg || !c.yb)) {
                        var d = G(a),
                            e = !1;
                        b = d.C("hitParam", {});
                        var f = M(c);
                        b[f] && (d = d.C("counters", {}), e = fe(c.ca) && !d[f]);
                        b[f] = 1;
                        b = e
                    }
                    if (b) return L.resolve(E);
                    b = new cu(a, gu);
                    return Wn(a, c, b, Jl, eu)
                }),
                gh, Kl = (gh = function(a) {
                    function c(b, d, e, f) {
                        void 0 === f && (f = 0);
                        d = a.call(this, b, d, e) || this;
                        d.ye = 0;
                        d.Bb = 0;
                        d.xe = 0;
                        d.buffer = [];
                        d.bd = 2E3;
                        d.$ = pd(b);
                        d.Wc();
                        d.xe = f;
                        return d
                    }
                    Oa(c, a);
                    c.prototype.Ze = function(b) {
                        return ua(this.$.T("ag", b))
                    };
                    c.prototype.Ye = function(b, d) {
                        var e = this;
                        b(Qa(D(this.l, "wv2.b.st"), function(f) {
                            e.send(f, d)
                        }))
                    };
                    c.prototype.Hi = function(b, d) {
                        var e = this;
                        ha(this.l, this.Pe);
                        var f = Math.ceil(this.ma.lb(d) / 63E4),
                            g = this.ma.qe(d, f);
                        y(function(h, k) {
                            var l, m = z({},
                                b, (l = {}, l.data = h, l.partNum = k + 1, l.end = k + 1 === f, l.partsTotal = g.length, l));
                            l = e.ma.Ha([m], !1);
                            e.Ye(l, [m])
                        }, g);
                        this.Wc()
                    };
                    c.prototype.send = function(b, d) {
                        var e = this;
                        this.$.T("se", d);
                        return a.prototype.send.call(this, b, d).then(P, function() {
                            e.$.T("see", d)
                        })
                    };
                    c.$e = function(b, d, e, f, g) {
                        c.ed["" + b + d] || (this.ed[d] = new c(g, f, e, "m" === d ? 31457280 : 0));
                        return this.ed[d]
                    };
                    c.prototype.Th = function() {
                        return this.xe && this.ye >= this.xe
                    };
                    c.prototype.push = function(b) {
                        var d = this;
                        if (!this.Th()) {
                            this.$.T("p", b);
                            var e = this.ma.ub(b),
                                f = this.ma.lb(e);
                            7E5 < f ? this.Hi(b, e) : (e = this.Ze(this.buffer.concat([b])), e = J(function(g, h) {
                                return g + d.ma.lb(d.ma.ub(h))
                            }, 0, e), this.Bb + e + f >= 7E5 * .7 && this.flush(), this.buffer.push(b), this.Bb += f)
                        }
                    };
                    c.prototype.F = function(b, d) {
                        this.$.F([b], d)
                    };
                    c.prototype.ga = function(b, d) {
                        this.$.ga([b], d)
                    };
                    c.prototype.flush = function(b) {
                        var d = this.buffer.concat(this.Ze(this.buffer));
                        d.length && (this.buffer = [], this.ye += this.Bb, this.Bb = 0, b = this.ma.Ha(d, b), this.Ye(b, d))
                    };
                    return c
                }(Hl), gh.ed = {}, gh),
                ab = function() {
                    function a(c,
                        b, d) {
                        this.Xh = "wv2.c";
                        this.Ob = [];
                        this.ia = [];
                        this.l = c;
                        this.L = Hf(c, this, d, this.Xh);
                        this.G = b;
                        this.eb = this.G.rh();
                        this.start = this.L.H(this.start, "st");
                        this.stop = this.L.H(this.stop, "sp")
                    }
                    a.prototype.start = function() {
                        var c = this;
                        this.Ob = B(function(b) {
                            var d = b[0],
                                e = b[2];
                            b = H(c.L.H(b[1], d[0]), c);
                            return c.eb.F(e || c.l, d, b)
                        }, this.ia)
                    };
                    a.prototype.stop = function() {
                        y(ja, this.Ob)
                    };
                    a.prototype.Z = function(c) {
                        return this.G.sa().Z(c)
                    };
                    return a
                }(),
                Un = ["checkbox", "radio"],
                Vn = /pwd|value|password/i,
                hh = Q("location.href"),
                iu =
                function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.ra = {
                            elements: [],
                            attributes: []
                        };
                        d.index = 0;
                        d.Vd = d.L.H(d.Vd, "o");
                        d.nd = d.L.H(d.nd, "io");
                        d.cd = d.L.H(d.cd, "ao");
                        d.de = d.L.H(d.de, "a");
                        d.ae = d.L.H(d.ae, "at");
                        d.ee = d.L.H(d.ee, "r");
                        d.ce = d.L.H(d.ce, "c");
                        d.za = new b.MutationObserver(d.Vd);
                        return d
                    }
                    Oa(c, a);
                    c.prototype.start = function() {
                        this.za.observe(this.l.document.documentElement, {
                            attributes: !0,
                            characterData: !0,
                            childList: !0,
                            subtree: !0,
                            attributeOldValue: !0,
                            characterDataOldValue: !0
                        })
                    };
                    c.prototype.stop = function() {
                        this.za.disconnect()
                    };
                    c.prototype.cd = function(b) {
                        var d = b.target;
                        b = b.attributeName;
                        var e = Ob(this.l)(d, this.ra.elements); - 1 === e && (e = this.ra.elements.push(d) - 1, this.ra.attributes[e] = {});
                        this.ra.attributes[e] || (this.ra.attributes[e] = {});
                        e = this.ra.attributes[e];
                        var f = d.getAttribute(b);
                        e[b] = re(this.l, d, b, f, this.G.Ib()).value
                    };
                    c.prototype.nd = function(b) {
                        function d(k) {
                            var l = Ob(e.l)(k, f);
                            return -1 === l ? (f.push(k), k = {
                                vd: {}
                            }, g.push(k), k) : g[l]
                        }
                        var e = this,
                            f = [],
                            g = [];
                        y(function(k) {
                            var l = k.attributeName,
                                m = k.removedNodes,
                                p = k.oldValue,
                                r =
                                k.target,
                                q = k.nextSibling,
                                t = k.previousSibling;
                            switch (k.type) {
                                case "attributes":
                                    e.cd(k);
                                    var x = d(r);
                                    x.vd[l] || (x.vd[l] = re(e.l, r, l, p, e.G.Ib()).value);
                                    break;
                                case "childList":
                                    m && y(function(F) {
                                        x = d(F);
                                        x.We || z(x, {
                                            We: r,
                                            gh: q ? q : void 0,
                                            hh: t ? t : void 0
                                        })
                                    }, Ba(m));
                                    break;
                                case "characterData":
                                    x = d(r), x.Xe || (x.Xe = p)
                            }
                        }, b);
                        var h = this.G.sa();
                        y(function(k, l) {
                            h.pe(k, g[l])
                        }, f)
                    };
                    c.prototype.Vd = function(b) {
                        var d = this;
                        if (hh(this.l)) {
                            var e = this.G.stamp();
                            this.nd(b);
                            y(function(f) {
                                var g = f.addedNodes,
                                    h = f.removedNodes,
                                    k = f.target;
                                switch (f.type) {
                                    case "childList":
                                        h &&
                                            h.length && d.ee(Ba(h), e);
                                        g && g.length && d.de(Ba(g), e);
                                        break;
                                    case "characterData":
                                        d.ce(k, e)
                                }
                            }, b);
                            this.ae(e)
                        } else this.stop()
                    };
                    c.prototype.ae = function(b) {
                        var d = this;
                        y(function(e, f) {
                            var g = d.yc();
                            d.G.Y("mutation", {
                                index: g,
                                attributes: d.ra.attributes[f],
                                target: d.Z(e)
                            }, "ac", b)
                        }, this.ra.elements);
                        this.ra.elements = [];
                        this.ra.attributes = []
                    };
                    c.prototype.de = function(b, d) {
                        var e = this,
                            f = this.yc();
                        this.G.sa().Cc({
                            nodes: b,
                            Vc: function(g) {
                                g = B(function(h) {
                                    h.node = void 0;
                                    return h
                                }, g);
                                e.G.Y("mutation", {
                                        index: f,
                                        nodes: g
                                    }, "ad",
                                    d)
                            }
                        })
                    };
                    c.prototype.ee = function(b, d) {
                        var e = this,
                            f = this.yc(),
                            g = this.G.sa(),
                            h = B(function(k) {
                                var l = g.removeNode(k);
                                Ti(e.l, k, function(m) {
                                    g.removeNode(m)
                                });
                                return l
                            }, b);
                        this.G.Y("mutation", {
                            index: f,
                            nodes: h
                        }, "re", d)
                    };
                    c.prototype.ce = function(b, d) {
                        var e = this.yc();
                        this.G.Y("mutation", {
                            value: b.textContent,
                            target: this.Z(b),
                            index: e
                        }, "tc", d)
                    };
                    c.prototype.yc = function() {
                        var b = this.index;
                        this.index += 1;
                        return b
                    };
                    return c
                }(ab),
                ju = function() {
                    function a(c, b) {
                        var d = this;
                        this.uc = [];
                        this.fb = [];
                        this.Ud = 1;
                        this.Me = this.Pf =
                            0;
                        this.ya = {};
                        this.Mb = {};
                        this.Hb = [];
                        this.Gd = function(f) {
                            return d.fb.length ? K(f, d.fb) : !1
                        };
                        this.removeNode = function(f) {
                            var g = d.Z(f),
                                h = Na(f);
                            if (h) return h = "NR:" + h.toLowerCase(), d.Gd(h) && d.$.T(h, {
                                data: {
                                    node: f,
                                    id: g
                                }
                            }), g
                        };
                        this.kb = function(f) {
                            var g = Na(f);
                            if (g) {
                                var h = f.__ym_indexer;
                                return h ? h : (h = d.Ud, f.__ym_indexer = h, d.Ud += 1, g = "NA:" + g.toLowerCase(), d.Gd(g) && d.$.T(g, {
                                    data: {
                                        node: f,
                                        id: h
                                    }
                                }), h)
                            }
                            return null
                        };
                        this.Jf = function() {
                            d.Pf = O(d.l, v(H(d.aa, d, !1), d.Jf), 50, "i.s")
                        };
                        this.Hf = function() {
                            d.Me = O(d.l, v(H(d.hd, d, !1),
                                d.Hf), 50, "i.g")
                        };
                        this.Ai = function(f) {
                            null === d.ya[f] && delete d.ya[f]
                        };
                        this.l = c;
                        var e = Hf(c, this, "i");
                        this.$ = pd(c);
                        this.options = b;
                        this.start = e.H(this.start, "st");
                        this.stop = e.H(this.stop, "sp");
                        this.Z = e.H(this.Z, "i");
                        this.pe = e.H(this.pe, "o");
                        this.Cc = e.H(this.Cc, "a");
                        this.removeNode = e.H(this.removeNode, "r");
                        this.aa = e.H(this.aa, "s");
                        this.hd = e.H(this.hd, "g")
                    }
                    a.prototype.pe = function(c, b) {
                        var d = this.kb(c);
                        Va(d) || (this.Mb[d] && this.Z(c), this.Mb[d] = b)
                    };
                    a.prototype.F = function(c, b, d) {
                        c = "" + b + c;
                        this.fb.push(c);
                        this.Gd(c) ||
                            this.fb.push(c);
                        this.$.F([c], d)
                    };
                    a.prototype.ga = function(c, b, d) {
                        var e = "" + b + c;
                        this.fb = fa(function(f) {
                            return f !== e
                        }, this.fb);
                        this.$.ga([e], d)
                    };
                    a.prototype.start = function() {
                        this.Jf();
                        this.Hf()
                    };
                    a.prototype.stop = function() {
                        this.flush();
                        ha(this.l, this.Me);
                        ha(this.l, this.Pf);
                        this.uc = [];
                        this.Hb = [];
                        this.ya = {};
                        this.Mb = {}
                    };
                    a.prototype.Cc = function(c) {
                        var b = this,
                            d = [],
                            e = 0,
                            f = {
                                Vc: c.Vc,
                                result: [],
                                Dc: 0,
                                nodes: d
                            };
                        this.uc.push(f);
                        y(function(g) {
                            Ti(b.l, g, function(h) {
                                var k = b.kb(h);
                                Va(k) || (d.push(h), b.ya[k] && b.Z(h), b.ya[k] = {
                                    node: h,
                                    event: f,
                                    Ti: e
                                }, e += 1)
                            })
                        }, c.nodes)
                    };
                    a.prototype.Z = function(c) {
                        if (c === this.l) return 0;
                        var b = this.kb(c),
                            d = this.ya[b],
                            e = this.kh(b),
                            f = e.We,
                            g = e.vd,
                            h = e.Xe,
                            k = e.gh,
                            l = e.hh;
                        if (d) {
                            e = d.event;
                            d = d.Ti;
                            var m = Is(this.l) === c;
                            k = k || c.nextSibling;
                            var p = l || c.previousSibling;
                            l = !m && k ? this.kb(k) : null;
                            p = !m && p ? this.kb(p) : null;
                            m = this.l;
                            k = this.options;
                            f = this.kb(f || c.parentNode || c.parentElement) || 0;
                            var r = g,
                                q = void 0;
                            void 0 === p && (p = null);
                            void 0 === l && (l = null);
                            void 0 === r && (r = {});
                            void 0 === q && (q = Na(c));
                            if (W(q)) c = void 0;
                            else {
                                g = {
                                    id: b,
                                    prev: p !== f ? p : null,
                                    next: l !== f ? l : null,
                                    parent: f,
                                    name: q.toLowerCase(),
                                    node: c
                                };
                                if (Nf(c)) {
                                    if (h = Rn(c, h), g.attributes = {}, g.content = h)
                                        if (c = qd(m, c)) g.content = "" !== db(h) ? io(m, h) : h, g.hidden = c
                                } else h = Sn(m, c, k, r, q), m = h.pb, g.attributes = h.zg, m && (g.hidden = m), c.namespaceURI && cb(c.namespaceURI, "svg") && (g.namespace = c.namespaceURI);
                                c = g
                            }
                            if (W(c)) return;
                            this.ya[b] = null;
                            this.Hb.push(b);
                            e.result[d] = c;
                            e.Dc += 1;
                            e.nodes.length === e.Dc && e.Vc(e.result)
                        }
                        return b
                    };
                    a.prototype.flush = function() {
                        this.aa(!0)
                    };
                    a.prototype.hd = function() {
                        if (this.Hb.length) {
                            var c =
                                cc(this.Hb, this.Ai),
                                b = rg(this.l, 30);
                            c(b)
                        }
                    };
                    a.prototype.aa = function(c) {
                        var b = this;
                        if (hh(this.l)) {
                            var d = ea(this.ya);
                            d = J(function(e, f) {
                                b.ya[f] && e.push(b.ya[f].node);
                                return e
                            }, [], d);
                            d = cc(d, this.Z);
                            c = c ? Sj(E) : Qj(this.l, 20);
                            d(c);
                            this.uc = fa(function(e) {
                                return e.Dc !== e.result.length
                            }, this.uc)
                        }
                    };
                    a.prototype.kh = function(c) {
                        if (Va(c)) return {};
                        var b = this.Mb[c];
                        return b ? (this.Mb[c] = null, this.Hb.push(c), b) : {}
                    };
                    return a
                }(),
                ku = ["input", "change", "keyup", "paste", "cut"],
                lu = function(a) {
                    function c(b, d, e) {
                        b = a.call(this,
                            b, d, e) || this;
                        b.inputs = {};
                        b.qd = !1;
                        b.Kc = b.L.H(b.Kc, "ii");
                        b.Lc = b.L.H(b.Lc, "ir");
                        b.Qc = b.L.H(b.Qc, "ri");
                        b.Zc = b.L.H(b.Zc, "ur");
                        b.Fd = b.L.H(b.Fd, "ce");
                        b.Bc = b.L.H(b.Bc, "vc");
                        return b
                    }
                    Oa(c, a);
                    c.prototype.start = function() {
                        var b = this,
                            d = this.G.sa();
                        this.qd = this.Gg();
                        y(function(e) {
                            e = e.toLowerCase();
                            d.F(e, "NA:", H(b.Kc, b));
                            d.F(e, "NR:", H(b.Lc, b))
                        }, Mf);
                        this.Ob = [this.eb.F(this.l.document, ku, H(this.Fd, this)), function() {
                            y(function(e) {
                                e = e.toLowerCase();
                                d.ga(e, "NA:", b.Kc);
                                d.ga(e, "NR:", b.Lc)
                            }, Mf);
                            y(b.Zc, ea(b.inputs))
                        }]
                    };
                    c.prototype.Zc = function(b) {
                        var d = this.inputs[b];
                        if (d) {
                            if (this.qd) {
                                var e = d.ui;
                                d = d.element;
                                e && this.l.Object.defineProperty(d, this.zc(d), e)
                            }
                            delete this.inputs[b]
                        }
                    };
                    c.prototype.Lc = function(b) {
                        b && this.Zc(b.data.id)
                    };
                    c.prototype.Kc = function(b) {
                        b && (b = b.data, this.Qc(b.node, b.id))
                    };
                    c.prototype.zc = function(b) {
                        return Pe(b) ? "checked" : "value"
                    };
                    c.prototype.Fd = function(b) {
                        if (b = b.target) {
                            var d = this.zc(b);
                            this.Bc(b[d], b)
                        }
                    };
                    c.prototype.Bc = function(b, d) {
                        var e = this.Z(d),
                            f = this.inputs[e];
                        if (!f && (f = this.Qc(f, e), !f)) return;
                        e = f.Ig;
                        var g = f.value,
                            h = this.zc(d),
                            k = !b || K(typeof b, ["string", "boolean", "number"]),
                            l = this.G.Ib().Ld;
                        k && b !== g && (g = re(this.l, d, h, b, this.G.Ib()).value, e ? this.G.Y("event", {
                            target: this.Z(d),
                            checked: !!b
                        }, "change") : (e = Qc(this.l, d, l), l = e.hb, this.G.Y("event", {
                            value: g,
                            hidden: e.qb && !l,
                            target: this.Z(d)
                        }, "change")), f.value = b)
                    };
                    c.prototype.Qc = function(b, d) {
                        var e = this;
                        if (!Ff(b) || "__ym_input_override_test" === b.getAttribute("class") || this.inputs[d]) return null;
                        var f = Pe(b),
                            g = this.zc(b),
                            h = {
                                element: b,
                                Ig: f,
                                value: b[g]
                            };
                        this.inputs[d] = h;
                        this.qd && Sb(this.l, function() {
                            var k = e.l.Object.getOwnPropertyDescriptor(Object.getPrototypeOf(b), g) || {},
                                l = e.l.Object.getOwnPropertyDescriptor(b, g) || {},
                                m = z({}, k, l);
                            if (Ia("((set)?(\\s?" + g + ")?)?", m.set)) {
                                try {
                                    e.l.Object.defineProperty(b, g, z({}, m, {
                                        configurable: !0,
                                        set: function(p) {
                                            e.Bc(p, this);
                                            return m.set.call(this, p)
                                        }
                                    }))
                                } catch (p) {}
                                h.ui = m
                            }
                        });
                        return h
                    };
                    c.prototype.Gg = function() {
                        var b = !0,
                            d = eb(this.l)("input");
                        try {
                            d = eb(this.l)("input");
                            d.value = "INPUT_VALUE";
                            d.style.setProperty("display", "none",
                                "important");
                            d.setAttribute("type", "text");
                            d.setAttribute("class", "__ym_input_override_test");
                            var e = this.l.Object.getOwnPropertyDescriptor(Object.getPrototypeOf(d), "value") || {},
                                f = this.l.Object.getOwnPropertyDescriptor(d, "value") || {},
                                g = z({}, e, f);
                            this.l.Object.defineProperty(d, "value", z({}, g, {
                                configurable: !0,
                                set: function(h) {
                                    return g.set.call(d, h)
                                }
                            }));
                            "INPUT_VALUE" !== d.value && (b = !1);
                            d.value = "INPUT_TEST";
                            "INPUT_TEST" !== d.value && (b = !1)
                        } catch (h) {
                            b = !1
                        }
                        return b
                    };
                    return c
                }(ab),
                mu = function(a) {
                    function c(b,
                        d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.Xa = {
                            width: 0,
                            height: 0,
                            pageHeight: 0,
                            pageWidth: 0,
                            orientation: 0
                        };
                        b.ia.push([
                            ["resize"], b.ri
                        ]);
                        b.ia.push([
                            ["orientationchange"], b.ni
                        ]);
                        return b
                    }
                    Oa(c, a);
                    c.prototype.start = function() {
                        a.prototype.start.call(this);
                        this.Mf()
                    };
                    c.prototype.ri = function() {
                        var b = this.Dd();
                        this.Hh(b) && (this.Xa = b, this.Nf(b))
                    };
                    c.prototype.ni = function() {
                        var b = this.Dd();
                        this.Xa.orientation !== b.orientation && (this.Xa = b, this.Di(b))
                    };
                    c.prototype.pf = function(b) {
                        return !b.height || !b.width || !b.pageWidth || !b.pageHeight
                    };
                    c.prototype.Hh = function(b) {
                        return b.height !== this.Xa.height || b.width !== this.Xa.width
                    };
                    c.prototype.Dd = function() {
                        var b = this.G.jb(),
                            d = Kc(this.l),
                            e = d[0];
                        d = d[1];
                        b = b.Cd();
                        return {
                            width: e,
                            height: d,
                            pageWidth: b ? b.scrollWidth : 0,
                            pageHeight: b ? b.scrollHeight : 0,
                            orientation: this.G.jb().th()
                        }
                    };
                    c.prototype.Di = function(b) {
                        var d;
                        void 0 === d && (d = this.G.stamp());
                        this.G.Y("event", {
                            width: b.width,
                            height: b.height,
                            orientation: b.orientation
                        }, "deviceRotation", d)
                    };
                    c.prototype.Nf = function(b, d) {
                        void 0 === d && (d = this.G.stamp());
                        this.G.Y("event", {
                            width: b.width,
                            height: b.height,
                            pageWidth: b.pageWidth,
                            pageHeight: b.pageHeight
                        }, "resize", d)
                    };
                    c.prototype.Mf = function() {
                        var b = this.Dd();
                        this.pf(b) ? O(this.l, H(this.Mf, this), 300) : (this.pf(this.Xa) && (this.Xa = b), this.Nf(b, 0))
                    };
                    return c
                }(ab),
                bf = function() {
                    function a(c) {
                        this.index = 0;
                        this.wb = {};
                        this.l = c
                    }
                    a.prototype.pc = function(c, b, d) {
                        void 0 === d && (d = {});
                        var e = ia(this.l),
                            f = this.index;
                        this.index += 1;
                        this.wb[f] = {
                            Ka: 0,
                            Ub: !1,
                            eh: c,
                            dd: [],
                            Pd: e(Y)
                        };
                        var g = this;
                        return function() {
                            var h = Ja(arguments),
                                k = d.gb && !g.wb[f].Ub,
                                l = g.wb[f];
                            ha(g.l, l.Ka);
                            l.dd = h;
                            l.Ub = !0;
                            var m = e(Y);
                            if (k || m - l.Pd >= b) c.apply(void 0, h), l.Pd = m;
                            l.Ka = O(g.l, function() {
                                k || (c.apply(void 0, h), l.Pd = e(Y));
                                l.Ub = !1;
                                l.dd = []
                            }, b, "th")
                        }
                    };
                    a.prototype.flush = function() {
                        var c = this;
                        y(function(b) {
                            var d = c.wb[b],
                                e = d.Ka,
                                f = d.eh,
                                g = d.dd;
                            d.Ub && (c.wb[b].Ub = !1, f.apply(void 0, g), ha(c.l, e))
                        }, ea(this.wb))
                    };
                    return a
                }(),
                nu = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.ag = [];
                        d.Ge = {
                            x: 0,
                            y: 0
                        };
                        d.Ca = new bf(b);
                        d.Oc = d.L.H(d.Oc, "o");
                        d.ia.push([
                            ["scroll"], d.ti
                        ]);
                        return d
                    }
                    Oa(c, a);
                    c.prototype.start = function() {
                        a.prototype.start.call(this);
                        this.G.Y("event", {
                            x: Math.max(this.l.scrollX, 0),
                            y: Math.max(this.l.scrollY, 0),
                            page: !0,
                            target: -1
                        }, "scroll", 0)
                    };
                    c.prototype.stop = function() {
                        a.prototype.stop.call(this);
                        this.Ca.flush()
                    };
                    c.prototype.ti = function(b) {
                        if (this.G.jb().kf()) this.Oc(b);
                        else {
                            var d = b.target,
                                e = fa(function(f) {
                                    return f[0] === d
                                }, this.ag).pop();
                            e ? e = e[1] : (e = this.Ca.pc(H(this.Oc, this), 100, {
                                gb: !0
                            }), this.ag.push([d, e]));
                            e(b)
                        }
                    };
                    c.prototype.Oc = function(b) {
                        var d = this.G.jb().Cd();
                        b = b.target;
                        var e = this.Jb(b);
                        d = d === b || this.l === b || this.l.document === b;
                        var f = Math.max(e.left, 0);
                        e = Math.max(e.top, 0);
                        if (d) {
                            if (this.Ge.x === f && this.Ge.y === e) return;
                            this.Ge = {
                                x: f,
                                y: e
                            }
                        }
                        this.G.Y("event", {
                            x: f,
                            y: e,
                            page: d,
                            target: d ? -1 : this.Z(b)
                        }, "scroll")
                    };
                    c.prototype.Jb = function(b) {
                        var d = {
                            left: 0,
                            top: 0
                        };
                        if (!b) return d;
                        if (b.window === b) return {
                            top: b.scrollY || 0,
                            left: b.scrollX || 0
                        };
                        var e = b.ownerDocument || b,
                            f = b.documentElement,
                            g = e.defaultView || e.parentWindow,
                            h = e.body;
                        return b !== e || (b = this.G.jb().Cd(), b) ? K(b, [f, h]) ? {
                            top: b.scrollTop ||
                                g.scrollY,
                            left: b.scrollLeft || g.scrollX
                        } : {
                            top: b.scrollTop || 0,
                            left: b.scrollLeft || 0
                        } : d
                    };
                    return c
                }(ab),
                ou = ["mousemove", "mousedown", "mouseup", "click"],
                pu = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.ia.push([ou, d.mi]);
                        d.Ca = new bf(b);
                        d.Jc = d.L.H(d.Jc, "n");
                        d.Ni = d.L.H(d.Ca.pc(H(d.Jc, d), 100), "t");
                        return d
                    }
                    Oa(c, a);
                    c.prototype.stop = function() {
                        a.prototype.stop.call(this);
                        this.Ca.flush()
                    };
                    c.prototype.mi = function(b) {
                        var d = null;
                        try {
                            d = b.type
                        } catch (e) {
                            return
                        }
                        "mousemove" === d ? this.Ni(b) : this.Jc(b)
                    };
                    c.prototype.Jc =
                        function(b) {
                            var d = b.type,
                                e = b.clientX;
                            e = void 0 === e ? null : e;
                            var f = b.clientY;
                            f = void 0 === f ? null : f;
                            b = b.target || this.l.document.elementFromPoint(e, f);
                            this.G.Y("event", {
                                x: e || 0,
                                y: f || 0,
                                target: this.Z(b)
                            }, d)
                        };
                    return c
                }(ab),
                qu = ["focus", "blur"],
                ru = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.ia.push([qu, b.fh]);
                        return b
                    }
                    Oa(c, a);
                    c.prototype.fh = function(b) {
                        var d = b.target;
                        b = b.type;
                        this.G.Y("event", {
                            target: this.Z(d === this.l ? this.l.document.documentElement : d)
                        }, b)
                    };
                    return c
                }(ab),
                su = w(function(a) {
                    var c = na(a.getSelection,
                        "getSelection");
                    return c ? H(c, a) : E
                }),
                tu = v(su, ja),
                uu = ["mousemove", "touchmove", "mousedown", "touchdown", "select"],
                vu = /text|search|password|tel|url/,
                wu = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.Hd = !1;
                        b.ia.push([uu, b.Fh]);
                        return b
                    }
                    Oa(c, a);
                    c.prototype.Fh = function(b) {
                        var d = this.G,
                            e = b.type,
                            f = b.which;
                        b = b.target;
                        if ("mousemove" !== e || 1 === f)(e = "select" === e ? this.yh(b) : this.vh()) && e.start !== e.end ? (this.Hd = !0, d.Y("event", e, "selection")) : this.Hd && (this.Hd = !1, d.Y("event", {
                            start: 0,
                            end: 0
                        }, "selection"))
                    };
                    c.prototype.vh = function() {
                        var b = tu(this.l);
                        if (b && 0 < b.rangeCount) {
                            b = b.getRangeAt(0) || this.l.document.createRange();
                            var d = this.Z(b.startContainer),
                                e = this.Z(b.endContainer);
                            if (!W(d) && !W(e)) return {
                                start: b.startOffset,
                                end: b.endOffset,
                                startNode: d,
                                endNode: e
                            }
                        }
                    };
                    c.prototype.yh = function(b) {
                        if (vu.test(b.type || "")) {
                            var d = this.Z(b);
                            if (!W(d)) return {
                                start: b.selectionStart,
                                end: b.selectionEnd,
                                target: d
                            }
                        }
                    };
                    return c
                }(ab),
                xu = {
                    focus: "windowfocus",
                    blur: "windowblur"
                },
                yu = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) ||
                            this;
                        b.visibility = null;
                        W(b.l.document.hidden) ? W(b.l.document.msHidden) ? W(b.l.document.webkitHidden) || (b.visibility = {
                            hidden: "webkitHidden",
                            event: "webkitvisibilitychange"
                        }) : b.visibility = {
                            hidden: "msHidden",
                            event: "msvisibilitychange"
                        } : b.visibility = {
                            hidden: "hidden",
                            event: "visibilitychange"
                        };
                        b.handleEvent = b.L.H(b.handleEvent, "e");
                        return b
                    }
                    Oa(c, a);
                    c.prototype.start = function() {
                        this.Ob = [this.eb.F(this.l, this.visibility ? [this.visibility.event] : ["focus", "blur"], H(this.handleEvent, this))]
                    };
                    c.prototype.handleEvent =
                        function(b) {
                            this.G.Y("event", {}, xu[this.visibility ? this.l.document[this.visibility.hidden] ? "blur" : "focus" : b.type])
                        };
                    return c
                }(ab),
                zu = ["touchmove", "touchstart", "touchend", "touchcancel", "touchforcechange"],
                Au = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.Xc = {};
                        d.scrolling = !1;
                        d.Kf = 0;
                        d.ia.push([
                            ["scroll"], d.Ci, d.l.document
                        ]);
                        d.ia.push([zu, d.Pi, d.l.document]);
                        d.Ca = new bf(b);
                        d.Nb = d.L.H(d.Nb, "nh");
                        d.Oi = d.L.H(d.Ca.pc(d.Nb, d.G.jb().kf() ? 0 : 50, {
                            gb: !0
                        }), "th");
                        return d
                    }
                    Oa(c, a);
                    c.prototype.Ci = function() {
                        var b =
                            this;
                        this.scrolling = !0;
                        ha(this.l, this.Kf);
                        this.Kf = O(this.l, function() {
                            b.scrolling = !1
                        }, 150)
                    };
                    c.prototype.Pi = function(b) {
                        var d = this,
                            e = "touchcancel" === b.type || "touchend" === b.type;
                        b.changedTouches && 0 < b.changedTouches.length && y(function(f) {
                            var g = d.Ah(f);
                            f.__ym_touch_id = g;
                            e && delete d.Xc[f.identifier]
                        }, Ba(b.changedTouches));
                        "touchmove" === b.type ? this.scrolling ? this.Nb(b) : this.Oi(b, this.G.stamp()) : this.Nb(b)
                    };
                    c.prototype.Ah = function(b) {
                        this.Xc[b.identifier] || (this.Xc[b.identifier] = Th());
                        return this.Xc[b.identifier]
                    };
                    c.prototype.Nb = function(b, d) {
                        void 0 === d && (d = this.G.stamp());
                        var e = b.type,
                            f = B(function(g) {
                                return {
                                    id: g.__ym_touch_id,
                                    x: Math.round(g.clientX),
                                    y: Math.round(g.clientY),
                                    force: g.force
                                }
                            }, Ba(b.changedTouches));
                        0 < f.length && this.G.Y("event", {
                            touches: f,
                            target: this.Z(b.target)
                        }, e, d)
                    };
                    return c
                }(ab),
                Bu = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.ia.push([
                            ["load"], b.li, b.l.document
                        ]);
                        return b
                    }
                    Oa(c, a);
                    c.prototype.li = function(b) {
                        b = b.target;
                        "IMG" === Na(b) && b.getAttribute("srcset") && this.G.Y("mutation", {
                            target: this.Z(b),
                            attributes: {
                                src: b.currentSrc
                            }
                        }, "ac")
                    };
                    return c
                }(ab),
                Cu = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.lg = 1;
                        d.Ca = new bf(b);
                        d.fc = d.L.H(d.fc, "z");
                        return d
                    }
                    Oa(c, a);
                    c.prototype.start = function() {
                        if (this.gf()) {
                            a.prototype.start.call(this);
                            this.fc();
                            var b = this.eb.F(n(this.l, "visualViewport"), ["resize"], this.Ca.pc(this.fc, 10));
                            this.Ob.push(b)
                        }
                    };
                    c.prototype.stop = function() {
                        a.prototype.stop.call(this);
                        this.Ca.flush()
                    };
                    c.prototype.fc = function() {
                        var b = this.gf();
                        b && b !== this.lg && (this.lg =
                            b, this.Ei(b))
                    };
                    c.prototype.gf = function() {
                        var b = je(this.l);
                        return b ? b[2] : null
                    };
                    c.prototype.Ei = function(b) {
                        var d = Xf(this.l);
                        this.G.Y("event", {
                            x: d.x,
                            y: d.y,
                            level: b
                        }, "zoom")
                    };
                    return c
                }(ab),
                ce, cf = {
                    91: "super",
                    93: "super",
                    224: "super",
                    18: "alt",
                    17: "ctrl",
                    16: "shift",
                    9: "tab",
                    8: "backspace",
                    46: "delete"
                },
                Ll = {
                    "super": 1,
                    nj: 2,
                    alt: 3,
                    shift: 4,
                    Ij: 5,
                    "delete": 6,
                    lj: 6
                },
                Du = [4, 9, 8, 32, 37, 38, 39, 40, 46],
                Ml = (ce = {}, ce["1"] = {
                        91: "&#8984;",
                        93: "&#8984;",
                        224: "&#8984;",
                        18: "&#8997;",
                        17: "&#8963;",
                        16: "&#8679;",
                        9: "&#8677;",
                        8: "&#9003;",
                        46: "&#9003;"
                    },
                    ce["2"] = {
                        91: "&#xff;",
                        93: "&#xff;",
                        224: "&#xff;",
                        18: "Alt",
                        17: "Ctrl",
                        16: "Shift",
                        9: "Tab",
                        8: "Backspace",
                        46: "Delete"
                    }, ce.Zh = {
                        32: "SPACEBAR",
                        37: "&larr;",
                        38: "&uarr;",
                        39: "&rarr;",
                        40: "&darr;",
                        13: "Enter"
                    }, ce),
                Eu = /flash/,
                Fu = /ym-disable-keys/,
                Gu = /^&#/,
                Hu = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.mb = {};
                        d.Oa = 0;
                        d.Fa = [];
                        d.Zf = [];
                        d.rc = 0;
                        d.Df = 0;
                        d.ia.push([
                            ["keydown"], d.Ch
                        ]);
                        d.ia.push([
                            ["keyup"], d.Dh
                        ]);
                        d.vg = -1 !== Ac(n(b, "navigator.appVersion") || "", "Mac") ? "1" : "2";
                        d.Hc = d.L.H(d.Hc, "v");
                        d.sd = d.L.H(d.sd, "ec");
                        d.Uc = d.L.H(d.Uc, "sk");
                        d.Ad = d.L.H(d.Ad, "gk");
                        d.se = d.L.H(d.se, "sc");
                        d.ec = d.L.H(d.ec, "cc");
                        d.reset = d.L.H(d.reset, "r");
                        d.Rc = d.L.H(d.Rc, "rs");
                        return d
                    }
                    Oa(c, a);
                    c.prototype.Ch = function(b) {
                        if (this.Hc(b) && !this.Rh(b)) {
                            var d = b.keyCode;
                            b.repeat || this.mb[d] || (this.mb[b.keyCode] = !0, cf[b.keyCode] && !this.Oa ? (this.Oa += 1, this.se(b), this.reset(300)) : this.Oa ? (this.Dg(), this.ie(b), this.sd()) : (this.reset(), this.ie(b)))
                        }
                    };
                    c.prototype.Dh = function(b) {
                        if (this.Hc(b)) {
                            var d = b.keyCode,
                                e = cf[b.keyCode];
                            this.mb[b.keyCode] && (this.mb[d] = !1);
                            e && this.Oa && (this.Oa = 0, this.mb = {});
                            1 === this.Fa.length && (b = this.Fa[0], K(b.keyCode, Du) && (this.Uc([b], !0), this.reset()));
                            this.Fa = fa(v(Q("keyCode"), Aa(d), Dc), this.Fa);
                            ha(this.l, this.rc)
                        }
                    };
                    c.prototype.Hc = function(b) {
                        var d = this.l.document.activeElement;
                        d = d && "OBJECT" === d.nodeName && Eu.test(d.getAttribute("type") || "");
                        b = b.target;
                        if (!b) return !d;
                        b = "INPUT" === b.nodeName && "password" === b.getAttribute("type") && Fu.test(b.className);
                        return !d && !b
                    };
                    c.prototype.sd = function() {
                        this.Zf = this.Fa.slice(0);
                        ha(this.l, this.rc);
                        this.rc = O(this.l, u(this.Zf, H(this.Uc, this)), 0, "e.c")
                    };
                    c.prototype.Uc = function(b, d) {
                        void 0 === d && (d = !1);
                        if (1 < b.length || d) {
                            var e = this.Ad(b);
                            this.G.Y("event", {
                                keystrokes: e
                            }, "keystroke")
                        }
                    };
                    c.prototype.Ad = function(b) {
                        var d = this;
                        b = B(function(e) {
                            e = e.keyCode;
                            var f = cf[e],
                                g = d.sh(e);
                            return {
                                id: e,
                                key: g,
                                isMeta: !!f && Gu.test(g),
                                modifier: f
                            }
                        }, b);
                        return zg(function(e, f) {
                            return (Ll[e.modifier] || 100) - (Ll[f.modifier] || 100)
                        }, b)
                    };
                    c.prototype.sh = function(b) {
                        return Ml[this.vg][b] || Ml.Zh[b] || String.fromCharCode(b)
                    };
                    c.prototype.ie =
                        function(b) {
                            K(b, this.Fa) || this.Fa.push(b)
                        };
                    c.prototype.se = function(b) {
                        this.ie(b);
                        this.ec()
                    };
                    c.prototype.ec = function() {
                        this.Oa ? O(this.l, this.ec, 100) : this.Fa = []
                    };
                    c.prototype.Dg = function() {
                        ha(this.l, this.Df)
                    };
                    c.prototype.reset = function(b) {
                        b ? this.Df = O(this.l, H(this.Rc, this), b) : this.Rc()
                    };
                    c.prototype.Rc = function() {
                        this.Oa = 0;
                        this.Fa = [];
                        this.mb = {};
                        ha(this.l, this.rc)
                    };
                    c.prototype.Rh = function(b) {
                        return b.target && "INPUT" === b.target.nodeName ? b.shiftKey || 32 === b.keyCode || "shift" === cf[b.keyCode] : !1
                    };
                    return c
                }(ab),
                Qn = ["sr", "sd", "\u043d"],
                Iu = /allow-same-origin/,
                Ju = function(a) {
                    function c(b, d, e) {
                        d = a.call(this, b, d, e) || this;
                        d.Xb = [];
                        d.wd = {};
                        d.Wd = d.L.H(d.Wd, "fi");
                        d.Xd = d.L.H(d.Xd, "sd");
                        d.Yd = d.L.H(d.Yd, "src");
                        d.za = new b.MutationObserver(d.Yd);
                        return d
                    }
                    Oa(c, a);
                    c.prototype.start = function() {
                        a.prototype.start.call(this);
                        this.G.Ib().ic && this.G.sa().F("iframe", "NA:", H(this.Wd, this));
                        this.G.cf().yd().F(["sdr"], H(this.Xd, this))
                    };
                    c.prototype.stop = function() {
                        a.prototype.stop.call(this);
                        y(function(b) {
                            b.G.stop()
                        }, this.Xb)
                    };
                    c.prototype.Yd =
                        function(b) {
                            var d = b.pop().target;
                            if (b = qb(function(f) {
                                    return f.jf === d
                                }, this.Xb)) {
                                this.Xb = fa(function(f) {
                                    return f.jf !== d
                                }, this.Xb);
                                var e = b.G.zd();
                                try {
                                    b.G.stop()
                                } catch (f) {}
                                this.oc(d, e)
                            }
                        };
                    c.prototype.Wd = function(b) {
                        if (b) {
                            var d = b.data.node;
                            this.za.observe(d, {
                                attributes: !0,
                                attributeFilter: ["src"]
                            });
                            this.oc(d, b.data.id)
                        }
                    };
                    c.prototype.oc = function(b, d) {
                        var e = this;
                        this.Ph(b) && Cb(this.l, b)(Qa(E, function() {
                            var f = e.G.oc(b.contentWindow, d);
                            e.Xb.push({
                                G: f,
                                jf: b
                            })
                        }))
                    };
                    c.prototype.Xd = function(b) {
                        var d = this,
                            e = b.frameId;
                        b = b.data;
                        this.wd[e] || (this.wd[e] = {
                            data: []
                        });
                        var f = this.wd[e];
                        f.data = f.data.concat(b);
                        this.l.isNaN(f.pd) && y(function(g) {
                            "page" === g.type && (f.pd = g.data.recordStamp - d.G.df())
                        }, f.data);
                        this.l.isNaN(f.pd) || (this.G.aa(B(function(g) {
                            g.stamp += f.pd;
                            g.stamp = d.l.Math.max(0, g.stamp);
                            return g
                        }, f.data)), f.data = [])
                    };
                    c.prototype.Ph = function(b) {
                        var d = b.getAttribute("src"),
                            e = b.getAttribute("sandbox");
                        return b.getAttribute("_ym_ignore") || e && !e.match(Iu) || d && "about:blank" !== d && (d = Pc(this.l, d).host) && R(this.l).host !==
                            d ? !1 : n(b, "contentWindow.location.href")
                    };
                    return c
                }(ab),
                Ku = w(function(a) {
                    var c = n(a, "sessionStorage");
                    if (!c) return null;
                    try {
                        var b = c.getItem("__ym_tab_guid");
                        c = !1;
                        var d = n(a, "opener.sessionStorage");
                        try {
                            c = !!d && b === d.getItem("__ym_tab_guid")
                        } catch (e) {
                            c = !0
                        }
                        if (!b || c) b = Th(), a.sessionStorage.setItem("__ym_tab_guid", b);
                        return b
                    } catch (e) {
                        return null
                    }
                }),
                Lu = function(a) {
                    function c(b, d, e) {
                        b = a.call(this, b, d, e) || this;
                        b.me = b.L.H(b.me, "ps");
                        return b
                    }
                    Oa(c, a);
                    c.prototype.start = function() {
                        this.G.sa().Cc({
                            nodes: [this.l.document.documentElement],
                            Vc: this.me
                        })
                    };
                    c.prototype.me = function(b) {
                        var d = this.G.uh(),
                            e = d.lh(),
                            f = R(this.l),
                            g = f.host,
                            h = f.protocol;
                        f = f.pathname;
                        var k = Kc(this.l),
                            l = k[0];
                        k = k[1];
                        this.G.Y("page", {
                            content: B(function(m) {
                                m.node = void 0;
                                return m
                            }, b),
                            base: e || "",
                            hasBase: !!e,
                            viewport: {
                                width: l,
                                height: k
                            },
                            title: this.l.document.title,
                            doctype: d.nh() || "",
                            address: this.l.location.href,
                            ua: this.l.navigator.userAgent,
                            referrer: this.l.document.referrer,
                            screen: {
                                width: this.l.screen.width,
                                height: this.l.screen.height
                            },
                            location: {
                                host: g,
                                protocol: h,
                                path: f
                            },
                            recordStamp: this.G.df(),
                            tabId: Ku(this.l)
                        }, "page", 0)
                    };
                    return c
                }(ab),
                Mu = ["addRule", "removeRule", "insertRule", "deleteRule"],
                ih = [
                    [function(a) {
                        function c(b, d, e) {
                            b = a.call(this, b, d, e) || this;
                            b.ab = {};
                            b.Yb = {};
                            b.Le = 0;
                            b.Mc = b.L.H(b.Mc, "a");
                            b.vb = b.L.H(b.vb, "sr");
                            b.Nc = b.L.H(b.Nc, "r");
                            b.aa = b.L.H(b.aa, "d");
                            return b
                        }
                        Oa(c, a);
                        c.prototype.start = function() {
                            var b = this.G.sa();
                            b.F("style", "NA:", this.Mc);
                            b.F("style", "NR:", this.Nc);
                            this.aa()
                        };
                        c.prototype.stop = function() {
                            var b = this;
                            a.prototype.stop.call(this);
                            var d = this.G.sa();
                            d.ga("style", "NA:", this.Mc);
                            d.ga("style", "NR:", this.Nc);
                            this.aa();
                            ha(this.l, this.Le);
                            y(function(e) {
                                b.ab[e].sheet && b.Gf(b.ab[e].sheet)
                            }, ea(this.ab));
                            this.ab = {}
                        };
                        c.prototype.aa = function() {
                            var b = this;
                            y(function(d) {
                                var e = d[0];
                                d = d[1];
                                if (d.length) {
                                    for (var f = [], g = d[0].stamp, h = [], k = 0; k < d.length; k += 1) {
                                        var l = d[k],
                                            m = l.stamp;
                                        delete l.stamp;
                                        m <= g + 50 ? f.push(l) : (h.push(f), g = m, f = [l])
                                    }
                                    f.length && h.push(f);
                                    h.length && y(function(p) {
                                        b.G.Y("event", {
                                            target: Ga(e),
                                            changes: p
                                        }, "stylechange", g)
                                    }, h);
                                    delete b.Yb[e]
                                }
                            }, Ma(this.Yb));
                            this.Le = O(this.l, this.aa, 100)
                        };
                        c.prototype.vb = function(b, d, e, f, g) {
                            void 0 === f && (f = "");
                            void 0 === g && (g = -1);
                            this.Yb[b] || (this.Yb[b] = []);
                            this.Yb[b].push({
                                op: d,
                                style: f,
                                index: g,
                                stamp: e
                            })
                        };
                        c.prototype.vi = function(b, d) {
                            var e = this,
                                f = b.addRule,
                                g = b.removeRule,
                                h = b.insertRule,
                                k = b.deleteRule;
                            T(f) && (b.addRule = function(l, m, p) {
                                e.vb(d, "a", e.G.stamp(), l + "{" + m + "}", p);
                                return f.call(b, l, m, p)
                            });
                            T(g) && (b.removeRule = function(l) {
                                e.vb(d, "r", e.G.stamp(), "", l);
                                return g.call(b, l)
                            });
                            T(h) && (b.insertRule = function(l, m) {
                                e.vb(d, "a",
                                    e.G.stamp(), l, m);
                                return h.call(b, l, m)
                            });
                            T(k) && (b.deleteRule = function(l) {
                                e.vb(d, "r", e.G.stamp(), "", l);
                                return k.call(b, l)
                            })
                        };
                        c.prototype.Gf = function(b) {
                            var d = this;
                            y(function(e) {
                                var f = d.l.CSSStyleSheet.prototype[e];
                                T(f) && (b[e] = H(f, b))
                            }, Mu)
                        };
                        c.prototype.Yg = function(b) {
                            try {
                                return b.cssRules || b.rules
                            } catch (d) {
                                return null
                            }
                        };
                        c.prototype.Mc = function(b) {
                            var d = b.data;
                            b = d.id;
                            d = d.node;
                            if (d.sheet && !d.getAttribute("src") && !d.innerText) {
                                var e = d.sheet,
                                    f = this.Yg(e);
                                if (f && f.length) {
                                    for (var g = [], h = 0; h < f.length; h += 1) g.push({
                                        style: f[h].cssText,
                                        index: h,
                                        op: "a"
                                    });
                                    this.G.Y("event", {
                                        changes: g,
                                        target: b
                                    }, "stylechange")
                                }
                                this.vi(e, b);
                                this.ab[b] = d
                            }
                        };
                        c.prototype.Nc = function(b) {
                            b = b.data.id;
                            var d = this.ab[b];
                            d && (delete this.ab[b], d.sheet && this.Gf(d.sheet))
                        };
                        return c
                    }(ab), "ss"],
                    [lu, "in"],
                    [iu, "mu"],
                    [mu, "r"],
                    [nu, "sc"],
                    [pu, "mo"],
                    [ru, "f"],
                    [wu, "se"],
                    [yu, "wf"],
                    [Au, "t"],
                    [Bu, "src"],
                    [Cu, "z"],
                    [Hu, "ks"]
                ];
            ih.push([Ju, "if"]);
            ih.push([Lu, "pa"]);
            var Nu = w(function(a) {
                    var c = a.document;
                    return {
                        Cd: function() {
                            if (c.scrollingElement) return c.scrollingElement;
                            var b = 0 === ib(c.compatMode,
                                "CSS1") ? c.documentElement : c.body;
                            return n(c, "documentElement.scrollHeight") >= n(c, "body.scrollHeight") ? b : null
                        },
                        th: function() {
                            var b = a.screen;
                            if (!b) return 0;
                            var d = qb(u(b, n), ["orientation", "mozOrientation", "msOrientation"]);
                            return n(b, d + ".angle") || 0
                        },
                        yj: u(a, jb),
                        kf: u(a, wd),
                        xj: u(a, Te)
                    }
                }),
                Ou = function() {
                    function a(c, b) {
                        var d = this;
                        this.Lb = 0;
                        this.od = [];
                        this.Kb = null;
                        this.va = this.$b = this.Xf = !1;
                        this.recordStamp = 0;
                        this.uh = function() {
                            return d.page
                        };
                        this.zd = function() {
                            return d.Lb
                        };
                        this.df = function() {
                            return d.recordStamp
                        };
                        this.rh = function() {
                            return d.eb
                        };
                        this.cf = function() {
                            return d.Kb
                        };
                        this.sa = function() {
                            return d.Id
                        };
                        this.stamp = function() {
                            return d.we ? d.l.Math.max(d.we(Y) - d.recordStamp, 0) : 0
                        };
                        this.Ib = function() {
                            return d.options
                        };
                        this.jb = function() {
                            return d.Ag
                        };
                        this.Y = function(f, g, h, k) {
                            void 0 === k && (k = d.stamp());
                            f = d.qh(f, g, h, k);
                            d.aa(f)
                        };
                        this.qh = function(f, g, h, k) {
                            void 0 === k && (k = d.stamp());
                            return {
                                type: f,
                                data: g,
                                stamp: k,
                                frameId: d.Lb,
                                event: h
                            }
                        };
                        this.aa = function(f) {
                            f = ca(f) ? f : [f];
                            d.Xf && !d.$b ? d.va ? (f = B(function(g) {
                                return g.frameId ?
                                    g : z(g, {
                                        frameId: d.Lb
                                    })
                            }, f), d.cf().Of(f)) : d.Vb(f) : d.od = d.od.concat(f)
                        };
                        this.l = c;
                        var e = Hf(c, this, "R");
                        this.te = e.H(this.te, "s");
                        this.aa = e.H(this.aa, "sd");
                        e = G(c);
                        e.C("wv2e") && de();
                        e.D("wv2e", !0);
                        this.options = b;
                        this.eb = da(c);
                        this.Id = new ju(this.l, b);
                        this.Ag = Nu(c);
                        this.Ne = B(function(f) {
                            return new f[0](c, d, f[1])
                        }, ih);
                        this.Mh();
                        this.page = On(this.l);
                        this.te()
                    }
                    a.prototype.start = function(c) {
                        this.Xf = !0;
                        this.Vb = c;
                        this.Lf()
                    };
                    a.prototype.stop = function() {
                        hh(this.l) && (y(function(c) {
                                return c.stop()
                            }, this.Ne), this.Id.stop(),
                            this.Kb && this.Kb.stop(), this.va || this.Y("event", {}, "eof"))
                    };
                    a.prototype.oc = function(c, b) {
                        var d = new a(c, z({}, this.options, {
                            frameId: b
                        }));
                        d.start(E);
                        return d
                    };
                    a.prototype.Mh = function() {
                        var c = this;
                        this.va = !!this.options.frameId;
                        this.Lb = this.options.frameId || 0;
                        this.$b = !this.va;
                        var b = this.options.fg || [];
                        b.push(R(this.l).host);
                        this.Kb = Pn(this.l, this, b);
                        b = this.Kb.yd();
                        jb(this.l) ? this.$b && b.F(["i"], function(d) {
                            c.va = d.va;
                            c.$b = !1;
                            d.frameId && (c.Lb = d.frameId);
                            c.Lf()
                        }) : this.$b = this.va = !1
                    };
                    a.prototype.Lf = function() {
                        var c =
                            Id(this.od);
                        this.aa(c)
                    };
                    a.prototype.te = function() {
                        this.we = dg(this.l);
                        this.recordStamp = this.we(Y);
                        y(function(c) {
                            c.start()
                        }, this.Ne);
                        this.Id.start()
                    };
                    return a
                }(),
                Pu = function() {
                    return function(a, c, b) {
                        var d = this;
                        this.fd = this.Qb = !1;
                        this.Wa = [];
                        this.sf = [];
                        this.Qe = [];
                        this.send = function(e, f, g) {
                            e = d.sender(e, d.nc);
                            f && g && e.then(f, g);
                            return e
                        };
                        this.ve = function(e, f, g) {
                            return new L(function(h, k) {
                                e.push([f, h, k, g])
                            })
                        };
                        this.Gh = function() {
                            d.Wa = zg(function(g, h) {
                                return g[3].partNum - h[3].partNum
                            }, d.Wa);
                            var e = J(function(g,
                                    h, k) {
                                    h = h[3];
                                    return g && k + 1 === h.partNum
                                }, !0, d.Wa),
                                f = !!d.Wa[d.Wa.length - 1][3].end;
                            return e && f
                        };
                        this.ud = function(e) {
                            oh(d.l, e.slice(), function(f) {
                                d.send(f[0], f[1], f[2])
                            }, 20, "s.w2.sf.fes");
                            Id(e)
                        };
                        this.dh = function() {
                            d.fd || (d.fd = !0, d.ud(d.sf), d.ud(d.Qe))
                        };
                        this.Hg = function(e) {
                            return J(function(f, g) {
                                var h = "page" === g.type && !g.frameId,
                                    k = "eof" === g.data.type || "eof" === g.event,
                                    l = h && !!g.partNum;
                                return {
                                    ld: f.ld || l,
                                    kd: f.kd || h,
                                    jd: f.jd || k
                                }
                            }, {
                                kd: !1,
                                jd: !1,
                                ld: !1
                            }, e)
                        };
                        this.Eh = function(e, f, g) {
                            g ? (e = d.ve(d.Wa, e, f[0]), d.Gh() &&
                                (d.ud(d.Wa), d.Qb = !0)) : (d.Qb = !0, e = d.send(e));
                            return e
                        };
                        this.ef = function(e, f, g) {
                            var h;
                            f = {
                                J: (h = {}, h["wv-part"] = "" + g, h["wv-type"] = d.Fi, h),
                                K: Ka(),
                                ba: {
                                    da: f
                                }
                            };
                            e && f.K.D("bt", 1);
                            return f
                        };
                        this.Wg = function(e, f, g) {
                            e = d.ef(!1, e, g);
                            return d.Qb ? d.send(e) : d.ve(d.Qe, e, f)
                        };
                        this.$h = function(e, f, g) {
                            e = d.ef(!0, e, g);
                            if (d.Qb) return d.send(e);
                            var h = d.Hg(f);
                            g = h.kd;
                            var k = h.jd;
                            h = h.ld;
                            var l;
                            g && (l = d.Eh(e, f, h));
                            d.fd ? g || (l = d.send(e)) : (g || (l = d.ve(d.sf, e, f)), (d.Qb || k) && d.dh());
                            return l
                        };
                        this.l = a;
                        this.Fi = b;
                        this.sender = va(a, "W", c);
                        this.nc = c
                    }
                }(),
                Nl = w(function(a) {
                    var c = G(a),
                        b = c.C("isEU");
                    if (W(b)) {
                        var d = Ga(te(a, "is_gdpr") || "");
                        if (K(d, [0, 1])) c.D("isEU", d), b = !!d;
                        else if (a = Pa(a).C("wasSynced"), a = n(a, "params.eu")) c.D("isEU", a), b = !!a
                    }
                    return b
                }, function(a) {
                    return G(a).C("isEU")
                }),
                Cf = A("i.e", Nl),
                Qu = A("i.ep", function(a) {
                    Nl(a)
                }),
                Ru = A("w2", function(a, c) {
                    function b() {
                        h = !0
                    }
                    var d = G(a),
                        e = M(c);
                    if (!c.yb || ld(a) || !a.MutationObserver || !Ia("Element", a.Element)) return E;
                    Ia("MutationObserver", a.MutationObserver) || Hd(a, e).warn("MutationObserver is overridden, webvisor is not guaranteed to work in this environment");
                    var f = Fa(function(k, l) {
                            qa(c, l)["catch"](k)
                        }),
                        g = Cb(a)(Qg(C([a, c], Mn)))(dl(function(k) {
                            return new Ou(a, k)
                        })),
                        h = !1;
                    jr([g, f])(Qa(D(a, "wv2.R.c"), function(k) {
                        var l = k[0];
                        k = k[1];
                        if (!h) {
                            b = function() {
                                h || (h = !0, l && l.stop())
                            };
                            var m = d.C("wv2Counter");
                            if (!Vh(a, k) || m) b();
                            else if (da(a).F(a, ["beforeunload", "unload"], b), d.D("wv2Counter", e), d.D("stopRecorder", b), k = gi(a, "7", "6")) {
                                m = new Pu(a, c, k.type);
                                var p = Kl.$e(e, "m", H(m.$h, m), k, a),
                                    r = Kl.$e(e, "e", H(m.Wg, m), k, a);
                                k = Nn();
                                m = k.ji;
                                r.F("ag", k.yg);
                                r.F("p", m);
                                p.F("see", function(t) {
                                    var x = !1;
                                    y(function(F) {
                                        "page" === F.type && (x = !0)
                                    }, t);
                                    x && (h || r.push({
                                        type: "event",
                                        event: "fatalError",
                                        data: {
                                            code: "invalid-snapshot",
                                            Xg: "p.s.f",
                                            stack: ""
                                        }
                                    }), b())
                                });
                                var q = Mb(function(t) {
                                    "eof" === n(t, "data.type") || "eof" === t.event ? (r.push(t), p.push(t), r.flush(!0), p.flush(!0)) : ("event" === t.type ? r : p).push(t)
                                });
                                O(a, b, 864E5);
                                Sb(a, function() {
                                    var t, x;
                                    rb(a, (t = {}, t.counterKey = e, t.name = "webvisor", t.data = (x = {}, x.version = 2, x), t));
                                    l.start(q)
                                })
                            }
                        }
                    }));
                    return function() {
                        return b()
                    }
                }),
                Su = A("w2.cs", function(a, c) {
                    var b, d = M(c);
                    ag(a,
                        d, (b = {}, b.webvisor = !!c.yb, b))
                }),
                Tu = ["rt", "mf"],
                zf = w(Gc, M),
                Rh = v(nd, ec),
                Uu = gb("isp", function(a, c) {
                    qa(c, function(b) {
                        var d = qb(function(h) {
                            return n(b, "settings." + h)
                        }, Tu);
                        if (d && Wd(a)) {
                            var e = qf(b) && !ne(a),
                                f = zf(c);
                            z(f, {
                                Rb: d,
                                status: e ? 3 : 4
                            });
                            if (!e) {
                                e = In(a, c, d);
                                var g = function(h) {
                                    f.status = h
                                };
                                return ("mf" === d ? Kn : Jn)(a, c, e).then(u(1, g))["catch"](u(2, g))
                            }
                        }
                    })["catch"](D(a, "l.isp"))
                }),
                Ol = A("fbq.o", function(a, c, b) {
                    var d = n(a, "fbq");
                    if (d && d.callMethod) {
                        var e = function() {
                            var g = Ja(arguments),
                                h = d.apply(void 0, g);
                            c(g);
                            return h
                        };
                        z(e, d);
                        b && y(c, b);
                        a.fbq = e
                    } else var f = O(a, C([a, c].concat(Ba(d && d.queue)), Ol), 1E3, "fbq.d");
                    return H(ha, null, a, f)
                }),
                fd, Ib, gd, jh = (fd = {}, fd.add_to_wishlist = "add-to-wishlist", fd.begin_checkout = "begin-checkout", fd.generate_lead = "submit-lead", fd.add_payment_info = "add-payment-info", fd),
                kh = (Ib = {}, Ib.AddToCart = "add-to-cart", Ib.Lead = "submit-lead", Ib.InitiateCheckout = "begin-checkout", Ib.Purchase = "purchase", Ib.CompleteRegistration = "register", Ib.Contact = "submit-contact", Ib.AddPaymentInfo = "add-payment-info", Ib.AddToWishlist =
                    "add-to-wishlist", Ib.Subscribe = "subscribe", Ib),
                Gn = (gd = {}, gd["1"] = jh, gd["2"] = jh, gd["3"] = jh, gd["0"] = kh, gd),
                Hn = [kh.AddToCart, kh.Purchase],
                Vu = sa(function(a, c) {
                    var b = n(c, "ecommerce"),
                        d = n(c, "event") || "";
                    if (!(b = b && d && {
                            version: "3",
                            sc: d
                        })) a: {
                        if (ca(c) || Ta(c))
                            if (b = Ja(c), d = b[1], "event" === b[0] && d) {
                                b = {
                                    version: "2",
                                    sc: d
                                };
                                break a
                            }
                        b = void 0
                    }
                    b || (b = (b = n(c, "ecommerce")) && {
                        version: "1",
                        sc: I(",", ea(b))
                    });
                    b && a(b)
                }),
                Wu = A("ag.e", function(a, c) {
                    if ("0" === c.ca) {
                        var b = [],
                            d = D(a, "ag.s", C([ja, b], y));
                        qa(c, function(e) {
                            if (n(e, "settings.auto_goals") &&
                                za(a, c) && (e = Ce(a, c, "autogoal").reachGoal)) {
                                e = C([e, c.rd], Fn);
                                var f = Vu(e);
                                e = C([a, e], En);
                                b.push(Ol(a, e));
                                b.push(Wi(a, "dataLayer", function(g) {
                                    g.za.F(f)
                                }))
                            }
                        });
                        return d
                    }
                }),
                Xu = /[^\d.,]/g,
                Yu = /[.,]$/,
                Cn = A("ep.pp", function(a, c) {
                    if (!c) return 0;
                    a: {
                        var b = c.replace(Xu, "").replace(Yu, "");
                        var d = "0" === b[b.length - 1];
                        for (var e = b.length; 0 < e && !(3 < b.length - e + 1 && d); --e) {
                            var f = b[e - 1];
                            if (K(f, [",", "."])) {
                                d = f;
                                break a
                            }
                        }
                        d = ""
                    }
                    b = d ? c.split(d) : [c];
                    d = d ? b[1] : "00";
                    b = parseFloat(Tb(b[0]) + "." + Tb(d));
                    d = Math.pow(10, 8) - .01;
                    a.isNaN(b) ? b = 0 :
                        (b = a.Math.min(b, d), b = a.Math.max(b, 0));
                    return b
                }),
                Zu = [
                    [
                        ["EUR", "\u20ac"], "978"
                    ],
                    [
                        ["USD", "\u0423\\.\u0415\\.", "\\$"], "840"
                    ],
                    [
                        ["UAH", "\u0413\u0420\u041d", "\u20b4"], "980"
                    ],
                    ["\u0422\u0413 KZT \u20b8 \u0422\u04a2\u0413 TENGE \u0422\u0415\u041d\u0413\u0415".split(" "), "398"],
                    [
                        ["GBP", "\u00a3", "UKL"], "826"
                    ],
                    ["RUR RUB \u0420 \u0420\u0423\u0411 \u20bd P \u0420UB P\u0423\u0411 P\u0423B PY\u0411 \u0420Y\u0411 \u0420\u0423B P\u0423\u0411".split(" "), "643"]
                ],
                $u = w(function(a) {
                    return new RegExp(I("|", a), "i")
                }),
                av =
                A("ep.cp", function(a) {
                    if (!a) return "643";
                    var c = Mi(a);
                    return (a = qb(function(b) {
                        return $u(b[0]).test(c)
                    }, Zu)) ? a[1] : "643"
                }),
                bv = w(function() {
                    function a() {
                        var k = h + "0",
                            l = h + "1";
                        f[k] ? f[l] ? (h = h.slice(0, -1), --g) : (e[l] = b(8), f[l] = 1) : (e[k] = b(8), f[k] = 1)
                    }

                    function c() {
                        var k = h + "1";
                        f[h + "0"] ? f[k] ? (h = h.slice(0, -1), --g) : (h += "1", f[h] = 1) : (h += "0", f[h] = 1)
                    }

                    function b(k) {
                        void 0 === k && (k = 1);
                        var l = d.slice(g, g + k);
                        g += k;
                        return l
                    }
                    for (var d = I("", Ph("Cy2FcreLJLpYXW3BXFJqldVsGMwDcBw2BGnHL5uj1TKstzse3piMo3Osz+EqDotgqs1TIoZvKtMKDaSRFztgUS8qkqZcaETgKWM54tCpTXjV5vW5OrjBpC0jF4mspUBQGd95fNSfv+vz+g+Hze33Hg8by+Yen1PP6zsdl7PQCwX9mf+f7FMb9x/Pw+v2Pp8Xy74eTwuBwTt913u4On1XW6hxOO5nIzFam00tC218S0kaeugpqST+XliLOlMoTpRQkuewUxoy4CT3efWtdFjSAAm+1BkjIhyeU4vGOf13a6U8wzNY4bGo6DIUemE7N3SBojDr7ezXahpWF022y8mma1NuTnZbq8XZZlPStejfG/CsbPhV6/bSnA==")),
                            e = {}, f = {}, g = 1, h = ""; g < d.length - 1;)("0" === b() ? c : a)();
                    return e
                }),
                zn = A("ep.dec", function(a, c) {
                    if (!c || ld(a)) return [];
                    var b = Ph(c),
                        d = b[1],
                        e = b[2],
                        f = b.slice(3);
                    if (2 !== Ng(b[0])) return [];
                    b = bv();
                    f = I("", f);
                    e = Ng(d + e);
                    var g = "";
                    d = "";
                    for (var h = 0; d.length < e && f[h];) g += f[h], b[g] && (d += String.fromCharCode(Ng(b[g])), g = ""), h += 1;
                    b = "";
                    for (f = 0; f < d.length;) e = d.charCodeAt(f), 128 > e ? (b += String.fromCharCode(e), f++) : 191 < e && 224 > e ? (g = d.charCodeAt(f + 1), b += String.fromCharCode((e & 31) << 6 | g & 63), f += 2) : (g = d.charCodeAt(f + 1), b += String.fromCharCode((e &
                        15) << 12 | (g & 63) << 6 | d.charCodeAt(f + 2) & 63), f += 3);
                    d = xb(a, b);
                    return ca(d) ? B(Or, d) : []
                }),
                Bn = A("ep.ent", function(a, c, b) {
                    a = "" + Wa(a, 10, 99);
                    b = "" + 100 * c + b + a;
                    if (16 < Ta(b)) return "";
                    b = Qh("0", 16, b);
                    c = b.slice(0, 8);
                    b = b.slice(-8);
                    c = (+c ^ 92844).toString(35);
                    b = (+b ^ 92844).toString(35);
                    return "" + c + "z" + b
                }),
                Pl = v(Oh, av),
                Ql = A("ep.ctp", function(a, c, b, d) {
                    var e = Pl(a, b),
                        f = Nh(a, d);
                    Mh(a, c, e, f);
                    Ia("MutationObserver", a.MutationObserver) && (new a.MutationObserver(function() {
                        var g = Pl(a, b),
                            h = Nh(a, d);
                        if (e !== g || f !== h) e = g, f = h, Mh(a, c, e, f)
                    })).observe(a.document.body, {
                        attributes: !0,
                        childList: !0,
                        subtree: !0,
                        characterData: !0
                    })
                }),
                cv = A("ep.chp", function(a, c, b, d, e) {
                    b && xf(a, c);
                    return d || e ? da(a).F(a.document, ["click"], D(a, "ep.chp.cl", C([a, c, d, e], An))) : E
                }),
                gv = A("ep.i", function(a, c) {
                    if (Od(a)) return yn(a, c).then(function(b) {
                        var d = b.Sg,
                            e = d[0],
                            f = d[1],
                            g = d[2],
                            h = d[3],
                            k = d[4],
                            l = d[5],
                            m = d[6],
                            p = d[7],
                            r = d[8],
                            q = d[9],
                            t = d[10],
                            x = d[11],
                            F = d[12],
                            U = d[13],
                            N = d[14],
                            ma = d[15];
                        if (!b.isEnabled) return L.resolve(E);
                        var wa = pe(a, e),
                            Bb = pe(a, h),
                            Cd = pe(a, m),
                            ze = pe(a, r),
                            dv = "" + e + f + g === "" + h + k + l;
                        return new L(function(ev,
                            fv) {
                            Cb(a)(Qa(fv, function() {
                                wa && Ql(a, c, f, g, t, x, F);
                                Bb && !dv && Ql(a, c, k, l, U, N, ma);
                                ev(cv(a, c, Cd || ze, p, q))
                            }))
                        })
                    })
                }),
                gn = ["RTCPeerConnection", "mozRTCPeerConnection", "webkitRTCPeerConnection"],
                xn = v(ea, Uc),
                hv = A("cc.i", function(a, c) {
                    var b = C([a, c], wn);
                    b = C([a, b, 300, void 0], O);
                    qa(c, b)
                }),
                iv = u("9-d5ve+.r%7", P),
                jv = A("ad", function(a, c) {
                    if (!c.Ta) {
                        var b = G(a);
                        if (!b.C("adBlockEnabled")) {
                            var d = function(m) {
                                    K(m, ["2", "1"]) && b.D("adBlockEnabled", m)
                                },
                                e = wc(a),
                                f = e.C("isad");
                            if (f) d(f);
                            else {
                                var g = u("adStatus", b.D),
                                    h = function(m) {
                                        m =
                                            m ? "1" : "2";
                                        d(m);
                                        g("complete");
                                        e.D("isad", m, 1200);
                                        return m
                                    },
                                    k = va(a, "adb", c);
                                if (!b.C("adStatus")) {
                                    g("process");
                                    var l = "metrika/a" + iv().replace(/[^a-v]+/g, "") + "t.gif";
                                    tn(a, function() {
                                        return k({
                                            na: {
                                                Ba: l
                                            }
                                        }).then(u(!1, h))["catch"](u(!0, h))
                                    })
                                }
                            }
                        }
                    }
                }),
                kv = A("pr.p", function(a, c) {
                    var b, d;
                    if (ng(a)) {
                        var e = va(a, "5", c),
                            f = Ka((b = {}, b.pq = 1, b.ar = 1, b));
                        e({
                            K: f,
                            J: (d = {}, d["page-url"] = R(a).href, d["page-ref"] = n(a, "document.referrer") || "", d)
                        }, c)["catch"](D(a, "pr.p.s"))
                    }
                }),
                Lh = !1,
                lv = A("fid", function(a) {
                    var c, b = E;
                    if (!T(a.PerformanceObserver)) return b;
                    var d = G(a);
                    if (d.C("fido")) return b;
                    d.D("fido", !0);
                    var e = new a.PerformanceObserver(D(a, "fid", function(f) {
                        f = f.getEntries()[0];
                        d.D("fid", a.Math.round(100 * (f.processingStart - f.startTime)));
                        b()
                    }));
                    b = function() {
                        return e.disconnect()
                    };
                    try {
                        e.observe((c = {}, c.type = "first-input", c.buffered = !0, c))
                    } catch (f) {}
                    return b
                }),
                mv = A("lt.p", gb("lt.p", function(a) {
                    var c;
                    if (Ia("PerformanceObserver", a.PerformanceObserver)) {
                        var b = 0,
                            d = new a.PerformanceObserver(D(a, "lt.o", function(e) {
                                e && e.getEntries && (e = e.getEntries(), b = J(function(f,
                                    g) {
                                    return f + g.duration
                                }, b, e), Td(a).D("lt", b))
                            }));
                        try {
                            d.observe((c = {}, c.type = "longtask", c.buffered = !0, c))
                        } catch (e) {
                            return
                        }
                        return function() {
                            return d.disconnect()
                        }
                    }
                })),
                nv = w(v(Q("performance.memory.jsHeapSizeLimit"), Da("concat", ""))),
                ov = ["availWidth", "availHeight", "availTop"],
                pv = "appName vendor deviceMemory hardwareConcurrency maxTouchPoints appVersion productSub appCodeName vendorSub".split(" "),
                qv = ["webgl", "experimental-webgl"],
                rn = [-.2, -.9, 0, .4, -.26, 0, 0, .732134444, 0],
                tf = u(Ra("ccf"), Ua),
                qn = "prefers-reduced-motion;prefers-reduced-transparency;prefers-color-scheme: dark;prefers-color-scheme: light;pointer: none;pointer: coarse;pointer: fine;any-pointer: none;any-pointer: coarse;any-pointer: fine;scan: interlace;scan: progressive;color-gamut: srgb;color-gamut: p3;color-gamut: rec2020;update: fast;update: slow;update: none;grid: 0;grid: 2;hover: hover;inverted-colors: inverted;inverted-colors: none".split(";"),
                Jh = "video/ogg video/mp4 video/webm audio/x-aiff audio/x-m4a audio/mpeg audio/aac audio/wav audio/ogg audio/mp4".split(" "),
                on = "theora vorbis 1 avc1.4D401E mp4a.40.2 vp8.0 mp4a.40.5".split(" "),
                jn = w(Hi),
                Ih = w(xb, Za),
                rv = A("phc.p", function(a, c) {
                    if (!pl(a)) return qa(c, function(b) {
                        var d = c.id,
                            e = Lc(a, void 0, d),
                            f = e.C("phc_settings") || "";
                        if (b = n(b, "settings.phchange")) {
                            var g = yb(a, b) || "";
                            g !== f && e.D("phc_settings", g)
                        } else f && (b = Ih(a, f));
                        e = n(b, "clientId");
                        f = n(b, "orderId");
                        b = n(b, "phones") || [];
                        e && f && b.length && (f = {
                            Cb: "",
                            Pb: "",
                            Vf: 0,
                            ja: {},
                            Aa: [],
                            mf: !1,
                            gb: !0,
                            l: a,
                            nc: c
                        }, z(f, {
                            mf: !0
                        }), Hh(a, d, f), b = Ed(a), e = Ji(a, b, 1E3), d = H(Hh, null, a, d, f), e.F(d), Ki(a, b))
                    })
                }),
                lh = w(function(a, c) {
                    var b = G(a),
                        d = Pa(a),
                        e = [],
                        f = C([a, c, b, d], Fp);
                    xd(a) || Gp(a, "14.1") || e.push(C([fn, "pp", ""], f));
                    var g = !rl(a) || rf(a, 68);
                    g && e.push(C([hn, "pu", ""], f));
                    !g || d.Kd || Wd(a) || (e.push(C([en, "zzlc", "na"], f)), e.push(C([dn, "cc", ""], f)));
                    return e.length ? {
                        Da: function(h, k) {
                            if (0 === b.C("isEU")) try {
                                y(Be, e)
                            } catch (l) {}
                            k()
                        },
                        N: function(h, k) {
                            var l = h.K;
                            if (l && 0 === b.C("isEU")) try {
                                y(Fa(l),
                                    e)
                            } catch (m) {}
                            k()
                        }
                    } : {}
                }, v(Za, M)),
                sv = v(function(a) {
                    return (a = n(a, "navigator.plugins")) && Ta(a) ? v(Ba, ua, ns(function(c, b) {
                        return c.name > b.name ? 1 : 2
                    }), Mb(Cp))(a) : ""
                }, we(",")),
                tv = function(a) {
                    return function(c) {
                        var b = eb(c);
                        if (!b) return "";
                        b = b("canvas");
                        var d = [],
                            e = a(),
                            f = e.Zg;
                        e = e.Pg;
                        try {
                            var g = Da("getContext", b);
                            d = B(v(P, g), e)
                        } catch (h) {
                            return ""
                        }
                        return (g = qb(P, d)) ? f(c, {
                            canvas: b,
                            Eg: g
                        }) : ""
                    }
                }(function() {
                    return {
                        Pg: qv,
                        Zg: $m
                    }
                }),
                Ym = ["name", "lang", "localService", "voiceURI", "default"],
                uv = A("p.tfs", function(a) {
                    var c = G(a);
                    if (!c.C("tfs")) {
                        c.D("tfs", !0);
                        c = da(a);
                        var b = E;
                        b = c.F(a, ["message"], function(d) {
                            var e = n(d, "origin");
                            if ("https://iframe-toloka.com" === e || "https://iframe-tasks.yandex" === e)
                                if (d = xb(a, d.data), pa(d) && "appendremote" === d.action)
                                    if (d = Pa(a), d.C("tfsc") || a.confirm("\u0414\u043e\u043f\u043e\u043b\u043d\u0435\u043d\u0438\u0435 \u201c\u0420\u0430\u0437\u043c\u0435\u0442\u043a\u0430 \u0441\u0430\u0439\u0442\u043e\u0432\u201c \u043e\u0442 toloka.ai \u0437\u0430\u043f\u0440\u0430\u0448\u0438\u0432\u0430\u0435\u0442 \u0434\u043e\u0441\u0442\u0443\u043f \u043a \u0441\u043e\u0434\u0435\u0440\u0436\u0438\u043c\u043e\u043c\u0443 \u0441\u0442\u0440\u0430\u043d\u0438\u0446\u044b. \u0420\u0430\u0437\u0440\u0435\u0448\u0438\u0442\u044c?")) {
                                        d.D("tfsc",
                                            1);
                                        var f, g;
                                        G(a).D("_u", (f = {}, f.getCachedTags = Ae, f.button = (g = {}, g.closest = u(a, ge), g.select = Uf, g.getData = u(a, he), g), f));
                                        tc(a, {
                                            src: "https://yastatic.net/s3/metrika/2.1540128042.1/form-selector/button_ru.js"
                                        });
                                        b()
                                    } else a.close()
                        })
                    }
                }),
                Wm = fb(/[a-z\u0430-\u044f\u0451,.]/gi),
                vv = A("ice", function(a, c, b) {
                    (c = za(a, c)) && (b = Eh(b)) && Dh(a, c, b)
                }),
                wv = A("ice", function(a, c, b) {
                    (c = za(a, c)) && (b = Eh(b)) && jj(a, b.Oh).then(C([a, c, b], Dh), D(a, "ice.s"))
                }),
                xv = ["text", "email", "tel"],
                yv = ["cc-", "name", "shipping"],
                zv = A("icei", function(a,
                    c) {
                    if (Od(a) && kl(a)) {
                        var b = !1,
                            d = [];
                        Cb(a)(Qa(E, C([c, function(e) {
                            if (!(Cf(a) || n(e, "settings.eu") || b)) {
                                var f = n(e, "settings.cf") ? wv : vv,
                                    g = da(a);
                                e = sb("input", a.document.body);
                                y(function(h) {
                                    Lf(a, h) || !K(h.type, xv) || Ya(Gb, B(u(h.autocomplete, cb), yv)) || d.push(g.F(h, ["blur"], C([a, c], f)))
                                }, e)
                            }
                        }], qa)));
                        return function() {
                            y(ja, d);
                            b = !0
                        }
                    }
                }),
                Ch, Av = A("p.ai", function(a, c) {
                    if (xd(a) || kf(a)) return qa(c, function(b) {
                        var d;
                        if (b = n(b, "settings.sbp")) return Bh(a, z({}, b, (d = {}, d.c = c.id, d)), 10)
                    })
                }),
                Bv = "architecture bitness model platformVersion uaFullVersion fullVersionList".split(" "),
                Rl = gb("uah", function(a) {
                    if (!Ia("getHighEntropyValues", n(a, "navigator.userAgentData.getHighEntropyValues"))) return L.reject("0");
                    try {
                        return a.navigator.userAgentData.getHighEntropyValues(Bv).then(function(c) {
                            if (!pa(c)) throw "2";
                            return c
                        }, function() {
                            throw "1";
                        })
                    } catch (c) {
                        return L.reject("3")
                    }
                }),
                Sl = new RegExp(I("|", "yandex.com/bots;Googlebot;APIs-Google;Mediapartners-Google;AdsBot-Google;FeedFetcher-Google;Google-Read-Aloud;DuplexWeb-Google;Google Favicon;googleweblight;Lighthouse;Mail.RU_Bot;StackRambler;Slurp;msnbot;bingbot;www.baidu.com/search/spi_?der.htm".split(";")).replace(/[./]/g,
                    "\\$&")),
                Pm = w(function(a) {
                    var c = lb(a);
                    return (c = Sl.test(c)) ? L.resolve(c) : Rl(a).then(function(b) {
                        try {
                            return J(function(d, e) {
                                return d || Sl.test(e.brand)
                            }, !1, b.brands)
                        } catch (d) {
                            return !1
                        }
                    }, u(!1, P))
                }),
                qc = ["0", "1", "2", "3"],
                Mc = qc[0],
                jf = qc[1],
                Cv = qc[2],
                Tl = ["GDPR-ok-view-detailed-0", "GDPR-ok-view-detailed-1", "GDPR-ok-view-detailed-2", "GDPR-ok-view-detailed-3"],
                zh = ["GDPR-ok-view-default", "GDPR-ok-view-detailed"].concat(Tl),
                hf = "GDPR-ok GDPR-cross GDPR-cancel 3 4 5 6 7 8 9 10 11 12 13 14 15 16 17 GDPR-settings GDPR-ok-view-default GDPR-ok-view-detailed 21 22 23".split(" ").concat(Tl).concat(["28",
                    "29", "30", "31"
                ]),
                Dv = "3 13 14 15 16 17 28".split(" "),
                le = v(Mb(Q("ymetrikaEvent.type")), ms(pc(hf))),
                Ev = {
                    Wh: !0,
                    url: "https://yastatic.net/s3/gdpr/v3/gdpr",
                    yf: "",
                    qf: "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz cs da de el hr it nl pl sk sv".split(" ")
                },
                Sm = gb("gdpr", function(a, c, b, d, e) {
                    function f(p) {
                        c("10");
                        b.F(zh, function(r) {
                            var q;
                            r = r.type;
                            l.Rf((q = {}, q.type = r, q));
                            p({
                                value: Ah(r)
                            })
                        })
                    }
                    var g = void 0 === e ? Ev : e;
                    e = g.url;
                    var h = g.yf,
                        k = g.Wh;
                    g = Vm(a, g.qf, d.ej);
                    var l = oe(a, d);
                    if (!l) return L.resolve({
                        value: Mc,
                        Md: !0
                    });
                    if (a._yaGdprLoaded) return new L(function(p) {
                        c("7");
                        f(p)
                    });
                    var m = tc(a, {
                        src: "" + e + (k ? "" : g) + h + ".js"
                    });
                    return new L(function(p, r) {
                        m ? (c("7"), m.onerror = function() {
                            var q;
                            c("9");
                            l.Rf((q = {}, q.type = "GDPR-ok-view-default", q));
                            p(null)
                        }, m.onload = u(p, f)) : (c("9"), r(Ra("gdp.e")))
                    })
                }),
                ac, Um = (ac = {}, ac["GDPR-ok"] = "ok", ac["GDPR-ok-view-default"] = "ok-default", ac["GDPR-ok-view-detailed"] = "ok-detailed", ac["GDPR-ok-view-detailed-0"] = "ok-detailed-all", ac["GDPR-ok-view-detailed-1"] = "ok-detailed-tech", ac["GDPR-ok-view-detailed-2"] =
                    "ok-detailed-tech-analytics", ac["GDPR-ok-view-detailed-3"] = "ok-detailed-tech-other", ac),
                Nm = "az be en es et fi fr hy ka kk ky lt lv no pt ro ru sl tg tr uz ar he sr uk zh".split(" "),
                yh = [],
                wh = Da("push", yh),
                Mm = w(function(a, c) {
                    var b = c.C("gdpr");
                    return K(b, qc) ? "-" + b : ""
                }),
                Ul = w(Dd),
                Fv = w(function() {
                    var a = J(function(c, b) {
                        "ru" !== b && (c[b] = zl + "." + b);
                        return c
                    }, {}, wg);
                    y(function(c) {
                        a[c] = c
                    }, ea(ul));
                    return a
                }),
                Em = w(function(a) {
                    a = R(a).hostname;
                    return (a = qb(v(Q("1"), Ii("test"), Fb(ja)(a)), Ma(ul))) && a[0]
                }),
                Vl = function(a,
                    c) {
                    return function(b, d) {
                        var e = M(d);
                        e = Fv(e);
                        var f = Cm(b, e),
                            g = G(b),
                            h = jb(b);
                        return Wd(b) || Sd(b) ? {} : {
                            N: function(k, l) {
                                var m = k.K,
                                    p = uh(b);
                                m = !(m && m.C("pv"));
                                if (!p || h || m || !f.length) return l();
                                if (g.C("startSync")) Ul(b).push(l);
                                else {
                                    g.D("startSync", !0);
                                    p = C([b, f, E, !1], a);
                                    m = lf[0];
                                    if (!m) return l();
                                    m(b).then(p).then(l, v(od(l), D(b, c)))["catch"](E)
                                }
                            }
                        }
                    }
                }(function(a, c, b, d) {
                    var e = ia(a),
                        f = G(a),
                        g = Pa(a);
                    b = Yg(a, "c");
                    var h = Xb(a, b);
                    return J(function(k, l) {
                        function m() {
                            var q = g.C("synced");
                            f.D("startSync", !1);
                            q && (q[l.Yh] = p, g.D("synced",
                                q));
                            q = Ul(a);
                            y(ja, q);
                            Id(q)
                        }
                        var p, r = h({
                            ba: {
                                ha: ["sync.cook"],
                                Pa: 1500
                            }
                        }, [Ea.Ra + "//" + l.Li + "/sync_cookie_image_check" + (d ? "_secondary" : "")]).then(function() {
                            p = e(pb);
                            m()
                        })["catch"](function() {
                            p = e(pb) - 1435;
                            m()
                        });
                        r = u(r, P);
                        return k.then(r)
                    }, L.resolve(), c)["catch"](D(a, "ctl"))
                }, "sy.c"),
                Jb, Am = (Jb = {}, Jb.brands = "chu", Jb.architecture = "cha", Jb.bitness = "chb", Jb.uaFullVersion = "chf", Jb.fullVersionList = "chl", Jb.mobile = "chm", Jb.model = "cho", Jb.platform = "chp", Jb.platformVersion = "chv", Jb),
                wm = w(function(a) {
                    return Rl(a).then(xm,
                        Bm)
                }),
                Gv = gb("ot", function(a, c) {
                    if (Le(a)) {
                        var b = da(a);
                        return qa(c, D(a, "ot.s", function(d) {
                            if (n(d, "settings.oauth")) {
                                var e = [],
                                    f = nd(a, c);
                                e.push(b.F(a, ["message"], D(a, "ot.m", u(f, vm))));
                                Cb(a)(Qa(E, D(a, "ot.b", function() {
                                    function g(r) {
                                        var q, t = r.href;
                                        t && ml(t, "https://oauth.yandex.ru/") && !cb(t, "_ym_uid=") && (t = cb(t, "?") ? "&" : "?", r.href += "" + t + Cc((q = {}, q._ym_uid = f, q.mc = "v", q)), b.F(r, ["click"], D(a, "ot.click", function() {
                                            var x = "et=" + l(Y);
                                            r.href += "&" + x
                                        })))
                                    }
                                    var h, k = a.document.body,
                                        l = ia(a),
                                        m = sb("a", k);
                                    y(g, m);
                                    if (Ia("MutationObserver",
                                            a.MutationObserver)) {
                                        m = new a.MutationObserver(D(a, "ot.m", u(function(r) {
                                            r = r.addedNodes;
                                            for (var q = 0; q < r.length; q += 1) {
                                                var t = r[q];
                                                "A" === t.nodeName && g(t)
                                            }
                                        }, y)));
                                        var p = (h = {}, h.childList = !0, h.subtree = !0, h);
                                        m.observe(k, p);
                                        e.push(H(m.disconnect, m))
                                    }
                                })));
                                return C([Be, e], y)
                            }
                        }))
                    }
                }),
                Hv = A("p.cta", function(a) {
                    Cb(a)(Qa(E, function() {
                        var c = G(a);
                        if (tm(a.document)) {
                            var b = 0;
                            if (Af(a, Oc, "cta")) {
                                var d = E,
                                    e = function() {
                                        Bf(Oc, "cta");
                                        d();
                                        ha(a, b)
                                    };
                                d = da(a).F(a, ["message"], A("p.cta.o", C([a, c, e], um)));
                                b = O(a, e, 1500)
                            } else c.D("cta.e",
                                "if")
                        } else c.D("cta.e", "ns")
                    }))
                }),
                pm = ["bidResponse", "bidAdjustment", "bidWon"],
                qm = ["cpm", "currency", "netRevenue", "requestTimestamp", "responseTimestamp"],
                Ha = {},
                Iv = A("pj", function(a, c) {
                    var b, d = za(a, c),
                        e = d && d.params;
                    return e ? (b = {}, b.pbjs = function(f) {
                        ca(f) && (f = fa(Gb, B(function(g) {
                            if (pa(g) && g.data && g.event && pa(g.data)) {
                                var h = n(g, "data.args");
                                return h ? {
                                    event: g.event,
                                    data: h
                                } : g
                            }
                        }, f)), om(f), rm(a, e))
                    }, b) : E
                }),
                mm = /(\D\d*)/g,
                nm = w(function() {
                    var a = Ae();
                    return J(function(c, b) {
                        c[a[b]] = b;
                        return c
                    }, {}, ea(a))
                }),
                Jv = A("g.v.e",
                    function(a, c) {
                        return qa(c, D(a, "g.v.t", function(b) {
                            var d = za(a, c);
                            if (d && (b = n(b, "settings.goal_values"))) {
                                var e = fa(v(Q("url"), u(a, hm)), b);
                                if (0 !== e.length) {
                                    b = da(a);
                                    var f = [];
                                    e = C([a, function(g) {
                                        var h;
                                        return d.params((h = {}, h.__ym = g, h))
                                    }, e], km);
                                    f.push(b.F(a, ["click"], D(a, "g.v.c", C([e], im))));
                                    f.push(b.F(a, ["submit"], D(a, "g.v.s", C([a, e], jm))));
                                    return C([v(P, ja), f], y)
                                }
                            }
                        }))
                    }),
                Wl = {},
                Xl = w(Gc),
                fm = v(Da("exec", /counterID=(\d+)/), Q("1")),
                Yl = sa(function(a, c) {
                    var b = Xl(a),
                        d = Ba(c),
                        e = d[0],
                        f = d[1],
                        g = d.slice(2);
                    if (f) {
                        d = em(a,
                            e);
                        var h = d[0],
                            k = d[1];
                        d = M(k);
                        b[d] || (b[d] = {});
                        b = b[d];
                        c.Se || Wl[f] && J(function(l, m) {
                            return l || !!m(a, k, g, h)
                        }, !1, Wl[f]) || ("init" === f ? (c.Se = !0, h ? wb(a, "" + e, "Duplicate counter " + e + " initialization") : a["yaCounter" + k.id] = new a.Ya[Ea.kc](z({}, g[0], k))) : h && h[f] && b.Lh ? (h[f].apply(h, g), c.Se = !0) : (d = b.Wf, d || (d = [], b.Wf = d), d.push(ra([e, f], g))))
                    }
                }),
                Kv = gb("is", function(a) {
                    if (!jb(a)) {
                        var c = wc(a);
                        if (Se(a, "0")) c.Fb("sup_debug");
                        else {
                            var b = Se(a, "2"),
                                d = !!c.C("sup_debug");
                            if (b || d) return a._ym_debug = !0, c.D("sup_debug", "1", 1440),
                                tc(a, {
                                    src: Al + "/tag_debug.js"
                                })
                        }
                    }
                }),
                dm = A("destruct.e", function(a, c, b) {
                    return function() {
                        var d = G(a),
                            e = c.id;
                        y(function(f, g) {
                            return T(f) && D(a, "dest.fr." + g, f)()
                        }, b);
                        delete d.C("counters")[M(c)];
                        delete a["yaCounter" + e]
                    }
                }),
                hd = G(window);
            hd.Ia("hitParam", {});
            hd.Ia("lastReferrer", window.location.href);
            (function() {
                V.push(function(a, c) {
                    var b;
                    return b = {}, b.firstPartyParams = Ys(a, c), b.firstPartyParamsHashed = zq(a, c), b
                });
                Xd.push("fpp");
                Xd.push("fpmh")
            })();
            (function() {
                var a = G(window);
                a.Ia("getCounters", Zs(window));
                id.push($s);
                Pg.push(function(c, b) {
                    b.counters = a.C("getCounters")
                })
            })();
            (function() {
                V.push(function(a, c) {
                    var b;
                    rb(a, (b = {}, b.counterKey = M(c), b.name = "counter", b.data = fk(c), b))
                })
            })();
            Ca["1"] = nb;
            V.push(at);
            ya["1"] = oc;
            ub($f, -1);
            Vb["1"] = [
                [$f, -1],
                [Qe, 1],
                [Ke, 2],
                [Pb(), 3]
            ];
            V.push(bt);
            V.push(A("p.ar", function(a, c) {
                var b, d = va(a, "a", c);
                return b = {}, b.hit = function(e, f, g, h, k, l) {
                    var m, p, r = {
                        J: {},
                        K: Ka((m = {}, m.pv = 1, m.ar = 1, m))
                    };
                    f = pa(f) ? {
                        title: f.title,
                        Cf: f.referer,
                        R: f.params,
                        dc: f.callback,
                        l: f.ctx
                    } : {
                        title: f,
                        Cf: g,
                        R: h,
                        dc: k,
                        l: l
                    };
                    h = Gd(c);
                    g = e || R(a).href;
                    h.url !== g && (h.ref = h.url, h.url = e);
                    e = f.Cf || h.ref || a.document.referrer;
                    h = Nb(a, c, "PageView. Counter " + c.id + ". URL: " + g + ". Referrer: " + e, f.R);
                    k = z(r.M || {}, {
                        R: f.R,
                        title: f.title
                    });
                    r = d(z(r, {
                        M: k,
                        J: z(r.J || {}, (p = {}, p["page-url"] = g, p["page-ref"] = e, p))
                    }), c).then(h);
                    return Tc(a, "p.ar.s", r, f.dc || E, f.l)
                }, b
            }));
            Ca.a = nb;
            Vb.a = Wb;
            ya.a = jl;
            V.push(Ce);
            Ca.g = nb;
            ya.g = oc;
            Vb.g = Wb;
            V.push(ct);
            V.push(dt);
            Vb.t = Wb;
            Ca.t = nb;
            ya.t = oc;
            V.push(A("cl.p", function(a, c) {
                function b(p, r, q, t) {
                    void 0 === t && (t = {});
                    q ? Ee(a,
                        c, {
                            url: q,
                            ob: !0,
                            Ec: p,
                            Ic: r,
                            sender: e,
                            jg: t
                        }) : g.warn("Empty link")
                }
                var d, e = va(a, "2", c),
                    f = [],
                    g = Zd(a, M(c)),
                    h = M(c),
                    k = D(a, "s.s.tr", u(Ie(a, h), rq));
                h = {
                    l: a,
                    cb: c,
                    $g: f,
                    sender: e,
                    uj: G(a),
                    Ng: bd(a, c.id),
                    wj: zc(a),
                    Si: u(u(h, $e(a)), v(ja, Q("trackLinks")))
                };
                h = D(a, "cl.p.c", u(h, oq));
                h = da(a).F(a, ["click"], h);
                c.cg && k(c.cg);
                var l = D(a, "file.clc", C([!0, !1], b)),
                    m = D(a, "e.l.l.clc", C([!1, !0], b));
                f = D(a, "add.f.e.clc", et(f));
                return d = {}, d.file = l, d.extLink = m, d.addFileExtension = f, d.trackLinks = k, d.u = h, d
            }));
            Vb["2"] = Wb;
            Ca["2"] = nb;
            ya["2"] =
                oc;
            Ca.r = Pd("r");
            ya.r = jl;
            bb.push(A("p.r", function(a, c) {
                var b = gt(a),
                    d = va(a, "r", c),
                    e = D(a, "rts.p");
                return qa(c, C([function(f, g) {
                    var h = {
                            id: g.Mg,
                            ca: g.ca
                        },
                        k = {
                            ba: {
                                da: g.wi
                            },
                            K: Ka(g.Bg),
                            J: g.R,
                            M: {
                                Tb: g.Tb
                            },
                            na: {
                                Ba: g.Ba
                            }
                        };
                    g.Ja && (k.Ja = nf(g.Ja));
                    h = d(k, h)["catch"](e);
                    return f.then(u(h, P))
                }, L.resolve(), b], J))["catch"](e)
            }));
            Z("r", function(a) {
                return {
                    N: function(c, b) {
                        var d = c.K,
                            e = void 0 === d ? Ka() : d,
                            f = c.M.Tb,
                            g = Fd(a);
                        d = e.C("rqnl", 0) + 1;
                        e.D("rqnl", d);
                        if (e = n(g, I(".", [f, "browserInfo"]))) e.rqnl = d, Yf(a);
                        b()
                    },
                    Da: function(c, b) {
                        aj(a,
                            c);
                        b()
                    }
                }
            }, 1);
            ub(De, 100);
            Z("1", De, 100);
            V.push(ht);
            Z("n", Qe, 1);
            Z("n", Ke, 2);
            Z("n", Pb(), 3);
            Z("n", De, 100);
            Ca.n = nb;
            ya.n = oc;
            lc({
                Ke: {
                    ea: "accurateTrackBounce"
                }
            });
            V.push(it);
            Ca.m = Pd("cm");
            ya.m = Ts;
            Z("m", Pb(["u", "v", "vf"]), 1);
            Z("m", De, 2);
            lc({
                Jg: {
                    ea: "clickmap"
                }
            });
            V.push(jt);
            V.push(kt);
            V.push(lt);
            V.push(mt);
            (function() {
                V.push(nt);
                Xd.push("ecommerce");
                lc({
                    rd: {
                        ea: "ecommerce",
                        Ua: function(a) {
                            if (a) return !0 === a ? "dataLayer" : "" + a
                        }
                    }
                })
            })();
            V.push(ot);
            bb.push(qt);
            V.push(rt);
            Xd.push("user_id");
            bb.push(A("p.st", st));
            V.push(tt);
            ub(function(a, c) {
                return {
                    Da: function(b, d) {
                        var e = za(a, c);
                        e = e && e.userParams;
                        var f = (b.M || {}).Ee;
                        e && f && e(f);
                        d()
                    }
                }
            }, 0);
            ee.push(Ws);
            Yb.unshift(wt);
            Rd.push("_ym_debug");
            V.push(xt);
            Yb.push(function(a) {
                var c = G(a);
                c.C("i") || (c.D("i", !0), da(a).F(a, ["message"], u(a, Np)))
            });
            (function() {
                var a, c = (a = {}, a.tp = v(Za, gk, Lb), a.tpid = v(Za, zr), a);
                z(Ld, c)
            })();
            ub(Ad, 20);
            Z("n", Ad, 20);
            Z("1", Ad, 20);
            Yb.push(yt);
            V.push(function(a, c) {
                var b;
                return b = {}, b.ecommerceAdd = A("ecm.a", zt(a, c)), b.ecommerceRemove = A("ecm.r", At(a, c)), b.ecommerceDetail =
                    A("ecm.d", Bt(a, c)), b.ecommercePurchase = A("ecm.p", Ct(a, c)), b
            });
            (function() {
                var a, c = {};
                c.bu = It;
                c.pri = sp;
                c.wv = u(2, P);
                c.ds = vp;
                c.co = function(b) {
                    return zb(G(b).C("jn"))
                };
                c.td = Ot;
                z(c, (a = {}, a.iss = v(xs, Lb), a.hdl = v(ys, Lb), a.iia = v(zs, Lb), a.cpf = v(Ht, Lb), a.ntf = w(function(b) {
                    b = n(b, "Notification.permission");
                    b = "denied" === b ? !1 : "granted" === b ? !0 : null;
                    return Va(b) ? null : b ? 2 : 1
                }), a.eu = Qb("isEU"), a.ns = yi, a.np = function(b) {
                    return Wa(b, 0, 100) ? null : jd(ie(db(Qf(b), 100)))
                }, a));
                c.pani = Jt;
                c.pci = Kt;
                c.si = Lt;
                c.gi = Mt;
                c.hsa = Qb("hsa");
                z(Ld, c)
            })();
            (function() {
                var a = {};
                a.hc = Qb("hc");
                a.oo = Qb("oo");
                a.pmc = Qb("cmc");
                a.lt = function(c) {
                    var b = Td(c).C("lt", null);
                    return b ? c.Math.round(100 * b) : b
                };
                a.re = v(Xq, Lb);
                a.aw = function(c) {
                    c = qb(v(la, Dc), [c.document.hidden, c.document.msHidden, c.document.webkitHidden]);
                    return la(c) ? null : zb(!c)
                };
                a.rcm = Rt;
                a.yu = function(c) {
                    return (c = Lc(c, "").C("yandexuid")) && c.substring(0, 25)
                };
                a.ifc = Qb("ifc");
                a.ifb = Qb("ifb");
                a.ecs = Qb("ecs");
                a.csi = Qb("scip");
                a.cdl = Qb("cdl");
                z(gg, a)
            })();
            ya.er = dd;
            (function(a) {
                try {
                    var c = Yg(a, "er"),
                        b = op(a, c);
                    Xj.push(function(d, e, f, g) {
                        var h, k, l, m, p;
                        .01 >= a.Math.random() || b((h = {}, h[d] = (k = {}, k[Ea.cc] = (l = {}, l[e] = (m = {}, m[f] = g ? (p = {}, p[a.location.href] = g, p) : a.location.href, m), l), k), h))
                    })
                } catch (d) {}
            })(window);
            (function() {
                ee.push(rp);
                Je.unshift(np);
                bh.push(function(a) {
                    var c = void 0;
                    void 0 === c && (c = !0);
                    G(a).D("oo", c)
                })
            })();
            ub(function(a, c) {
                return {
                    N: function(b, d) {
                        var e = b.J,
                            f = b.K;
                        !xl[c.id] && f.C("pv") && c.exp && !e.nohit && (e.exp = c.exp, xl[c.id] = !0);
                        d()
                    }
                }
            }, -99);
            V.push(St);
            Vb.e = Wb;
            Ca.e = nb;
            ya.e = oc;
            lc({
                exp: {
                    ea: "experiments"
                }
            });
            rk.experiments = "ex";
            (function() {
                var a;
                lf.push(Tt);
                Ca.f = nb;
                z(ya, (a = {}, a.f = il, a));
                Z("f", Pb(), 1);
                Z("f", uj, 2);
                Z("f", Ad, 20)
            })();
            ee.push(function(a, c) {
                var b = {
                        oa: M(c),
                        md: za(a, c),
                        bg: ia(a),
                        Sd: Pa(a)
                    },
                    d = b.bg(pb);
                if (!b.Sd.Kd) {
                    var e = b.Sd.C("ymoo" + b.oa);
                    if (e && 30 > d - e) b = b.oa, delete G(a).C("counters", {})[b], Ua(Ra("uws"));
                    else qa(c, Ut(b))["catch"](D(a, "d.f"))
                }
            });
            (function() {
                var a, c, b = [Eb];
                z(ya, (a = {}, a.s = b, a.S = b, a.u = dd, a));
                z(Ca, (c = {}, c.s = Xb, c.S = nb, c.u = Xb, c));
                Z("s");
                Z("u");
                Z("S", Pb(["v", "hid", "u", "vf", "rn"]), 1);
                V.push(A("s",
                    Zo))
            })();
            Ca["8"] = Xb;
            ya["8"] = [fg];
            hl.push([fg, 0]);
            V.push(A("p.us", function(a, c) {
                return qa(c, function(b) {
                    if (n(b, "settings.sbp")) return si(a, b, {
                        cb: c,
                        Rb: "8",
                        Qd: "cs"
                    })
                })
            }));
            Z("p", Pb(ch), 1);
            Sg("pub", function(a, c) {
                return {
                    N: function(b, d) {
                        fi(a, c, b);
                        d()
                    }
                }
            }, 1);
            Ca.p = Yt;
            ya.p = ua([Db, Eb]);
            bb.push(bu);
            lc({
                yb: {
                    ea: "webvisor",
                    Ua: Gb
                },
                Rg: {
                    ea: "disableFormAnalytics",
                    Ua: Gb
                }
            });
            Z("4", Pb(ch), 1);
            Ca["4"] = Bl;
            ya["4"] = ua([Db, Eb, Wc]);
            bb.push(hu);
            (function() {
                Z("W", Pb(ch), 1);
                Sg("wv", no, 1);
                ya.W = ua([Db, Eb]);
                Ca.W = Bl;
                bb.push(Ru);
                V.push(Su);
                lc({
                    yb: {
                        ea: "webvisor"
                    }
                });
                lc({
                    Ui: {
                        ea: "trustedDomains"
                    },
                    ic: {
                        ea: "childIframe",
                        Ua: Gb
                    }
                });
                bh.push(function(a) {
                    G(a).C("stopRecorder", E)()
                })
            })();
            V.push(Uu);
            Z("pi");
            Ca.pi = Xb;
            ya.pi = dd;
            Sg("w", function(a, c) {
                return {
                    N: function(b, d) {
                        if (b.K) {
                            var e = zf(c),
                                f = e.status;
                            "rt" === e.Rb && f && (b.K.D("rt", f), b.na || (b.na = {}), b.na.Ih = 1 === f ? Rh(a, c) + "." : "")
                        }
                        d()
                    }
                }
            }, 2);
            V.push(Wu);
            V.push(gv);
            ya["6"] = ua([Db, Eb]);
            Ca["6"] = Xb;
            V.push(hv);
            V.push(Pt);
            (function() {
                Pg.push(function(a, c) {
                    c.informer = un(a)
                })
            })();
            ub(vf, 6);
            Z("1", vf, 6);
            Z("adb");
            Z("n",
                vf, 4);
            ya.adb = dd;
            Ca.adb = Kj;
            id.push(jv);
            ya["5"] = oc;
            Ca["5"] = nb;
            Vb["5"] = fa(v(Uc, pc([Qe, Ke]), Dc), Wb);
            V.push(kv);
            Z("5", Ad, 20);
            ub(Kh, 7);
            Z("n", Kh, 6);
            bb.push(lv);
            Ca.d = nb;
            Z("d", Pb(["hid", "u", "v", "vf"]), 1);
            ya.d = dd;
            Z("n", function(a, c) {
                return {
                    Da: function(b, d) {
                        if (!b.M || !b.M.force) {
                            var e = .002,
                                f = c.id === Ea.sg ? 1 : .002,
                                g, h, k, l, m;
                            void 0 === e && (e = 1);
                            void 0 === f && (f = 1);
                            var p = yd(a);
                            if (p && T(p.getEntriesByType) && (e = Math.random() > e, f = Math.random() > f, !e || !f)) {
                                p = p.getEntriesByType("resource");
                                for (var r = {}, q = {}, t = {}, x = wl(), F = R(a).href,
                                        U = 0; U < p.length; U += 1) {
                                    var N = p[U],
                                        ma = N.name.replace(vl, "").split("?")[0],
                                        wa = ec(ma),
                                        Bb = (g = {}, g.dns = Math.round(N.domainLookupEnd - N.domainLookupStart), g.tcp = Math.round(N.connectEnd - N.connectStart), g.duration = Math.round(N.duration), g.response = Math.round(N.responseEnd - N.requestStart), g);
                                    "script" !== N.initiatorType || e || (q[ma] = z(Bb, (h = {}, h.name = N.name, h.decodedBodySize = N.decodedBodySize, h.transferSize = Math.round(N.transferSize), h)));
                                    !Qt[wa] && !x[wa] || r[ma] || f || (r[ma] = z(Bb, (k = {}, k.pages = F, k)))
                                }
                                ea(r).length &&
                                    (t.timings8 = r);
                                ea(q).length && (t.scripts = q);
                                if (ea(t).length) va(a, "d", c)({
                                    K: Ka((l = {}, l.ar = 1, l.pv = 1, l)),
                                    ba: {
                                        da: yb(a, t) || void 0
                                    },
                                    J: (m = {}, m["page-url"] = F, m)
                                }, {
                                    id: Ea.wg,
                                    ca: "0"
                                })["catch"](D(a, "r.tim.ng2"))
                            }
                        }
                        d()
                    }
                }
            }, 7);
            ya.ci = [Eb];
            Ca.ci = Xb;
            bb.push(A("p.sci", function(a, c) {
                return qa(c, u(a, sn))["catch"](D(a, "ins.cs"))
            }));
            V.push(mv);
            bb.push(Gt);
            V.push(rv);
            ub(lh, 8);
            Z("f", lh, 3);
            Z("n", lh, 5);
            id.push(function(a) {
                return A("fip", function(c) {
                    if (!rl(c) || Sd(c)) {
                        var b = Pa(c);
                        if (!b.C("fip")) {
                            var d = v(Mb(v(function(e, f) {
                                return A("fip." +
                                    f, e)(c)
                            }, H(Zr, null))), we("-"))(a);
                            b.D("fip", d)
                        }
                    }
                })
            }([tv, sv, function(a) {
                var c = n(a, "ApplePaySession"),
                    b = R(a).protocol;
                a = c && "https:" === b && !jb(a) ? c : void 0;
                c = "";
                if (!a) return c;
                try {
                    c = "" + a.canMakePayments();
                    b = "";
                    var d = a.supportsVersion;
                    if (T(d))
                        for (var e = 1; 20 >= e; e += 1) b += d.call(a, e) ? "" + e : "0";
                    return b + c
                } catch (f) {
                    return c
                }
            }, function(a) {
                a = n(a, "navigator") || {};
                return a.doNotTrack || a.msDoNotTrack || "unknown"
            }, function(a) {
                if (a = Ft(a)) try {
                    for (var c = [], b = 0; b < sl.length; b += 1) {
                        var d = a(sl[b]);
                        c.push(d)
                    }
                    var e = c
                } catch (f) {
                    e = []
                } else e = [];
                return e ? I("x", e) : ""
            }, function(a) {
                var c = void 0;
                void 0 === c && (c = pv);
                var b = n(a, "navigator") || {};
                c = B(u(b, n), c);
                c = I("x", c);
                try {
                    var d = n(a, "navigator.getGamepads");
                    var e = na(d, "getGamepads") && a.navigator.getGamepads() || []
                } catch (f) {
                    e = []
                }
                return c + "x" + Ta(e)
            }, nv, function(a) {
                a = n(a, "screen") || {};
                return I("x", B(u(a, n), ov))
            }, function(a) {
                return I("x", Xm(a) || [])
            }, function(a) {
                a = nn(a);
                return ca(a) ? I("x", a) : a
            }, function(a) {
                return (a = pn(a)) ? I("x", B(C(["", ["matches", "media"]], Zm), ua(qh(a)))) : ""
            }]));
            ub(function(a) {
                return {
                    N: function(c,
                        b) {
                        var d = c.K,
                            e = Pa(a).C("fip");
                        e && d && (d.D("fip", e), me(c, "fip", zb(e)));
                        b()
                    }
                }
            }, 9);
            Z("h", function(a) {
                return {
                    Da: function(c, b) {
                        var d = c.Bi;
                        Sf(c) && d && G(a).D("isEU", n(d, "settings.eu"));
                        b()
                    }
                }
            }, 3);
            id.push(Qu);
            Yb.push(uv);
            bb.push(zv);
            V.push(Av);
            lc({
                dj: {
                    ea: "yaDisableGDPR"
                },
                ej: {
                    ea: "yaGDPRLang"
                }
            });
            Je.push(function(a, c) {
                return {
                    N: C([a, c], Jm)
                }
            });
            Rd.push("gdpr");
            Rd.push("gdpr_popup");
            vg.push(function(a, c) {
                var b = ke(a);
                b = le(b);
                if (fa(pc(Dv), b).length) return !0;
                b = c(a, "gdpr");
                return K(b, [Mc, Cv])
            });
            Je.push(function(a) {
                return {
                    N: function(c,
                        b) {
                        var d = c.na || {},
                            e;
                        (e = n(a, "document.referrer")) ? (e = Pc(a, e).host, e = kj(e), e = zl + "." + (e || Vt)) : e = hc;
                        c.na = z(d, {
                            Jh: [e]
                        });
                        b()
                    }
                }
            });
            ub(Vl, 5);
            Z("1", Vl, 6);
            ya.c = dd;
            Ca.c = Xb;
            Z("1", th, 7);
            ub(th, 7);
            Yb.push(A("hcp", rh));
            bb.push(A("p.ot", Gv));
            bb.push(gb("cta", Hv, !0));
            Z("n", function(a) {
                var c = G(a);
                return {
                    N: function(b, d) {
                        var e = b.M || {},
                            f = c.C("cta"),
                            g = c.C("cta.e");
                        if (f || g) {
                            e.R || (e.R = {});
                            e.R.__ym || (e.R.__ym = {});
                            var h = {};
                            f ? (f = B(function(k) {
                                    var l, m = n(k, "topic");
                                    k = n(k, "version");
                                    return l = {}, l.topic = m, l.version = k, l
                                }, f), h.ct =
                                f) : g && (h["ct.e"] = g);
                            z(e.R.__ym, h);
                            b.M = z(b.M || {}, e)
                        }
                        d()
                    }
                }
            }, 7);
            Z("n", $f, 8);
            V.push(Iv);
            V.push(Jv);
            bb.push(gb("hsa", A("hsa", function(a) {
                Cb(a)(Qa(E, function() {
                    var c = G(a);
                    if (n(a, "document.hasStorageAccess")) {
                        var b = 0;
                        if (Af(a, Oc, "hsa")) {
                            var d = E,
                                e = function(f) {
                                    c.D("hsa", f);
                                    Bf(Oc, "hsa");
                                    d();
                                    ha(a, b)
                                };
                            d = da(a).F(a, ["message"], A("hsa.o", u(e, gm)));
                            b = O(a, u("d", e), 1500)
                        } else c.D("hsa", "a")
                    } else c.D("hsa", "0")
                }))
            }), !0));
            Yb.push(A("cdl", function(a) {
                var c = G(a).Ia;
                if (a = n(a, "navigator.cookieDeprecationLabel")) try {
                    a.getValue().then(u("cdl",
                        c), C(["cdl", "e"], c))
                } catch (b) {
                    c("cdl", "d")
                } else c("cdl", "na")
            }));
            V.push(function(a, c) {
                var b = Xl(a),
                    d = M(c),
                    e = b[d];
                e || (e = {}, b[d] = e);
                e.Lh = !0;
                if (b = e.Wf) d = Yl(a), y(d, b)
            });
            Yb.push(function(a) {
                var c = n(a, "ym");
                if (c) {
                    var b = n(c, "a");
                    b || (c.a = [], b = c.a);
                    var d = Yl(a);
                    Ge(a, b, function(e) {
                        e.za.F(d)
                    }, !0)
                }
            });
            Rd.push("_ym_sup_debug");
            Yb.unshift(Kv);
            if (window.Ya && df) {
                var Zl = Ea.kc;
                window.Ya[Zl] = df;
                Xs(window);
                y(v(Xc([window, window.Ya[Zl]]), ja), Pg)
            }
            y(v(Xc([window]), ja), Yb)
        })()
    } catch (df) {};
}).call(this)